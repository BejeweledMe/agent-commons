"""Provider-launch coordination for the local UI.

The coordinator is an in-memory composition seam: it keeps the existing panel
request and response shapes while moving background-run ownership out of the
``UIContext`` compatibility facade.  It never defines a new persisted event or
provider protocol; delegation creation and runtime execution remain the
existing manager and runtime-service calls.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final, TypedDict, cast

from agent_commons.domain.envelopes import DelegationBudget, DelegationLimits
from agent_commons.errors import CommonsError, ConfigurationError, ValidationError
from agent_commons.runtime import (
    ContextBindingMode,
    ContextBindingRequest,
    DesignPackageBindingRequest,
)
from agent_commons.runtime.attempts import AttemptStore
from agent_commons.runtime.budget import OperatorBudgetExhaustedError, ProviderUnitBudget
from agent_commons.runtime.model import BuiltinProfileId
from agent_commons.services.conversations import Conversations
from agent_commons.services.manager import CommonsManager
from agent_commons.services.task_launch import create_task_delegation
from agent_commons.ui.provider_auth import (
    UIProviderAuthCoordinator,
    provider_auth_launch_refusal,
)
from agent_commons.ui.read_dtos import ProviderAuthPayload

if TYPE_CHECKING:
    from agent_commons.services.delegation_runtime import DelegationRuntimeService
    from agent_commons.ui.context import UIContext

_LOG = logging.getLogger("agent_commons.ui")

MIN_WALL_TIME_SECONDS: Final = 60
MAX_WALL_TIME_SECONDS: Final = 3600

#: The one wording for "this panel cannot launch yet", shared by the direct-call
#: refusal here and the typed ``launch_not_configured`` HTTP refusal in
#: `ui.server`, so the two can never drift into two explanations of one state.
LAUNCH_NOT_CONFIGURED = (
    "no runtime environment is configured for this panel: launching a provider "
    "needs an operator session and an operator profile config"
)

_GENERIC_LAUNCH_FAILURE_SUMMARY = (
    "the panel could not start this run because runtime configuration or process "
    "startup failed; provider details were suppressed"
)
_KNOWN_PROFILE_FAILURE_SUMMARIES = {
    f"runner profile is not configured: {profile_id.value}": (
        f"the panel could not start this run: runner profile is not configured: {profile_id.value}"
    )
    for profile_id in BuiltinProfileId
}


def _safe_launch_failure_summary(exc: Exception) -> str:
    """Map an exception to fixed text without returning its arbitrary detail."""

    try:
        key = str(exc)
    except Exception:  # pragma: no cover - hostile exception defensive boundary
        return _GENERIC_LAUNCH_FAILURE_SUMMARY
    return _KNOWN_PROFILE_FAILURE_SUMMARIES.get(key, _GENERIC_LAUNCH_FAILURE_SUMMARY)


@dataclass(frozen=True, slots=True)
class LaunchRequest:
    """The complete in-memory input of the existing launch call."""

    agent_id: str
    task_id: str
    wall_time_seconds: int | None = None
    idempotency_key: str | None = None
    background: bool = True
    context: ContextBindingRequest = ContextBindingRequest.fresh()
    design_package: DesignPackageBindingRequest | None = None


class LaunchResult(TypedDict):
    """The existing `/api/delegations` success body, in wire-field order."""

    delegation_id: str
    target_profile: str
    purpose: str
    launched: bool


class UILaunchCoordinator:
    """Create and run one bounded UI delegation through the configured runtime."""

    #: A UI-launched run is one bounded leaf with one provider attempt.
    _DEFAULT_RUN_LIMITS: Final = DelegationLimits(
        max_depth=0,
        wall_time_seconds=600,
        max_attempts=1,
        max_concurrency=1,
        budget=DelegationBudget(unit="provider_units", limit=1),
    )

    def __init__(self, context: UIContext) -> None:
        self._context = context
        self._launch_threads: list[threading.Thread] = []
        self._thread_factory: Callable[..., threading.Thread] = threading.Thread
        self._lifecycle = threading.Condition(threading.RLock())
        self._launch_preparations = 0
        self._draining = False
        # A test/embedder runtime factory is a construction-time dependency.
        # Capturing it prevents later mutable context state from swapping the
        # auth probe independently of the coordinator that owns its flights.
        auth_runtime_factory = context._runtime_factory
        if auth_runtime_factory is not None:

            def build_auth_runtime() -> DelegationRuntimeService:
                return cast(
                    "DelegationRuntimeService",
                    auth_runtime_factory(self._context.manager()),
                )

        else:

            def build_auth_runtime() -> DelegationRuntimeService:
                return self._runtime_service(self._context.manager())

        self._provider_auth = UIProviderAuthCoordinator(build_auth_runtime)

    def await_launches(self, timeout: float | None = 30.0) -> None:
        """Join any background launch threads. For tests and clean shutdown."""

        deadline = None if timeout is None else time.monotonic() + timeout
        with self._lifecycle:
            threads = tuple(self._launch_threads)
        for thread in threads:
            thread.join(timeout=None if deadline is None else max(0.0, deadline - time.monotonic()))

    def begin_draining(self) -> None:
        """Close launch admission before a host starts draining its projects."""

        with self._lifecycle:
            self._draining = True

    def _finish_preparation(self) -> None:
        with self._lifecycle:
            self._launch_preparations -= 1
            self._lifecycle.notify_all()

    def provider_auth_status(self, profile_id: str) -> ProviderAuthPayload:
        return self._provider_auth.status(profile_id)

    def check_provider_auth(self, profile_id: str) -> ProviderAuthPayload:
        return self._provider_auth.check_again(profile_id)

    def start_provider_login(self, profile_id: str) -> ProviderAuthPayload:
        return self._provider_auth.start_login(profile_id)

    def cancel_provider_login(self, profile_id: str) -> ProviderAuthPayload:
        return self._provider_auth.cancel_login(profile_id)

    def shutdown(self, timeout: float | None = None) -> dict[str, int]:
        """Drain owned launch threads, preserving truthful live-work state."""

        self.begin_draining()
        with self._lifecycle:
            while self._launch_preparations:
                self._lifecycle.wait()
        self.await_launches(timeout=timeout)
        with self._lifecycle:
            live = sum(1 for thread in self._launch_threads if thread.is_alive())
        # Provider-auth cleanup has its own short, bounded process barrier;
        # only recorded delegation threads are drained without a speculative
        # timeout during host shutdown.
        self._provider_auth.shutdown(timeout=5.0 if timeout is None else timeout)
        return {"live": live}

    def _runtime_service(self, manager: CommonsManager) -> DelegationRuntimeService:
        """Build the same runtime service the CLI uses, under the writer session."""

        if self._context._runtime_factory is not None:
            return cast("DelegationRuntimeService", self._context._runtime_factory(manager))
        from agent_commons.services.delegation_runtime import (
            DelegationRuntimeService,
            load_runtime_configuration,
        )

        config = load_runtime_configuration(
            self._context._profile_config,
            workspace_root=self._context.repo,
        )
        runner = None
        if config.demo:
            # An internal/dev config can bind the runner seam without the panel
            # advertising demo capability.
            from agent_commons.runtime.demo import DemoRunner

            runner = DemoRunner(manager.paths.state_root)
        return DelegationRuntimeService(
            manager,
            profiles=config.profiles,
            operator_limits=config.limits,
            catalog=config.catalog,
            runner=runner,
            library_store=self._context.library_store(),
        )

    def budget_observation(
        self,
        profile_id: str,
        *,
        parent_session_id: str | None = None,
    ) -> ProviderUnitBudget:
        """Observe the operator's next root launch without opening or renewing a session."""
        from agent_commons.services.delegation_runtime import load_runtime_configuration

        context = self._context
        manager = context.manager()
        if parent_session_id is None:
            if context._session_owner is not None:
                parent_session_id = context._session_owner.session_id
            elif context._session_provider is not None:
                parent_session_id = context._session_provider()
            else:
                parent_session_id = context._writer_session_id
        manager.sessions.require_active(parent_session_id)
        config = load_runtime_configuration(context._profile_config, workspace_root=context.repo)
        profile = config.profiles.get(BuiltinProfileId(profile_id))
        return AttemptStore(
            manager.paths.state_root,
            operator_limits=config.limits,
            read_only=True,
        ).observe_provider_budget(
            parent_session_id=str(parent_session_id), profile_id=profile.profile_id
        )

    def launch_budget(self, profile_id: str) -> dict[str, object]:
        return self.budget_observation(profile_id).to_wire(BuiltinProfileId(profile_id))

    def run(self, request: LaunchRequest) -> LaunchResult:
        """Record a bounded delegation for a role, then run it through the broker."""

        context = self._context
        if not context.launch_enabled:
            raise ConfigurationError(LAUNCH_NOT_CONFIGURED)
        limits = self._DEFAULT_RUN_LIMITS.to_payload()
        if request.wall_time_seconds is not None:
            wall_time_seconds = request.wall_time_seconds
            if isinstance(wall_time_seconds, bool) or not isinstance(wall_time_seconds, int):
                raise ValidationError(
                    "invalid_wall_time_seconds: wall_time_seconds must be an integer "
                    "between 60 and 3600"
                )
            if not MIN_WALL_TIME_SECONDS <= wall_time_seconds <= MAX_WALL_TIME_SECONDS:
                raise ValidationError(
                    "invalid_wall_time_seconds: wall_time_seconds must be between 60 and 3600"
                )
            limits["wall_time_seconds"] = wall_time_seconds
        if context._session_owner is not None:
            context._session_owner.ensure_run_ttl(int(limits["wall_time_seconds"]))
        writer = context.writer()
        role = writer.get_agent(request.agent_id)
        if role.get("state") != "active":
            raise ValidationError("only an active role can be given work")
        if role.get("template"):
            raise ValidationError("a role preset is a template and is never employed")
        try:
            role_context_mode = ContextBindingMode(str(role.get("context_mode", "fresh")))
        except ValueError as exc:
            raise ValidationError("the selected role has an invalid context mode") from exc
        if role_context_mode is ContextBindingMode.ACCUMULATED:
            if request.context.mode is not ContextBindingMode.ACCUMULATED:
                raise ValidationError(
                    "an accumulated role requires one exact published Context Pack revision"
                )
        elif request.context.mode is not ContextBindingMode.FRESH:
            raise ValidationError("a fresh role cannot receive a Context Pack")
        snapshot = writer.snapshot()
        task = snapshot.tasks.get(request.task_id)
        if task is None:
            raise ValidationError(f"no such task: {request.task_id}")
        unresolved_dependencies = tuple(
            dependency
            for dependency in (str(item) for item in (task.get("dependencies") or ()))
            if snapshot.tasks.get(dependency, {}).get("state") != "accepted"
        )
        if unresolved_dependencies:
            raise ValidationError(
                "this task is blocked by unresolved dependencies; accept prerequisite tasks "
                "before launch"
            )
        profile_id = str(role["profile_id"])
        purpose = "implementation"
        if profile_id.endswith("independent-reviewer"):
            purpose = "independent_review"
        # Probe the exact configured profile before creating a canonical
        # delegation.  Authentication refusal is therefore pure: no child,
        # attempt, receipt, or requested delegation exists yet.
        auth_status = self.provider_auth_status(profile_id)
        if auth_status["blocks_launch"]:
            raise provider_auth_launch_refusal(auth_status)
        # A replay of an already recorded request consumes no new unit. Its
        # exact content is still checked by create_delegation and the broker.
        replay = request.idempotency_key and snapshot.delegations.get(
            writer._new_entity_id("delegation", "delegation.requested", request.idempotency_key)
        )
        if not replay:
            budget = self.budget_observation(profile_id, parent_session_id=writer.session_id)
            if budget.exhausted:
                raise OperatorBudgetExhaustedError(budget, BuiltinProfileId(profile_id))
        runtime: DelegationRuntimeService | None = None
        if (
            request.context.mode is ContextBindingMode.ACCUMULATED
            or request.design_package is not None
        ):
            runtime = self._runtime_service(writer)
        if request.design_package is not None:
            # Refuse stale, missing, unauthorized, or superseded Design
            # Packages before a canonical delegation, child session, or attempt
            # exists.  The runtime repeats this exact validation under the
            # per-delegation lock and persists only safe provenance metadata.
            runtime.validate_design_package_selection(request.design_package)
        if request.context.mode is ContextBindingMode.ACCUMULATED:
            # Refuse a stale, missing, unauthorized, or oversized pack while
            # the HTTP action is still synchronous and before a canonical
            # delegation, child session, or attempt exists.  The runtime
            # repeats this exact validation under the per-delegation lock.
            runtime.validate_context_selection(request.context)
        # The writer is pinned before background ownership begins.  Runtime
        # construction remains in the owned launch body so a configuration
        # failure is recorded on the newly-created delegation as
        # `needs_operator`, rather than turning a truthful async refusal into
        # an HTTP failure with no delegation to inspect.
        launch_runtime = runtime
        with self._lifecycle:
            if self._draining:
                raise ConfigurationError(
                    "this panel is draining existing work and cannot launch another run"
                )
            self._launch_preparations += 1
        admission = context._launch_admission
        admitted = False
        if admission is not None:
            if not admission.acquire(blocking=False):
                self._finish_preparation()
                raise ConfigurationError(
                    "this local host is already running its maximum number of provider launches"
                )
            admitted = True
        try:
            # Every task worker must have a bounded, correctly addressed return
            # channel before provider work starts. Existing scopes are reused.
            Conversations(writer).ensure(
                scope={"kind": "task", "id": request.task_id},
                idempotency_key=f"launch-conversation-{request.task_id}",
            )
            delegation = create_task_delegation(
                writer,
                target_ref={"kind": "task", "id": request.task_id},
                target_revision=str(task.get("effective_revision") or task["revision"]),
                target_profile=profile_id,
                purpose=purpose,
                limits=limits,
                on_behalf_of_agent_id=request.agent_id,
                idempotency_key=request.idempotency_key,
            )
        except Exception:
            if admitted:
                admission.release()
            self._finish_preparation()
            raise
        delegation_id = str(delegation["entity_ref"]["id"])
        launch_key = f"ui-launch-{delegation_id}"

        def launch() -> None:
            try:
                launch_kwargs = {
                    "idempotency_key": launch_key,
                    "context": request.context,
                }
                if request.design_package is not None:
                    launch_kwargs["design_package"] = request.design_package
                (launch_runtime or self._runtime_service(writer)).run(
                    delegation_id, delegation["revision"], **launch_kwargs
                )
            except Exception as exc:  # a launch failure is reported, never silent
                # The runtime repeats the auth gate immediately before opening
                # the child.  If credentials changed after the UI precheck,
                # leave this exact delegation requested and retryable; calling
                # it terminal `launch_failed` would make the visible recovery
                # action a lie.
                if getattr(exc, "code", None) in {
                    "provider_auth_required",
                    "provider_auth_unknown",
                    "credential_store_unavailable",
                }:
                    _LOG.warning(
                        "UI launch of %s stopped at the provider-auth gate; "
                        "provider details were suppressed",
                        delegation_id,
                    )
                    context.invalidate()
                    return
                budget_failure = isinstance(exc, OperatorBudgetExhaustedError)
                safe_summary = str(exc) if budget_failure else _safe_launch_failure_summary(exc)
                _LOG.warning(
                    "UI launch of %s failed before canonical finalization; "
                    "provider details were suppressed",
                    delegation_id,
                )
                try:
                    writer.mark_delegation_needs_operator(
                        delegation_id,
                        str(delegation["revision"]),
                        reason_code="budget_exhausted" if budget_failure else "launch_failed",
                        summary=safe_summary,
                        idempotency_key=f"{launch_key}:launch-failed",
                    )
                    context.invalidate()
                except CommonsError:  # pragma: no cover - defence
                    _LOG.warning(
                        "UI launch failure of %s could not be recorded; details suppressed",
                        delegation_id,
                    )
            finally:
                context.invalidate()
                if admitted:
                    admission.release()

        def mark_unlaunched(summary: str) -> None:
            try:
                writer.mark_delegation_needs_operator(
                    delegation_id,
                    str(delegation["revision"]),
                    reason_code="launch_failed",
                    summary=summary,
                    idempotency_key=f"{launch_key}:unlaunched",
                )
            except CommonsError:
                _LOG.warning("unlaunched UI delegation %s could not be finalized", delegation_id)
            finally:
                context.invalidate()

        if request.background:
            # A recorded delegation is bounded work this host owns.  It must
            # survive server-route shutdown long enough to reach its truthful
            # terminal state; a daemon would be silently killed as the CLI
            # process exits and the session lock/heartbeat then lied about it.
            thread = self._thread_factory(target=launch, name=launch_key, daemon=False)
            refused = False
            start_error: RuntimeError | None = None
            with self._lifecycle:
                if self._draining:
                    refused = True
                else:
                    self._launch_threads.append(thread)
                    try:
                        thread.start()
                    except RuntimeError as exc:
                        self._launch_threads.remove(thread)
                        start_error = exc
                self._launch_preparations -= 1
                self._lifecycle.notify_all()
            if refused or start_error is not None:
                mark_unlaunched(
                    "the local panel stopped before this bounded run could start"
                    if refused
                    else "the local panel could not start this bounded run"
                )
                if admitted:
                    admission.release()
                if start_error is not None:
                    raise ConfigurationError(
                        "the local panel could not start this bounded run"
                    ) from start_error
                raise ConfigurationError(
                    "this panel is draining existing work and cannot launch another run"
                )
        else:
            try:
                launch()
            finally:
                self._finish_preparation()
        context.invalidate()
        return {
            "delegation_id": delegation_id,
            "target_profile": profile_id,
            "purpose": purpose,
            "launched": True,
        }
