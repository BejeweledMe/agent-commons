export type JsonObject = Record<string, unknown>;

export type ApiError = {
  code: string;
  message: string;
  safeNextActions: readonly string[];
  /**
   * The typed refusal payload of an answer the server sends without the usual
   * `error` envelope. `null` means the answer carried no readable refusal, which
   * is never read as "no reason": the surface stays fail-closed either way.
   */
  refusal?: WorkerRefusal | null;
  /**
   * The additive launch-budget object an `operator_budget_exhausted` precheck
   * sends with its refusal, exactly as received. `launchBudget.ts` validates
   * it; an unreadable object leaves the refusal without a count rather than
   * inventing one.
   */
  budget?: JsonObject | null;
};

/**
 * The server's typed reason a launch was refused before any attempt existed or
 * a run stopped: exactly `{code, reason, next_action}` from `runtime/refusals.py`.
 * `code` stays a string because an additive server code must keep its object and
 * render the neutral sentence; the client never infers one from process output.
 * `reason` is the server's own bounded, sanitized sentence (at most 256 characters).
 */
export type StopReason = {
  code: string;
  reason: string;
  nextAction: string;
};

export type SetupStatus = {
  state: string;
  launchEnabled: boolean;
  writesEnabled: boolean;
};

export type SetupGuidanceTool = "Claude" | "Codex" | "git" | "agent-commons-mcp";

export type SetupGuidanceBlockerCode =
  | "setup_not_a_repository"
  | "setup_uninitialized"
  | "setup_unconfigured"
  | "setup_no_provider_found"
  | "setup_support_binary_unresolved"
  | "setup_config_rejected_by_loader";

export type SetupGuidanceNextActionKey =
  | "choose_git_repository"
  | "initialize_workspace"
  | "install_provider_and_check_again"
  | "install_support_tool_and_check_again"
  | "configure_runtime"
  | "repair_workspace_configuration"
  | "setup_ready";

export type SetupGuidance = {
  blockerCode: SetupGuidanceBlockerCode | null;
  tools: readonly SetupGuidanceTool[];
  nextActionKey: SetupGuidanceNextActionKey;
  locationLabel: "workspace_configuration" | null;
};

export type Profile = {
  id: string;
  label: string;
  provider?: string;
  model?: string | null;
  configured?: boolean;
};

export type Catalog = {
  profiles: readonly Profile[];
  presets: readonly RolePreset[];
  contextModes: readonly string[];
  grantLevels: readonly string[];
  modelOptions?: Readonly<Record<string, readonly string[]>>;
};

export type RoleOption = {
  id: string;
  name: string;
  profileId: string;
  contextMode: "fresh" | "accumulated";
  model?: string | null;
  specializationRef?: import("./libraryTypes.js").LibraryRef | null;
};

export type RoleCreateResult = { agentId: string };

export type RolePreset = RoleOption & { skills: readonly string[] };

export type TaskOption = {
  id: string;
  title: string;
  state: string;
};

export type TaskCreateResult = { taskId: string; revision: string };

/** One canonical finding the server attached to this task record. */
export type TaskFinding = {
  id: string;
  title: string | null;
};

export type TaskDetail = {
  taskId: string;
  revision: string;
  title: string;
  description: string;
  acceptanceCriteria: readonly string[];
  state: string;
  summary: string | null;
  evidenceRefs: readonly RevisionBoundRef[];
  /** `null` when the record carries no findings key: the server has not said, which is not "none". */
  findings: readonly TaskFinding[] | null;
  truncated: boolean;
};

export type ContextSourceOption = {
  ref: RevisionBoundRef;
  label: string;
  freshness: "current";
};
export type ContextSourceCatalog = {
  schema: "agent-commons.ui.context-sources.v1";
  state: "empty" | "ready";
  sources: readonly ContextSourceOption[];
  truncated: boolean;
};

export type ContextPackOption = {
  contextPackId: string;
  revision: string;
  summary: string;
  factCount: number;
  openQuestionCount: number;
};

export type ContextPackOptionsStatus = {
  freshness: "current";
  truncated: boolean;
  refusal: "context_pack_options_truncated" | null;
};

export type DesignPackageOption = {
  designPackageId: string;
  revision: string;
  title: string;
  screenCount: number;
};

export type DesignPackageOptionsStatus = {
  freshness: "current";
  truncated: boolean;
  refusal: "design_package_options_truncated" | null;
};

export type ContextPackReferenceKind =
  | "artifact"
  | "finding"
  | "task"
  | "thread"
  | "verification"
  | "decision";

export type RevisionBoundRef = {
  kind: ContextPackReferenceKind;
  id: string;
  revision: string;
};

export type ContextPackFact = {
  statement: string;
  sourceRefs: readonly RevisionBoundRef[];
};

export type ContextPackDraft = {
  summary: string;
  facts: readonly ContextPackFact[];
  decisionRefs: readonly RevisionBoundRef[];
  openQuestions: readonly string[];
};

export type ContextPackDetail = ContextPackDraft & {
  schema: "agent-commons.ui.context-pack.v1";
  state: "published";
  contextPackId: string;
  revision: string;
  recordedAt: string | null;
};

export type ContextPackCatalog = {
  schema: "agent-commons.ui.context-packs.v1";
  state: "empty" | "ready";
  packs: readonly ContextPackOption[];
  truncated: boolean;
};

export type LaunchOptions = {
  launchEnabled: boolean;
  roles: readonly RoleOption[];
  tasks: readonly TaskOption[];
  contextPacks: readonly ContextPackOption[];
  contextPackOptionsStatus: ContextPackOptionsStatus;
  designPackages: readonly DesignPackageOption[];
  designPackageOptionsStatus: DesignPackageOptionsStatus;
};

export type ProviderAuthState =
  | "ready"
  | "authentication_required"
  | "authenticating"
  | "timed_out"
  | "cancelled"
  | "failed"
  | "unsupported"
  | "credential_store_unavailable";

export type ProviderAuthAction =
  | "authenticate"
  | "cancel_authentication"
  | "check_again"
  | "continue_launch";

export type ProviderAuthStatus = {
  profileId: string;
  provider: "claude" | "codex" | "grok";
  operation: "status" | "login";
  state: ProviderAuthState;
  supported: boolean;
  blocksLaunch: boolean;
  checkedAt: string;
  freshness: "fresh" | "stale";
  freshForSeconds: number;
  actionIds: readonly ProviderAuthAction[];
  postStartRecovery: "new_run_only";
};

export type ProviderAvailabilityRefusalCode =
  | "provider_installation_unavailable"
  | "provider_initialization_failed"
  | "provider_qualification_required"
  | "provider_qualification_failed"
  | "provider_authentication_required"
  | "provider_authentication_unconfirmed";

export type ProviderCapabilityRefusalCode =
  | "provider_resume_unavailable"
  | "provider_skill_projection_unavailable"
  | "provider_monetary_budget_unavailable";

export type ProviderAvailability = {
  profileId: string;
  provider: "claude" | "codex" | "grok";
  model: string | null;
  capabilities: {
    mcp: boolean;
    skills: boolean;
    resume: "unavailable";
    cancellation: string;
    usageReporting: string;
    sandboxBoundary: string;
    budgetUnits: readonly string[];
    contextModes: readonly ["fresh", "accumulated"];
  };
  capabilityRefusals: readonly {
    code: ProviderCapabilityRefusalCode;
    remediation: readonly string[];
  }[];
  installationState: "installed" | "unavailable";
  initializationState: "ready" | "failed" | "passed_unqualified" | "not_checked";
  qualification: {
    state: "qualified" | "required" | "failed";
    freshness: "current" | "missing" | "invalid";
    fingerprint: string | null;
    checkedAt: string | null;
    /** Additive (WP-15.3): the wall time the canary used; null when the server did not provide it. */
    wallTimeSeconds: number | null;
  };
  authentication: {
    state: ProviderAuthState | "not_checked";
    freshness: "fresh" | "stale" | "unknown";
  };
  launchable: boolean;
  refusal: {
    code: ProviderAvailabilityRefusalCode;
    remediation: readonly string[];
  } | null;
};

/** Refusal codes the worker-eligibility read model may attach to one worker. */
export type WorkerEligibilityRefusalCode =
  | "worker_observation_missing"
  | "specialization_unavailable"
  | "review_profile_incompatible"
  | ProviderAvailabilityRefusalCode;

/** Informative descriptions of a worker. Never a permission or an authorization. */
export type WorkerCapability =
  | "tools"
  | "skills_projection"
  | "trusted_workspace"
  | "review_only";

export type WorkerRefusal = {
  code: WorkerEligibilityRefusalCode;
  remediation: readonly string[];
};

export type WorkerEligibilityState = "eligible" | "ineligible" | "unknown";

export type WorkerEligibilityEntry = {
  profileId: string;
  provider: "claude" | "codex" | "grok";
  model: string | null;
  eligibility: WorkerEligibilityState;
  /** Exactly the server's reason; `null` only for an eligible worker. */
  refusal: WorkerRefusal | null;
  capabilities: readonly WorkerCapability[];
  observedRevision: string | null;
};

/**
 * Server truth for specialization hiring. A missing, stale or unreadable answer
 * is `unknown`, therefore unselectable; the client never infers eligibility.
 */
export type WorkerEligibility = {
  schema: "agent_commons.worker-eligibility.v1";
  specialization: import("./libraryTypes.js").LibraryRef | null;
  workers: readonly WorkerEligibilityEntry[];
};

/**
 * Local, content-free usage counters. Every key is one of the closed enums the
 * server accepts, so a count can never carry an identifier or free text.
 */
export type InstrumentationCounters = Readonly<Partial<Record<
  import("./instrumentation.js").InstrumentationKind,
  Readonly<Partial<Record<
    import("./instrumentation.js").InstrumentationOutcome,
    Readonly<Partial<Record<import("./instrumentation.js").InstrumentationBucket, number>>>
  >>>
>>>;

export type Instrumentation = {
  schema: "agent_commons.instrumentation.v1";
  /** Server truth for the toggle; the client never assumes it. */
  enabled: boolean;
  uiVersion: string;
  counters: InstrumentationCounters;
  retention: { windowDays: number; updatedAtDay: string };
  /** The exact revision every instrumentation write must carry back. */
  revision: string;
};

export type WorkspaceMeta = {
  repo: string;
  writesEnabled: boolean;
};

export type WorkspaceData = {
  meta: WorkspaceMeta;
  setup: SetupStatus;
  guidance: SetupGuidance | null;
  catalog: Catalog | null;
  launch: LaunchOptions | null;
  providerAuth: readonly ProviderAuthStatus[];
  providerAuthErrors: readonly string[];
  providerAvailability: readonly ProviderAvailability[];
};

export type Failure = {
  code: string;
  title: string;
  nextStep: string;
  canRetry: boolean;
  safeNextActions: readonly string[];
};

export type TrackerSurfaceState =
  | "loading"
  | "empty"
  | "ready"
  | "partial"
  | "stale"
  | "error";

export type TrackerTask = {
  taskKind: "task" | "component";
  parentTaskId: string | null;
  taskId: string;
  title: string;
  taskState: string;
  readiness: string;
  dependencyTaskIds: readonly string[];
  blockingDependencyIds: readonly string[];
  ownerSessionId: string | null;
  roleName: string | null;
  suggestedAgentId: string | null;
  suggestedRoleName: string | null;
  suggestedProvider: "codex" | "claude" | "grok" | null;
  provider: string | null;
  profileId: string | null;
  phase: string | null;
  awaitsHuman: boolean;
  nextAction: string;
  freshness: string;
  evidenceState: string;
  gaps: readonly string[];
  /** Canonical provenance, shown as raw values in the decision card's details. */
  objectiveId: string | null;
  applicationId: string | null;
};

export type TrackerEdge = {
  prerequisiteTaskId: string;
  dependentTaskId: string;
  prerequisiteMissing: boolean;
};

export type TrackerRun = {
  delegationId: string;
  taskId: string | null;
  agentId: string | null;
  roleName: string | null;
  provider: string | null;
  profileId: string | null;
  phase: string;
  attemptId: string | null;
  attemptNumber: number | null;
  startedAt: string | null;
  updatedAt: string | null;
  finishedAt: string | null;
  durationSeconds: number | null;
  wallTimeSeconds: number | null;
  awaitsHuman: boolean;
  nextAction: string;
  freshness: string;
  evidenceState: string;
  /**
   * Additive: the typed stop reason, from the run's own field or decoded from
   * the bounded canonical summary. `null` means the server said nothing, which
   * keeps the existing generic copy rather than inventing a reason.
   */
  stopReason: StopReason | null;
  /**
   * Additive: the bounded, sanitized diagnostic tail the server keeps for an
   * unsuccessful process. An incomplete tail is withheld, and what remains may
   * appear only inside a closed disclosure, never in the first layer.
   */
  providerDiagnostic: string | null;
};

export type TrackerAttention = {
  kind: "run" | "review";
  itemId: string;
  taskId: string | null;
  reasonCode: string;
  nextAction: string;
};

export type TrackerCapacity = {
  state: string;
  active: number | null;
  limit: number | null;
  queued: number | null;
  queueCapacity: number | null;
};

export type TrackerFreshness = {
  generatedAt: string;
  sourceUpdatedAt: string | null;
  state: string;
  resumeGap: boolean;
};

export type TrackerSnapshot = {
  schema: "agent-commons.tracker.v1";
  sequence: number;
  sourceRevision: string | null;
  truncated: boolean;
  state: TrackerSurfaceState;
  tasks: readonly TrackerTask[];
  edges: readonly TrackerEdge[];
  runs: readonly TrackerRun[];
  attention: readonly TrackerAttention[];
  capacity: TrackerCapacity;
  freshness: TrackerFreshness;
  focusTaskIds: readonly string[];
  criticalPathTaskIds: readonly string[];
  criticalPathBasis: "dependency_depth_only";
  criticalPathPredictive: false;
  gaps: readonly string[];
};
