import type { AgentBoardSession } from "../agentBoardState.js";
import { AgentSettings, type AgentTab } from "./AgentSettings.js";
import { Icon, IconButton } from "./Icon.js";
import { Modal } from "./Modal.js";
import type { LibraryState } from "../libraryTypes.js";
import { type ReactElement, type ReactNode, useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import {
  Background, Controls, Handle, Position, ReactFlow, ReactFlowProvider, applyNodeChanges, useReactFlow, useNodesInitialized,
  type Connection, type Edge, type Node, type NodeChange, type NodeProps
} from "@xyflow/react";
import { ApiProblem, requestOutcome, type WorkApi } from "../api.js";
import { recordInstrumentation } from "../instrumentation.js";
import type { RoleOption } from "../contracts.js";
import type { Locale, MessageKey } from "../i18n.js";
import type { BlueprintApplication } from "../libraryTypes.js";
import type { TrackerViewState } from "../trackerState.js";
import {
  BoardError, EMPTY_LAYOUT, OWNER_NODE_ID, addFrame, buildBoardModel, frameForApplication, layoutBody, moveFrame, moveRole, parseBoardGraph, parseBoardLayout,
  removeFrame, renameFrame, resetPositions, roleCardCopy, type BoardFrame, type BoardGraph, type BoardLayout, type BoardRoleNode
} from "../boardState.js";
import { ConversationButton } from "./ConversationPanel.js";
import { AgentGalleryButton, OutputsButton } from "./OutputsPanel.js";

type Text = (key: MessageKey) => string;

type RoleData = {
  role: BoardRoleNode; text: Text; writesEnabled: boolean; canGiveTask: boolean;
  onConfigure: (agentId: string, tab: AgentTab) => void; onChild: (agentId: string) => void; supervisorName: string | null; cardTitle: string; cardDescription: string;
  onOpenTasks: (agentId: string) => void; onGiveTask: (agentId: string) => void;
};
type FrameData = { frame: BoardFrame; text: Text; writesEnabled: boolean; onRename: (frameId: string, title: string) => void; onRemove: (frameId: string) => void };
type RoleFlowNode = Node<RoleData, "role">;
type FrameFlowNode = Node<FrameData, "frame">;
type OwnerFlowNode = Node<{ text: Text; onOpenChat: () => void }, "owner">;
type BoardNode = RoleFlowNode | FrameFlowNode | OwnerFlowNode;

function OwnerNode({ data }: NodeProps<OwnerFlowNode>): ReactElement {
  return <div className="board-owner"><Icon name="supervisor" size={20} /><strong>{data.text("owner_title")}</strong><button type="button" className="button button-secondary nodrag" onClick={data.onOpenChat}><Icon name="chat" />{data.text("owner_chat")}</button><Handle type="source" position={Position.Bottom} isConnectable={false} /></div>;
}

/** A standing role on the board. Every action is an existing server operation or a navigation. */
function RoleNode({ data }: NodeProps<RoleFlowNode>): ReactElement {
  const { role, text } = data;
  return <div className="board-role" data-activity={role.activity} data-agent-id={role.id}>
    <Handle type="target" position={Position.Top} isConnectable={data.writesEnabled} />
    <div className="board-role-head">
      <AgentGalleryButton scope={{ kind: "agent", id: role.id }} title={role.name} displayTitle={data.cardTitle} />
      <span className="board-role-activity">{text(`board_activity_${role.activity}` as MessageKey)}</span>
    </div>
    <p className="board-role-identity" title={role.name}>{role.name}</p>
    <p className="board-role-meta" title={data.cardDescription}>{data.cardDescription}</p>
    <button type="button" className="board-supervisor nodrag" title={text("board_supervisor_help")} onClick={() => data.onConfigure(role.id, "general")}><Icon name="supervisor" size={14} />{data.supervisorName ? `${text("agent_supervisor")}: ${data.supervisorName}` : role.supervisorId ? text("agent_supervisor_unavailable") : text("agent_assign_supervisor")}</button>
    <p className="board-role-tasks">{role.taskCount === 0 ? text("board_role_no_tasks") : `${text("board_role_tasks")}: ${role.taskCount} · ${role.openTaskCount} ${text("board_role_open_tasks")}`}</p>
    <div className="board-role-actions nodrag">
      <IconButton icon="settings" label={text("agent_settings")} onClick={() => data.onConfigure(role.id, "general")} />
      <IconButton icon="skills" label={text("agent_tab_skills")} onClick={() => data.onConfigure(role.id, "skills")} />
      <IconButton icon="permissions" label={text("agent_tab_permissions")} onClick={() => data.onConfigure(role.id, "permissions")} />
      <IconButton icon="add-child" label={text("agent_add_child")} disabled={!data.writesEnabled} onClick={() => data.onChild(role.id)} />
      <ConversationButton compact scope={{ kind: "agent", id: role.id }} title={role.name} />
      <OutputsButton compact scope={{ kind: "agent", id: role.id }} title={role.name} />
      <IconButton icon="tasks" label={text("board_role_tasks")} onClick={() => data.onOpenTasks(role.id)} />
      <IconButton icon="run" label={text("board_role_give_task")} disabled={!data.writesEnabled || !data.canGiveTask} onClick={() => data.onGiveTask(role.id)} />
    </div>
    <button type="button" className="board-connections nodrag" title={text("board_connections_help")} onClick={() => data.onConfigure(role.id, "connections")}><Icon name="link" size={14} />{text("board_connections")}</button>
    <Handle type="source" position={Position.Bottom} isConnectable={data.writesEnabled} />
  </div>;
}

/** A department frame: an arrangement on the board, not a canonical Team. */
function FrameNode({ data }: NodeProps<FrameFlowNode>): ReactElement {
  const { frame, text } = data;
  return <div className="board-frame" data-frame-id={frame.id}>
    <div className="board-frame-head">
      <input className="board-frame-title nodrag" aria-label={text("board_frame_rename")} defaultValue={frame.title} disabled={!data.writesEnabled} maxLength={120}
        onBlur={(event) => { if (event.currentTarget.value.trim() && event.currentTarget.value.trim() !== frame.title) data.onRename(frame.id, event.currentTarget.value); }}
        onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }} />
      <span className="board-frame-count">{frame.members.length} {text("board_frame_members")}</span>
      {data.writesEnabled ? <button type="button" className="notice-link board-frame-remove nodrag" title={text("board_frame_remove_help")} onClick={() => data.onRemove(frame.id)}>{text("board_frame_remove")}</button> : null}
    </div>
  </div>;
}

const nodeTypes = { owner: OwnerNode, role: RoleNode, frame: FrameNode };

export type ProjectBoardProps = {
  onOpenProjectChat: () => void;
  session: AgentBoardSession;
  active: boolean; library: LibraryState; onChanged: () => void; onConfigureChild: (agentId: string) => void;
  api: WorkApi; locale: Locale; text: Text; rolesReady: boolean; roles: readonly RoleOption[]; tracker: TrackerViewState; writesEnabled: boolean;
  /** Bumped by the shell after any confirmed write so the graph is re-read. */
  refreshKey: number;
  selectedTaskId: string | null;
  onOpenTasks: (agentId: string) => void;
  onGiveTask: (agentId: string) => void;
  onAddDepartment: () => void;
  /** A blueprint application the shell just confirmed; the board frames it once and reports back. */
  pendingApplication: { application: BlueprintApplication; title: string } | null;
  onApplicationPlaced: () => void;
  hirePanel: ReactNode; hireOpen: boolean; onHireOpenChange: (open: boolean) => void;
};

export function ProjectBoard(props: ProjectBoardProps): ReactElement {
  return <ReactFlowProvider><BoardCanvas {...props} /></ReactFlowProvider>;
}

function BoardCanvas({ onOpenProjectChat, session, active, library, onChanged, onConfigureChild, api, text, rolesReady, roles, tracker, writesEnabled, refreshKey, selectedTaskId, onOpenTasks, onGiveTask, onAddDepartment, pendingApplication, onApplicationPlaced, hirePanel, hireOpen, onHireOpenChange }: ProjectBoardProps): ReactElement {
  const flow = useReactFlow();
  const nodesInitialized = useNodesInitialized();
  const [fitRequested, setFitRequested] = useState(session.viewport === null);
  const fitPending = useRef(fitRequested);
  const requestFit = useCallback(() => { fitPending.current = true; setFitRequested(true); }, []);
  useSyncExternalStore(session.subscribe, session.snapshot);
  const [visited, setVisited] = useState(active || session.visited);
  useEffect(() => { if (active) { session.visited = true; setVisited(true); } }, [active, session]);
  const [showCommunication, setShowCommunication] = useState(false);
  const [showCreators, setShowCreators] = useState(false);
  const [settings, setSettings] = useState<{ id: string; tab: AgentTab } | null>(null);
  const { connection, linkState } = session;
  const setConnection = session.setConnection.bind(session);
  const setLinkState = session.setLinkState.bind(session);
  const [connectionOpen, setConnectionOpen] = useState(false);
  const configure = useCallback((id: string, tab: AgentTab) => { session.editor(api, id); setSettings({ id, tab }); }, [api, session]);

  const [graph, setGraph] = useState<BoardGraph | null>(null);
  const [layout, setLayout] = useState<BoardLayout>(EMPTY_LAYOUT);
  const [loadState, setLoadState] = useState<"loading" | "ready" | "failed">("loading");
  const [status, setStatus] = useState<MessageKey | null>(null);
  const layoutRef = useRef(layout);
  layoutRef.current = layout;
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Read the role structure and the arrangement; a failed read never invents either.
  useEffect(() => {
    const controller = new AbortController();
    setLoadState("loading");
    void (async () => {
      try {
        const [graphValue, layoutValue] = await Promise.all([api.readGraph(controller.signal), api.readBoardLayout(controller.signal)]);
        if (controller.signal.aborted) return;
        setGraph(parseBoardGraph(graphValue));
        setLayout(parseBoardLayout(layoutValue));
        setLoadState("ready");
      } catch (error) {
        if (controller.signal.aborted) return;
        setLoadState("failed");
      }
    })();
    return () => controller.abort();
  }, [api, refreshKey]);

  const persist = useCallback((next: BoardLayout) => {
    setLayout(next);
    if (!writesEnabled) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      saveTimer.current = null;
      const controller = new AbortController();
      setStatus("board_saving");
      const started = performance.now();
      void (async () => {
        try {
          const saved = parseBoardLayout(await api.writeBoardLayout(layoutBody(layoutRef.current), controller.signal));
          // The server revision is the only revision; positions from the reply are what was stored.
          setLayout((current) => ({ ...current, revision: saved.revision }));
          setStatus("board_saved");
          recordInstrumentation("board_edit", "confirmed", performance.now() - started);
        } catch (error) {
          recordInstrumentation("board_edit", requestOutcome(error), performance.now() - started);
          if (error instanceof ApiProblem && error.apiError?.code === "board_revision_conflict") setStatus("board_layout_conflict");
          else if (error instanceof ApiProblem || error instanceof BoardError) setStatus("board_layout_save_failed");
          else setStatus("board_layout_save_failed");
        }
      })();
    }, 600);
  }, [api, writesEnabled]);

  // A confirmed blueprint application becomes a department frame exactly once.
  useEffect(() => {
    if (!pendingApplication || loadState !== "ready") return;
    persist(addFrame(layoutRef.current, frameForApplication(pendingApplication.application, pendingApplication.title, layoutRef.current)));
    onApplicationPlaced();
  }, [pendingApplication, loadState, persist, onApplicationPlaced]);

  const model = useMemo(() => buildBoardModel(roles, graph, tracker, layout), [roles, graph, tracker, layout]);

  const handlers = useMemo(() => ({
    rename: (frameId: string, title: string) => persist(renameFrame(layoutRef.current, frameId, title)),
    remove: (frameId: string) => persist(removeFrame(layoutRef.current, frameId))
  }), [persist]);

  const derivedNodes = useMemo((): BoardNode[] => [
    { id: OWNER_NODE_ID, type: "owner", position: model.ownerPosition, draggable: false, selectable: false, connectable: false, data: { text, onOpenChat: onOpenProjectChat } },
    ...model.frames.map((frame): FrameFlowNode => ({
      id: frame.id, type: "frame", position: { x: frame.x, y: frame.y }, width: frame.width, height: frame.height, zIndex: -1, selectable: true, draggable: writesEnabled,
      data: { frame, text, writesEnabled, onRename: handlers.rename, onRemove: handlers.remove }
    })),
    ...model.nodes.map((role): RoleFlowNode => ({
      id: role.id, type: "role", position: role.position, draggable: writesEnabled,
      data: { role, text, writesEnabled, canGiveTask: selectedTaskId !== null, onOpenTasks, onGiveTask, onConfigure: configure, onChild: onConfigureChild,
        ...roleCardCopy(role.name, library.kind === "ready" ? library.catalog.roles.find((r) => r.ref.id === role.specialization) : undefined),
        supervisorName: roles.find((r) => r.id === role.supervisorId)?.name ?? null }

    }))
  ], [model, text, writesEnabled, selectedTaskId, onOpenTasks, onGiveTask, handlers, configure, onConfigureChild, library, roles, onOpenProjectChat]);

  const [nodes, setNodes] = useState<BoardNode[]>(derivedNodes);
  useEffect(() => { setNodes((current) => derivedNodes.map((node) => ({ ...node, selected: current.find((old) => old.id === node.id)?.selected ?? false }))); }, [derivedNodes]);

  // Fit only once the async graph, saved positions and measured cards agree.
  // Subsequent refreshes and project/tab restores keep the operator's viewport.
  useEffect(() => {
    if (!fitRequested || !active || loadState !== "ready" || !rolesReady || !nodesInitialized) return;
    if (nodes.length !== derivedNodes.length || nodes.some((node, index) => {
      const expected = derivedNodes[index];
      return node.id !== expected.id || node.position.x !== expected.position.x || node.position.y !== expected.position.y;
    })) return;
    const frame = requestAnimationFrame(() => {
      if (!fitPending.current) return;
      void flow.fitView({ padding: 0.2 }).then((fitted) => {
        if (!fitted || !fitPending.current) return;
        fitPending.current = false; setFitRequested(false);
        session.setViewport(flow.getViewport());
      });
    });
    return () => cancelAnimationFrame(frame);
  }, [active, loadState, rolesReady, nodesInitialized, nodes, derivedNodes, fitRequested, flow, session]);

  const edges = useMemo((): Edge[] => [
    ...model.ownerMembers.map((id) => ({ id: `owner|${id}`, source: OWNER_NODE_ID, target: id, className: "board-edge-membership", type: "smoothstep", label: text("owner_membership") })),
    ...model.supervisedBy.map((edge) => ({ id: `supervisor|${edge.from}|${edge.to}`, source: edge.to, target: edge.from, className: "board-edge-supervisor", type: "smoothstep", label: text("agent_supervisor") })),
    ...(showCreators ? model.reportsTo : []).map((edge) => ({ id: `reports|${edge.from}|${edge.to}`, source: edge.to, target: edge.from, className: "board-edge-reports", type: "smoothstep", label: text("agent_creator") })),
    ...(showCommunication ? model.links : []).map((link) => ({ id: link.id, source: link.from, target: link.to, className: "board-edge-link", type: "smoothstep", label: text(link.allowedAction === "handoff_work" ? "agent_link_handoff" : "agent_link_ask") }))
  ], [model, text, showCreators, showCommunication]);

  const onNodesChange = useCallback((changes: NodeChange<BoardNode>[]) => setNodes((current) => applyNodeChanges(changes, current)), []);

  const onNodeDragStop = useCallback((_: unknown, node: BoardNode) => {
    if (!writesEnabled || node.type === "owner") return;
    persist(node.type === "frame" ? moveFrame(layoutRef.current, node.id, node.position) : moveRole(layoutRef.current, node.id, node.position));
  }, [persist, writesEnabled]);

  const onConnect = useCallback((value: Connection) => {
    if (!writesEnabled || !value.source || !value.target || value.source === value.target || value.source === OWNER_NODE_ID || value.target === OWNER_NODE_ID) return;
    setConnectionOpen(true);
    if (connection && ["uncertain", "saving", "saved_refresh_failed"].includes(linkState)) return;
    setConnection({ source: value.source, target: value.target, kind: "ask", key: crypto.randomUUID(), confirmed: false }); setLinkState("idle");
  }, [writesEnabled, connection, linkState]);
  async function saveConnection(): Promise<void> {
    if (!connection || linkState === "saving") return;
    setLinkState("saving");
    const request = connection;
    try {
      if (!request.confirmed) { await api.openAgentLink({ fromAgentId: request.source, toAgentId: request.target, allowedAction: request.kind, reason: text("board_link_reason") }, new AbortController().signal, request.key); request.confirmed = true; }
    } catch (error) { setLinkState(requestOutcome(error) === "uncertain" ? "uncertain" : "failed"); return; }
    try { setGraph(parseBoardGraph(await api.readGraph(new AbortController().signal))); setConnection(null); setLinkState("idle"); setShowCommunication(true); onChanged(); }
    catch { setLinkState("saved_refresh_failed"); }
  }

  const relayout = useCallback(() => { persist(resetPositions(layoutRef.current)); requestFit(); }, [persist, requestFit]);

  return <div className="board-section">
    <div className="board-toolbar">

      <div className="board-toolbar-actions">
        {connection && !connectionOpen ? <button type="button" className="button button-secondary" onClick={() => setConnectionOpen(true)}>{text("agent_pending_connection")}</button> : null}
        <button type="button" className="button button-primary button-inline" disabled={!writesEnabled} title={text("board_hire_help")} onClick={() => onHireOpenChange(!hireOpen)} aria-expanded={hireOpen}>{text("board_hire")}</button>
        <button type="button" className="button button-secondary button-inline" disabled={!writesEnabled} title={text("board_department_help")} onClick={onAddDepartment}>{text("board_add_department")}</button>
        <button type="button" className="button button-secondary button-inline" title={text("board_fit_help")} onClick={requestFit}>{text("board_fit")}</button>
        <button type="button" className="button button-secondary button-inline" disabled={!writesEnabled} title={text("board_relayout_help")} onClick={relayout}>{text("board_relayout")}</button>
      </div>
    <details className="board-accessible-list"><summary title={text("board_list_help")}>{text("agent_list")}</summary><ul>{model.nodes.map((role) => <li key={role.id}><button className="notice-link" type="button" onClick={() => configure(role.id, "general")}>{role.name}</button> · {text(`board_activity_${role.activity}` as MessageKey)}</li>)}</ul></details>
    <details className="board-layers"><summary title={text("board_layers_help")}>{text("board_relations")}</summary><div><p>{text("board_hierarchy_help")}</p><label><input type="checkbox" checked={showCommunication} onChange={(event) => setShowCommunication(event.target.checked)} />{text("board_show_communication")}</label><label><input type="checkbox" checked={showCreators} onChange={(event) => setShowCreators(event.target.checked)} />{text("board_show_creators")}</label></div></details>
    </div>
    {loadState !== "ready" || status ? <p className="board-status" role="status">{loadState === "loading" ? text("board_loading") : loadState === "failed" ? text("board_unavailable") : status ? text(status) : null}</p> : null}

    <div className="board-body">
      <div className="board-canvas" aria-label={text("shell_nav_board")}>
        {active || visited ? <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes} onNodesChange={onNodesChange} onNodeDragStop={onNodeDragStop} onConnect={onConnect} onEdgeClick={(_, edge) => { if (edge.source === OWNER_NODE_ID) return; configure(edge.className === "board-edge-link" ? edge.source : edge.target, edge.className === "board-edge-link" ? "connections" : "general"); }}
          ariaLabelConfig={{ "controls.ariaLabel": text("task_graph.zoom"), "controls.zoomIn.ariaLabel": text("task_graph.zoomIn"), "controls.zoomOut.ariaLabel": text("task_graph.zoomOut"), "controls.fitView.ariaLabel": text("board_fit") }}
          defaultViewport={session.viewport ?? undefined} fitView={false} onMove={(event, viewport) => {
            if (event) { fitPending.current = false; setFitRequested(false); }
            if (!fitPending.current) session.setViewport(viewport);
          }}
          panOnScroll zoomOnScroll={false} zoomOnPinch minZoom={0.2} maxZoom={1.6} nodesConnectable={writesEnabled} elementsSelectable proOptions={{ hideAttribution: true }} deleteKeyCode={null}>
          <Background gap={24} />
          <Controls showInteractive={false} />

        </ReactFlow> : null}
        {loadState === "ready" && model.nodes.length === 0 ? <div className="board-empty"><p>{text("board_empty")}</p></div> : null}
      </div>
      {hireOpen ? <Modal title={text("shell_board_hire_title")} closeLabel={text("shell_close")} onClose={() => onHireOpenChange(false)}>{hirePanel}</Modal> : null}
      {active && settings ? <AgentSettings key={settings.id} session={session.editor(api, settings.id)} initialTab={settings.tab} text={text} roles={roles} writesEnabled={writesEnabled} onClose={() => setSettings(null)} onChanged={onChanged} /> : null}
      {active && connection && connectionOpen ? <Modal size="small" title={text("agent_open_link")} closeLabel={text("shell_close")} onClose={() => setConnectionOpen(false)}>
        <p>{roles.find((r) => r.id === connection.source)?.name} → {roles.find((r) => r.id === connection.target)?.name}</p>
        <label>{text("agent_link_type")}<select disabled={linkState !== "idle"} value={connection.kind} onChange={(e) => setConnection({ ...connection, kind: e.target.value as "ask" | "handoff_work" })}><option value="ask">{text("agent_link_ask")}</option><option value="handoff_work">{text("agent_link_handoff")}</option></select></label>
        <p className="small-copy">{text(connection.kind === "handoff_work" ? "agent_link_handoff_warning" : "agent_link_help")}</p>
        <p role="status">{linkState === "uncertain" ? text("agent_uncertain") : linkState === "failed" ? text("agent_failed") : linkState === "saved_refresh_failed" ? text("agent_saved_refresh_failed") : ""}</p>
        <button type="button" className="button button-primary" disabled={linkState === "saving" || !writesEnabled} onClick={() => void saveConnection()}>{text(connection.confirmed ? "refresh_status" : linkState === "idle" ? "agent_open_link" : "agent_retry_same")}</button>
      </Modal> : null}
    </div>
  </div>;
}
