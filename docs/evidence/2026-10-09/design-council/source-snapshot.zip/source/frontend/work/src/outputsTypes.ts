export type OutputScope = Readonly<{ kind: "task" | "agent"; id: string }>;
export type OutputVersions = "latest" | "all";
export type OutputState = "unchecked" | "ready" | "stale" | "unavailable";
/** Server-derived review standing of the producing task; never inferred here. */
export type ReviewState = "awaiting" | "approved" | "returned";
export type OutputProvenance = Readonly<{
  taskId: string; taskRevision: string; producerAgentId: string | null;
  producerSessionId: string | null; producerDelegationId: string | null; delegationRevision: string | null;
}>;
export type ImageOutput = OutputProvenance & Readonly<{
  kind: "design_image" | "artifact_image" | "static_build" | "text_result";
  outputId: string; title: string; artifactId: string; artifactRevision: string; contentRevision: string;
  recordedAt: string | null; packageId: string | null; packageRevision: string | null; screenId: string | null;
  state: OutputState; reason: string | null; mediaType: "image/png" | "image/jpeg" | "application/zip" | "text/plain; charset=utf-8";
  summary?: string; checks?: readonly string[];
  latest: boolean; versionCount: number; width: number | null; height: number | null;
  historicalPreviewVerified?: boolean; retained?: boolean; resultReviewState?: ReviewState | null; reviewState: ReviewState | null;
}>;
export type OutputList = Readonly<{ scope: OutputScope; versions: OutputVersions; items: readonly (ImageOutput | LiveOutput)[] }>;
export type OutputSummary = Readonly<{ scope: OutputScope; total: number; unchecked: number; stale: number; unavailable: number }>;
export class OutputsError extends Error { constructor() { super("outputs_unavailable"); } }
const ID = "[0-7][0-9A-HJKMNP-TV-Z]{25}";
const SESSION = /^session\.(?:[a-f0-9]{32}|[0-7][0-9A-HJKMNP-TV-Z]{25})$/;
const DIGEST = /^sha256:[a-f0-9]{64}$/;
const REASONS = new Set([
  "package_revision_superseded", "artifact_revision_changed", "producer_task_revision_changed",
  "artifact_binding_changed", "producer_provenance_missing", "output_preview_unsupported",
  "verified_preview_changed", "output_preview_unavailable", "artifact_preview_invalid_id",
  "artifact_preview_not_found", "artifact_preview_manifest_invalid", "artifact_preview_classification_blocked",
  "artifact_preview_unsupported_media_type", "artifact_preview_missing_source", "artifact_preview_symlink_source",
  "artifact_preview_non_regular_source", "artifact_preview_stale_source", "artifact_preview_oversize",
  "artifact_preview_invalid_image", "artifact_preview_pixel_limit",
]);
function fail(): never { throw new OutputsError(); }
function object(value: unknown): Record<string, unknown> { return typeof value === "object" && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : fail(); }
function keys(value: Record<string, unknown>, expected: string, optional = ""): void {
  const names = expected.split(" "), allowed = new Set(optional ? [...names, ...optional.split(" ")] : names);
  if (names.some((name) => !(name in value)) || Object.keys(value).some((name) => !allowed.has(name))) fail();
}
/** An older server, a null, or a value this build does not know all mean "no review label". */
function reviewState(value: unknown): ReviewState | null {
  return value === "awaiting" || value === "approved" || value === "returned" ? value : null;
}
function id(value: unknown, kind: string): string { return typeof value === "string" && new RegExp(`^${kind}\\.${ID}$`).test(value) ? value : fail(); }
function count(value: unknown): number { return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : fail(); }
function text(value: unknown, limit = 256): string { return typeof value === "string" && value.length > 0 && value.length <= limit && !/[\x00-\x1f\x7f\u202a-\u202e\u2066-\u2069]/.test(value) ? value : fail(); }
export function scopeKey(scope: OutputScope): string { if (scope.kind !== "task" && scope.kind !== "agent") fail(); return `${scope.kind}:${id(scope.id, scope.kind)}`; }
function parseScope(value: unknown, expected: OutputScope): OutputScope {
  const row = object(value); keys(row, "kind id");
  if (row.kind !== expected.kind || row.id !== expected.id) fail();
  scopeKey(expected); return { kind: expected.kind, id: expected.id };
}
export function parseOutputSummary(value: unknown, expected: OutputScope): OutputSummary {
  const row = object(value); keys(row, "schema scope versions total counts previews_verified");
  if (row.schema !== "agent_commons.outputs-summary.v1" || row.versions !== "latest" || row.previews_verified !== false) fail();
  const counts = object(row.counts); keys(counts, "unchecked stale unavailable");
  const total = count(row.total), unchecked = count(counts.unchecked), stale = count(counts.stale), unavailable = count(counts.unavailable);
  if (total !== unchecked + stale + unavailable) fail();
  return { scope: parseScope(row.scope, expected), total, unchecked, stale, unavailable };
}
export function parseOutputList(value: unknown, expected: OutputScope, versions: OutputVersions): OutputList {
  const row = object(value); keys(row, "schema scope versions items truncated");
  if (row.schema !== "agent_commons.outputs.v1" || row.versions !== versions || row.truncated !== false || !Array.isArray(row.items) || row.items.length > 64) fail();
  const scope = parseScope(row.scope, expected), seen = new Set<string>();
  const items = row.items.map((raw): ImageOutput | LiveOutput => {
    const item = object(raw);
    if (item.kind === "live_preview") {
      const live = parseLive(item, scope, versions);
      if (seen.has(live.outputId)) fail();
      seen.add(live.outputId); return live;
    }
    if (item.kind === "design_image") {
      keys(item, "kind output_id series_id title package_id package_revision screen_id artifact_id artifact_revision content_revision task_id task_revision producer_session_id producer_agent_id producer_delegation_id recorded_at media_type classification state reason latest version_count width height", "review_state result_review_state retained");
      const packageId = id(item.package_id, "design_package"), packageRevision = id(item.package_revision, "evt"), screenId = id(item.screen_id, "screen");
      if (item.output_id !== `${packageId}@${packageRevision}:${screenId}` || item.series_id !== `${packageId}:${screenId}`) fail();
    } else if ((item.kind === "artifact_image" || item.kind === "static_build" || item.kind === "text_result")) {
      keys(item, "kind output_id series_id title artifact_id artifact_revision content_revision task_id task_revision producer_session_id producer_agent_id producer_delegation_id delegation_revision recorded_at media_type classification state reason latest version_count width height historical_preview_verified", item.kind === "text_result" ? "review_state result_review_state retained summary checks" : "review_state result_review_state retained");
      if (item.kind === "text_result") { reportProse(item.summary, 4096); reportChecks(item.checks); }
      if (item.output_id !== `${id(item.artifact_id, "artifact")}@${id(item.artifact_revision, "evt")}` || typeof item.series_id !== "string" || !/^generated\.[a-f0-9]{64}$/.test(item.series_id)) fail();
      if (typeof item.historical_preview_verified !== "boolean" || (item.historical_preview_verified && (item.state !== "stale" || item.reason !== "producer_task_revision_changed"))) fail();
      id(item.delegation_revision, "evt"); id(item.producer_agent_id, "agent"); id(item.producer_delegation_id, "delegation");
      if (typeof item.producer_session_id !== "string" || !SESSION.test(item.producer_session_id)) fail();
    } else fail();
    if (typeof item.output_id !== "string" || seen.has(item.output_id)) fail();
    id(item.artifact_revision, "evt"); id(item.task_revision, "evt"); id(item.task_id, "task");
    for (const [field, kind] of [["producer_session_id", "session"], ["producer_agent_id", "agent"], ["producer_delegation_id", "delegation"]]) if (item[field] !== null) {
      if (kind === "session") { if (typeof item[field] !== "string" || !SESSION.test(item[field] as string)) fail(); }
      else id(item[field], kind);
    }
    if ((scope.kind === "task" && item.task_id !== scope.id) || (scope.kind === "agent" && item.producer_agent_id !== scope.id)) fail();
    if (typeof item.content_revision !== "string" || !DIGEST.test(item.content_revision) || !["public", "internal"].includes(item.classification as string)) fail();
    if (item.kind === "text_result" ? item.media_type !== "text/plain; charset=utf-8" || item.retained !== true : item.kind === "static_build" ? item.media_type !== "application/zip" || item.retained !== true : item.media_type !== "image/png" && item.media_type !== "image/jpeg") fail();
    if (item.retained !== undefined && typeof item.retained !== "boolean") fail();
    if (!["unchecked", "ready", "stale", "unavailable"].includes(item.state as string) || typeof item.latest !== "boolean" || (versions === "latest" && !item.latest)) fail();
    if (item.reason !== null && (typeof item.reason !== "string" || !REASONS.has(item.reason))) fail();
    if (item.recorded_at !== null && (typeof item.recorded_at !== "string" || !Number.isFinite(Date.parse(item.recorded_at)) || item.recorded_at.length > 64)) fail();
    const width = item.width === null ? null : count(item.width), height = item.height === null ? null : count(item.height);
    if (item.state === "ready" && (item.reason !== null || ((item.kind === "static_build" || item.kind === "text_result") ? width !== null || height !== null : !width || !height || width * height > 16_000_000))) fail();
    if (item.state !== "ready" && (width !== null || height !== null)) fail();
    const versionCount = count(item.version_count); if (!versionCount) fail();
    seen.add(item.output_id as string);
    return { taskId: item.task_id as string, taskRevision: item.task_revision as string, producerAgentId: item.producer_agent_id as string | null,
      producerSessionId: item.producer_session_id as string | null, producerDelegationId: item.producer_delegation_id as string | null,
      delegationRevision: item.kind !== "design_image" ? item.delegation_revision as string : null,
      artifactRevision: item.artifact_revision as string, recordedAt: item.recorded_at as string | null,
      packageId: item.kind === "design_image" ? item.package_id as string : null, packageRevision: item.kind === "design_image" ? item.package_revision as string : null, screenId: item.kind === "design_image" ? item.screen_id as string : null,
      kind: item.kind, outputId: item.output_id as string, title: text(item.title), artifactId: id(item.artifact_id, "artifact"), contentRevision: item.content_revision,
      state: item.state as OutputState, reason: item.reason as string | null, mediaType: item.media_type as ImageOutput["mediaType"], latest: item.latest,
      versionCount, width, height, historicalPreviewVerified: item.kind !== "design_image" && item.historical_preview_verified === true,
      ...(item.kind === "text_result" ? { summary: reportProse(item.summary, 4096), checks: reportChecks(item.checks) } : {}),
      retained: item.retained === true, resultReviewState: reviewState(item.result_review_state), reviewState: reviewState(item.review_state) };
  });
  return { scope, versions, items };
}


export type LiveOutput = OutputProvenance & Readonly<{
  kind: "live_preview"; outputId: string; title: string; url: string | null; origin: string;
  publishedAt: number; expiresAt: number; reportedState: "starting" | "ready" | "unavailable";
  state: "starting" | "reported_ready" | "unavailable" | "expired" | "stale";
  latest: boolean; versionCount: number;
}>;
function liveOrigin(value: unknown): string {
  if (typeof value !== "string" || !/^http:\/\/(?:127\.0\.0\.1|\[::1\]):[1-9][0-9]{0,4}$/.test(value)) fail();
  const port = Number(new URL(value).port); if (port < 1024 || port > 65535) fail();
  return value;
}
function parseLive(item: Record<string, unknown>, scope: OutputScope, versions: OutputVersions): LiveOutput {
  keys(item, "kind output_id title task_id task_revision producer_agent_id producer_session_id producer_delegation_id delegation_revision url origin published_at expires_at reported_state state reachability latest version_count");
  if (typeof item.output_id !== "string" || !/^preview\.[a-f0-9]{32}$/.test(item.output_id)) fail();
  id(item.task_id, "task"); id(item.task_revision, "evt"); id(item.producer_agent_id, "agent");
  id(item.producer_delegation_id, "delegation"); id(item.delegation_revision, "evt");
  if (typeof item.producer_session_id !== "string" || !SESSION.test(item.producer_session_id)) fail();
  if ((scope.kind === "task" ? item.task_id : item.producer_agent_id) !== scope.id) fail();
  const origin = liveOrigin(item.origin);
  if (!["starting", "ready", "unavailable"].includes(item.reported_state as string) || !["starting", "reported_ready", "unavailable", "expired", "stale"].includes(item.state as string) || item.reachability !== "unknown") fail();
  if (typeof item.latest !== "boolean" || (versions === "latest" && !item.latest) || !count(item.version_count)) fail();
  if (item.state === "reported_ready" ? item.reported_state !== "ready" || item.url !== origin + "/" || !item.latest : item.url !== null) fail();
  if (typeof item.published_at !== "string" || typeof item.expires_at !== "string" || item.published_at.length > 40 || item.expires_at.length > 40) fail();
  const publishedAt = Date.parse(item.published_at), expiresAt = Date.parse(item.expires_at);
  if (!Number.isFinite(publishedAt) || !Number.isFinite(expiresAt) || expiresAt - publishedAt < 60_000 || expiresAt - publishedAt > 3_600_000) fail();
  return { taskId: item.task_id as string, taskRevision: item.task_revision as string, producerAgentId: item.producer_agent_id as string,
    producerSessionId: item.producer_session_id as string, producerDelegationId: item.producer_delegation_id as string, delegationRevision: item.delegation_revision as string,
    kind: "live_preview", outputId: item.output_id, title: text(item.title, 160), url: item.url as string | null, origin, publishedAt, expiresAt,
    reportedState: item.reported_state as LiveOutput["reportedState"], state: item.state as LiveOutput["state"], latest: item.latest, versionCount: item.version_count as number };
}
/** New-tab navigation is rechecked at render and click, without a network probe. */
export function liveNavigation(item: LiveOutput, now: number, uiOrigin: string): string | null {
  if (item.state !== "reported_ready" || now >= item.expiresAt || !item.latest) return null;
  try {
    if (liveOrigin(item.origin) + "/" !== item.url || new URL(uiOrigin).port === new URL(item.origin).port) return null;
    return item.url;
  } catch { return null; }
}

/** Viewing exact verified pixels never promotes historical task output to current readiness. */
export function canViewImage(item: ImageOutput): boolean {
  return (item.kind === "design_image" || item.kind === "artifact_image") && (item.state === "ready" || (item.kind === "artifact_image" && item.state === "stale" && item.reason === "producer_task_revision_changed" && item.historicalPreviewVerified === true));
}
export function canDownloadBuild(item: ImageOutput): boolean { return item.kind === "static_build" && (item.state === "ready" || item.historicalPreviewVerified === true); }

export type OutputKindFilter = "all" | "images" | "builds" | "reports" | "live";
export function filterOutputs(items: OutputList["items"], filter: OutputKindFilter): OutputList["items"] {
  return filter === "all" ? items : items.filter((item) => filter === "live" ? item.kind === "live_preview" : filter === "builds" ? item.kind === "static_build" : filter === "reports" ? item.kind === "text_result" : item.kind === "design_image" || item.kind === "artifact_image");
}

export function reportProse(value: unknown, limit: number): string {
  if (typeof value !== "string" || new TextEncoder().encode(value).length > limit || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value)) fail();
  return value;
}
export function reportChecks(value: unknown): readonly string[] {
  if (!Array.isArray(value) || value.length > 32) fail();
  return value.map((item) => reportProse(item, 1024));
}
export function canReadReport(item: ImageOutput): boolean {
  return item.kind === "text_result" && (item.state === "ready" || item.historicalPreviewVerified === true);
}
export type TextResultContent = Readonly<{ artifactId: string; artifactRevision: string; contentRevision: string; title: string; summary: string; checks: readonly string[]; content: string; taskId: string; taskRevision: string }>;
export function parseTextResultContent(value: unknown, scope: OutputScope, item: ImageOutput): TextResultContent {
  const row = object(value);
  keys(row, "schema artifact_id artifact_revision content_revision title summary checks content task_id task_revision");
  if (item.kind !== "text_result" || row.schema !== "agent_commons.text-result-content.v1"
    || row.artifact_id !== item.artifactId || row.artifact_revision !== item.artifactRevision || row.content_revision !== item.contentRevision
    || row.task_id !== item.taskId || row.task_revision !== item.taskRevision || row.title !== item.title
    || (scope.kind === "task" ? row.task_id !== scope.id : item.producerAgentId !== scope.id)) fail();
  const summary = reportProse(row.summary, 4096), checks = reportChecks(row.checks);
  if (summary !== item.summary || JSON.stringify(checks) !== JSON.stringify(item.checks)) fail();
  return { artifactId: item.artifactId, artifactRevision: item.artifactRevision, contentRevision: item.contentRevision, title: item.title, summary, checks,
    content: reportProse(row.content, 65536), taskId: item.taskId, taskRevision: item.taskRevision };
}
