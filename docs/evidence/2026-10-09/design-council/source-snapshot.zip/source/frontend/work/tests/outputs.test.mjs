import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { copyFileSync, mkdtempSync, readFileSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { renderToStaticMarkup } from "react-dom/server";
import { createElement } from "react";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const compiled = mkdtempSync(resolve(tmpdir(), "agent-commons-outputs-"));
execFileSync(resolve(root, "node_modules/.bin/tsc"), ["--ignoreConfig", "--target", "ES2022", "--module", "ESNext", "--moduleResolution", "Bundler", "--lib", "ES2022,DOM", "--jsx", "react-jsx", "--resolveJsonModule", "--allowSyntheticDefaultImports", "--outDir", compiled, resolve(root, "src/components/OutputsPanel.tsx"), resolve(root, "src/api.ts")], { cwd: root });
symlinkSync(resolve(root, "node_modules"), resolve(compiled, "node_modules"), "dir");
copyFileSync(resolve(root, "src/i18n.json"), resolve(compiled, "i18n.json"));
const load = (path) => import(pathToFileURL(resolve(compiled, path)).href);
const { OutputsApi, OutputPreviewQueue, outputStatus, presentCurrent, reviewLabel } = await load("outputsApi.js");
const { parseOutputList, parseOutputSummary, OutputsError, canViewImage, filterOutputs } = await load("outputsTypes.js");
const { outputText } = await load("outputsStrings.js");
const { WorkApi } = await load("api.js");
const { OutputsAction, ImagePreviewAction, ReviewStateLine, AgentGalleryAction, OutputAttribution, ImageThumbnail, OutputsPanel } = await load("components/OutputsPanel.js");
const id = (kind, n = "0") => `${kind}.${n.repeat(26)}`;
const scope = { kind: "task", id: id("task") };
const agentScope = { kind: "agent", id: id("agent") };
const summary = (overrides = {}) => ({ schema: "agent_commons.outputs-summary.v1", scope, versions: "latest", total: 1, counts: { unchecked: 1, stale: 0, unavailable: 0 }, previews_verified: false, ...overrides });
const row = (overrides = {}) => ({ kind: "design_image", output_id: `${id("design_package")}@${id("evt")}:${id("screen")}`, series_id: `${id("design_package")}:${id("screen")}`, title: "Home", package_id: id("design_package"), package_revision: id("evt"), screen_id: id("screen"), artifact_id: id("artifact"), artifact_revision: id("evt"), content_revision: `sha256:${"a".repeat(64)}`, task_id: scope.id, task_revision: id("evt"), producer_session_id: id("session"), producer_agent_id: agentScope.id, producer_delegation_id: id("delegation"), recorded_at: "2026-09-08T00:00:00Z", media_type: "image/png", classification: "internal", state: "ready", reason: null, latest: true, version_count: 1, width: 2, height: 3, ...overrides });
const list = (items = [row()], selection = scope, versions = "latest") => ({ schema: "agent_commons.outputs.v1", scope: selection, versions, items, truncated: false });
const deferred = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };
const signal = () => new AbortController().signal;

test("summary counts stay metadata-only and reject mismatched scope or malformed totals", () => {
  assert.equal(parseOutputSummary(summary(), scope).total, 1);
  for (const value of [summary({ scope: agentScope }), summary({ total: 2 }), summary({ previews_verified: true }), summary({ private_path: "not accepted" })]) assert.throws(() => parseOutputSummary(value, scope), OutputsError);
});

test("output parser binds exact producer, series, version, and typed references", () => {
  assert.equal(parseOutputList(list(), scope, "latest").items[0].title, "Home");
  assert.equal(parseOutputList(list([row()], agentScope), agentScope, "latest").items.length, 1);
  for (const changed of [{ task_id: id("task", "1") }, { output_id: "wrong" }, { artifact_id: "artifact/path" }, { classification: "private" }, { latest: false }, { width: 20_000_000 }, { private_path: "not accepted" }, { reason: "raw error text" }]) assert.throws(() => parseOutputList(list([row(changed)]), scope, "latest"), OutputsError);
  assert.throws(() => parseOutputList(list([row({ producer_agent_id: id("agent", "1") })], agentScope), agentScope, "latest"), OutputsError);
  assert.throws(() => parseOutputList(list([row(), row()]), scope, "latest"), OutputsError);
});

test("latest scoped result remains explicitly stale; history never substitutes readiness", () => {
  const stale = row({ state: "stale", reason: "package_revision_superseded", width: null, height: null, version_count: 2 });
  const result = parseOutputList(list([stale]), scope, "latest").items[0];
  assert.equal(result.latest, true); assert.equal(result.state, "stale");
  const historical = parseOutputList(list([row({ ...stale, latest: false })], scope, "all"), scope, "all");
  assert.equal(historical.items[0].latest, false);
});

test("Results entry exists only for actual positive counts and supports both languages", () => {
  for (const count of [null, 0]) assert.equal(renderToStaticMarkup(createElement(OutputsAction, { count, locale: "en", title: "Home", onOpen() {} })), "");
  assert.match(renderToStaticMarkup(createElement(OutputsAction, { count: 2, locale: "en", title: "Home", onOpen() {} })), /Results for Home/);
  assert.match(renderToStaticMarkup(createElement(OutputsAction, { count: 2, locale: "ru", title: "Экран", onOpen() {} })), /Результаты/);
});

test("abort prevents both late successful content and late errors crossing selection boundaries", async () => {
  for (const success of [true, false]) {
    const pending = deferred(), controller = new AbortController(), seen = [];
    const handled = presentCurrent(pending.promise, controller.signal, (value) => seen.push(value), () => seen.push("error"));
    controller.abort(); success ? pending.resolve("old project image") : pending.reject(new Error("old project failure"));
    await handled; assert.deepEqual(seen, []);
  }
});

test("summaries deduplicate and refresh on revision; failed reads can retry", async () => {
  const calls = [];
  const api = new OutputsApi({ readOutputs(...args) { const item = deferred(); calls.push({ args, ...item }); return item.promise; } });
  const first = api.summary(scope, "rev1"), duplicate = api.summary(scope, "rev1");
  assert.equal(first, duplicate); assert.equal(calls.length, 1);
  const second = api.summary(scope, "rev2"); assert.equal(calls[0].args[4].aborted, true);
  calls[0].reject(new Error("old revision")); await assert.rejects(first);
  assert.equal(api.summary(scope, "rev2"), second);
  calls[1].reject(new Error("temporary")); await assert.rejects(second);
  const third = api.summary(scope, "rev2"); calls[2].resolve(summary()); assert.equal((await third).total, 1);
  api.dispose(); assert.equal(calls.length, 3);
});

test("preview requires exact digest plus a still-current scoped record after byte download", async () => {
  const blob = new Blob([new Uint8Array([1, 2, 3])], { type: "image/png" });
  const digest = `sha256:${Buffer.from(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer())).toString("hex")}`;
  const ready = row({ content_revision: digest });
  let response = list([ready]), calls = 0;
  const api = new OutputsApi({ readOutputImage: async () => { calls++; return blob; }, readOutputs: async () => response });
  const item = parseOutputList(response, scope, "latest").items[0];
  assert.equal(await api.preview(scope, item, "latest", signal()), blob);
  response = list([row({ ...ready, state: "stale", reason: "artifact_revision_changed", width: null, height: null })]);
  await assert.rejects(api.preview(scope, item, "latest", signal()), OutputsError);
  response = list([ready]); await assert.rejects(api.preview(scope, { ...item, contentRevision: `sha256:${"f".repeat(64)}` }, "latest", signal()), OutputsError);
  await assert.rejects(api.preview(scope, { ...item, state: "stale" }, "latest", signal()), OutputsError);
  assert.equal(calls, 3);
});

test("output requests and image bytes retain immutable project identity", async () => {
  const previous = globalThis.fetch, calls = [];
  const host = Object.assign(new WorkApi(), { apiBase: "/api/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" });
  const first = host.forProject("project.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"), second = host.forProject("project.bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
  globalThis.fetch = async (url, init) => { calls.push({ url, init }); return url.includes("/preview") ? new Response(new Uint8Array([1]), { headers: { "Content-Type": "image/png" } }) : new Response(JSON.stringify(summary()), { headers: { "Content-Type": "application/json" } }); };
  try {
    await first.readOutputs("task", scope.id, "latest", true, signal());
    await second.readOutputs("agent", agentScope.id, "all", false, signal());
    await first.readOutputImage(id("artifact"), signal());
    assert.match(calls[0].url, /\/projects\/project.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\/outputs\/summary\?scope_kind=task/);
    assert.match(calls[1].url, /\/projects\/project.bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\/outputs\?scope_kind=agent.*versions=all/);
    assert.match(calls[2].url, /\/projects\/project.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\/artifacts\/artifact\./);
    assert.equal(calls[2].init.redirect, "error");
    await assert.rejects(first.readOutputs("task", `${scope.id}?other=1`, "latest", true, signal()));
    await assert.rejects(first.readOutputImage("../config", signal()));
    assert.equal(calls.length, 3);
  } finally { globalThis.fetch = previous; }
});

test("preview transport rejects non-images, empty bytes, declared and streamed oversize", async () => {
  const previous = globalThis.fetch;
  const api = Object.assign(new WorkApi(), { apiBase: "/api/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" });
  try {
    for (const response of [new Response("<svg/>", { headers: { "Content-Type": "image/svg+xml" } }), new Response(new Uint8Array(), { headers: { "Content-Type": "image/png" } }), new Response(new Uint8Array([1]), { headers: { "Content-Type": "image/png", "Content-Length": "10485761" } }), new Response(new Uint8Array(10485761), { headers: { "Content-Type": "image/png" } })]) {
      globalThis.fetch = async () => response;
      await assert.rejects(api.readOutputImage(id("artifact"), signal()));
    }
  } finally { globalThis.fetch = previous; }
});

const liveRow = (overrides = {}) => ({ kind: "live_preview", output_id: `preview.${"a".repeat(32)}`, title: "Frontend", task_id: scope.id, task_revision: id("evt"), producer_agent_id: agentScope.id, producer_session_id: `session.${"b".repeat(32)}`, producer_delegation_id: id("delegation"), delegation_revision: id("evt"), url: "http://127.0.0.1:5173/", origin: "http://127.0.0.1:5173", published_at: "2026-09-08T00:00:00Z", expires_at: "2026-09-08T00:01:00Z", reported_state: "ready", state: "reported_ready", reachability: "unknown", latest: true, version_count: 1, ...overrides });

test("producer session parsing accepts actual UUID session identities without weakening other refs", () => {
  const actual = row({ producer_session_id: `session.${"b".repeat(32)}` });
  assert.equal(parseOutputList(list([actual]), scope, "latest").items[0].kind, "design_image");
  for (const session of ["session.raw-provider-text", `session.${"g".repeat(32)}`, `session.${"b".repeat(32)}?token=x`]) assert.throws(() => parseOutputList(list([row({ producer_session_id: session })]), scope, "latest"), OutputsError);
});

test("live previews are distinct metadata, require scoped producer, and reject URL tricks", () => {
  assert.equal(parseOutputList(list([liveRow()]), scope, "latest").items[0].kind, "live_preview");
  for (const updates of [{ task_id: id("task", "1") }, { producer_session_id: "fake" }, { origin: "http://127.1:5173", url: "http://127.1:5173/" }, { origin: "http://localhost:5173", url: "http://localhost:5173/" }, { url: "http://127.0.0.1:5173/?secret=token" }, { url: "http://127.0.0.1:5173/#secret" }, { reachability: "verified" }, { state: "expired" }, { state: "starting" }, { expires_at: "2026-09-09T00:00:00Z" }, { raw_source: "private" }]) assert.throws(() => parseOutputList(list([liveRow(updates)]), scope, "latest"), OutputsError);
});

test("live navigation expires locally and never links to the control server or an iframe", async () => {
  const { liveNavigation } = await load("outputsTypes.js");
  const { LivePreviewCard } = await load("components/OutputsPanel.js");
  const item = parseOutputList(list([liveRow()]), scope, "latest").items[0], before = item.publishedAt + 10_000;
  assert.equal(liveNavigation(item, before, "http://127.0.0.1:8080"), item.url);
  assert.equal(liveNavigation(item, item.expiresAt, "http://127.0.0.1:8080"), null);
  assert.equal(liveNavigation(item, before, "http://[::1]:5173"), null);
  const markup = renderToStaticMarkup(createElement(LivePreviewCard, { item, locale: "en", now: before, uiOrigin: "http://127.0.0.1:8080" }));
  assert.match(markup, /Publisher reports ready/); assert.match(markup, /Reachability has not been checked/);
  assert.match(markup, /target="_blank"/); assert.match(markup, /rel="noopener noreferrer"/); assert.doesNotMatch(markup, /iframe|<img/);
  const expired = renderToStaticMarkup(createElement(LivePreviewCard, { item, locale: "ru", now: item.expiresAt, uiOrigin: "http://127.0.0.1:8080" }));
  assert.match(expired, /Просмотр истёк/); assert.doesNotMatch(expired, /href=/);
});

test("summary cache expires without canonical changes so runtime advertisements become discoverable", async () => {
  const original = Date.now; let now = 1000, calls = 0;
  Date.now = () => now;
  try {
    const api = new OutputsApi({ readOutputs: async () => { calls++; return summary(); } });
    await api.summary(scope, "same-canonical-revision");
    await api.summary(scope, "same-canonical-revision"); assert.equal(calls, 1);
    now += 15_000; await api.summary(scope, "same-canonical-revision"); assert.equal(calls, 2);
    api.dispose();
  } finally { Date.now = original; }
});


const generatedRow = (overrides = {}) => {
  const { package_id, package_revision, screen_id, ...image } = row();
  return { ...image, kind: "artifact_image", output_id: `${image.artifact_id}@${image.artifact_revision}`, series_id: `generated.${"a".repeat(64)}`, delegation_revision: id("evt"), historical_preview_verified: false, ...overrides };
};
test("generated images retain exact producer boundaries without claiming a Design Package", async () => {
  const blob = new Blob([new Uint8Array([1,2,3])], {type:"image/png"});
  const digest = `sha256:${Buffer.from(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer())).toString("hex")}`;
  const wire = generatedRow({content_revision:digest});
  let response = list([wire]);
  const item = parseOutputList(response, scope, "latest").items[0];
  assert.equal(item.kind, "artifact_image");
  assert.equal(parseOutputList(list([wire],agentScope),agentScope,"latest").items.length,1);
  for (const changed of [{package_id:id("design_package")},{producer_session_id:null},{producer_agent_id:null},{delegation_revision:"wrong"},{series_id:"path/to/file.png"},{task_id:id("task","1")},{output_id:"wrong"}]) {
    assert.throws(()=>parseOutputList(list([generatedRow(changed)]),scope,"latest"),OutputsError);
  }
  const api = new OutputsApi({readOutputImage:async()=>blob,readOutputs:async()=>response});
  assert.equal(await api.preview(scope,item,"latest",signal()),blob);
  response=list([generatedRow({...wire,state:"stale",reason:"artifact_revision_changed",width:null,height:null})]);
  await assert.rejects(api.preview(scope,item,"latest",signal()),OutputsError);
});


test("completed-task recorded images remain stale but exact verified bytes can be viewed", async () => {
  const blob = new Blob([new Uint8Array([1,2,3])], {type:"image/png"});
  const digest = `sha256:${Buffer.from(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer())).toString("hex")}`;
  const wire = generatedRow({state:"stale", reason:"producer_task_revision_changed", width:null, height:null, historical_preview_verified:true, content_revision:digest});
  let response = list([wire]);
  const item = parseOutputList(response, scope, "latest").items[0];
  assert.equal(item.state,"stale"); assert.equal(canViewImage(item),true);
  const api = new OutputsApi({readOutputImage:async()=>blob,readOutputs:async()=>response});
  assert.equal(await api.preview(scope,item,"latest",signal()),blob);
  response = list([generatedRow({...wire,historical_preview_verified:false})]);
  await assert.rejects(api.preview(scope,item,"latest",signal()),OutputsError);
  response = list([wire]);
  await assert.rejects(api.preview(scope,{...item,contentRevision:`sha256:${"f".repeat(64)}`},"latest",signal()),OutputsError);
  for (const changed of [{state:"ready",reason:null,width:2,height:3},{reason:"artifact_preview_stale_source"},{classification:"restricted"},{producer_agent_id:id("agent","1")}]) {
    const selection = changed.producer_agent_id ? agentScope : scope;
    assert.throws(()=>parseOutputList(list([generatedRow({...wire,...changed})],selection),selection,"latest"),OutputsError);
  }
  assert.equal(canViewImage({...item,kind:"design_image"}),false);
  assert.equal(canViewImage({...item,historicalPreviewVerified:false}),false);
});


test("verified task history renders a recorded-image action without implying current readiness", () => {
  const item = parseOutputList(list([generatedRow({state:"stale",reason:"producer_task_revision_changed",historical_preview_verified:true,width:null,height:null})]),scope,"latest").items[0];
  const markup = renderToStaticMarkup(createElement(ImagePreviewAction,{item,locale:"en",onOpen(){}}));
  assert.match(markup,/View recorded image/); assert.match(markup,/does not mark the result current/);
  assert.doesNotMatch(markup,/cannot be previewed|Ready to view/);
  const refused = renderToStaticMarkup(createElement(ImagePreviewAction,{item:{...item,historicalPreviewVerified:false},locale:"en",onOpen(){}}));
  assert.doesNotMatch(refused,/<button/);
  assert.match(renderToStaticMarkup(createElement(ImagePreviewAction,{item:{...item,historicalPreviewVerified:false},locale:"en",onOpen(){}})),/earlier recorded version/);
});


const first = (rows, selection = scope, versions = "latest") => parseOutputList(list(rows, selection, versions), selection, versions).items[0];
const historical = () => generatedRow({ state: "stale", reason: "producer_task_revision_changed", historical_preview_verified: true, width: null, height: null });

test("status labels separate a latest result, a viewable earlier version, and an unusable one", () => {
  assert.equal(outputStatus(first([row()]), 0), "latestResult");
  assert.equal(outputStatus(first([row({ latest: false })], scope, "all"), 0), "earlierViewable");
  assert.equal(outputStatus(first([historical()]), 0), "earlierViewable");
  assert.equal(outputStatus(first([row({ state: "stale", reason: "package_revision_superseded", width: null, height: null })]), 0), "earlierVersion");
  assert.equal(outputStatus(first([row({ state: "unavailable", reason: "output_preview_unsupported", width: null, height: null })]), 0), "previewUnavailable");
  assert.equal(outputStatus(first([row({ state: "unchecked", reason: null, width: null, height: null })]), 0), "previewNotVerified");
  // A historical result never borrows the latest label, in either language.
  const item = first([historical()]);
  for (const locale of ["en", "ru"]) {
    const markup = renderToStaticMarkup(createElement("p", null, outputText(locale, outputStatus(item, 0))));
    assert.notEqual(outputStatus(item, 0), "latestResult");
    assert.doesNotMatch(markup, /Out of date|Устарело/);
  }
  assert.equal(outputText("en", outputStatus(item, 0)), "Earlier version (viewable)");
  assert.equal(outputText("ru", outputStatus(item, 0)), "Прежняя версия (можно посмотреть)");
});

test("live preview status separates local expiry, a reported-unavailable address, and history", () => {
  const ready = first([liveRow()]);
  assert.equal(outputStatus(ready, ready.publishedAt + 10_000), "reported_ready");
  assert.equal(outputStatus(ready, ready.expiresAt), "previewExpired");
  assert.equal(outputStatus(first([liveRow({ reported_state: "starting", state: "starting", url: null })]), 0), "starting");
  assert.equal(outputStatus(first([liveRow({ reported_state: "unavailable", state: "unavailable", url: null })]), 0), "addressUnavailable");
  const stale = first([liveRow({ state: "stale", url: null })]);
  assert.equal(outputStatus(stale, stale.expiresAt + 60_000), "earlierVersion");
  assert.equal(outputText("en", "previewExpired"), "Preview expired");
  assert.equal(outputText("ru", "addressUnavailable"), "Адрес недоступен");
});

test("every status and review label has distinct non-empty copy in both languages", () => {
  const labels = ["latestResult", "earlierViewable", "earlierVersion", "previewExpired", "addressUnavailable", "previewNotVerified", "previewUnavailable", "reviewAwaiting", "reviewApproved", "reviewReturned"];
  for (const locale of ["en", "ru"]) {
    const seen = labels.map((key) => outputText(locale, key));
    for (const value of seen) assert.equal(typeof value === "string" && value.length > 0, true);
    assert.equal(new Set(seen).size, labels.length);
    assert.equal(seen.some((value) => /Out of date|Устарело/.test(value)), false);
  }
  assert.equal(outputText("en", "reviewAwaiting"), "Current task: awaiting check");
  assert.equal(outputText("ru", "reviewAwaiting"), "Текущая задача: ждёт проверки");
  assert.equal(outputText("en", "reviewApproved"), "Current task: check approved");
  assert.equal(outputText("ru", "reviewReturned"), "Текущая задача: возвращена с замечаниями");
});

test("review state is read from the server field only; absent, null and unknown stay neutral", () => {
  const parsed = (overrides) => first([row(overrides)]).reviewState;
  assert.equal(parsed({}), null);
  assert.equal(parsed({ review_state: null }), null);
  for (const unknown of ["under_review", "accepted", "", 7, true, {}]) assert.equal(parsed({ review_state: unknown }), null);
  for (const state of ["awaiting", "approved", "returned"]) assert.equal(parsed({ review_state: state }), state);
  assert.equal(first([generatedRow({ review_state: "approved" })]).reviewState, "approved");
  // Freshness never manufactures a verdict, and unknown keys stay refused.
  assert.equal(parsed({ state: "stale", reason: "producer_task_revision_changed", width: null, height: null }), null);
  assert.equal(first([historical()]).reviewState, null);
  assert.throws(() => parseOutputList(list([row({ review_verdict: "approved" })]), scope, "latest"), OutputsError);
  assert.equal(reviewLabel(null), null);
  assert.deepEqual(["awaiting", "approved", "returned"].map(reviewLabel), ["reviewAwaiting", "reviewApproved", "reviewReturned"]);
});

test("a review label renders in both languages only when the server reported one", () => {
  assert.equal(renderToStaticMarkup(createElement(ReviewStateLine, { state: null, locale: "en" })), "");
  assert.equal(renderToStaticMarkup(createElement(ReviewStateLine, { state: null, locale: "ru" })), "");
  assert.match(renderToStaticMarkup(createElement(ReviewStateLine, { state: "awaiting", locale: "en" })), /Current task: awaiting check/);
  assert.match(renderToStaticMarkup(createElement(ReviewStateLine, { state: "awaiting", locale: "ru" })), /Текущая задача: ждёт проверки/);
  assert.match(renderToStaticMarkup(createElement(ReviewStateLine, { state: "returned", locale: "en" })), /Current task: returned with comments/);
  const approved = renderToStaticMarkup(createElement(ReviewStateLine, { state: "approved", locale: "ru" }));
  assert.match(approved, /Текущая задача: проверка одобрена/);
  assert.match(approved, /class="outputs-review"/);
  assert.doesNotMatch(approved, /style=/);
});

test("output styles stay class-based and reserve green for acceptance elsewhere", () => {
  const css = readFileSync(resolve(root, "src/outputs.css"), "utf8");
  assert.match(css, /\.outputs-review/);
  assert.doesNotMatch(css, /green|#0f0|#00ff00/i);
  assert.doesNotMatch(readFileSync(resolve(root, "src/components/OutputsPanel.tsx"), "utf8"), /style=\{/);
});


test("agent gallery name and avatar are one accessible entry independent of result counts", () => {
  for (const locale of ["en", "ru"]) {
    const markup = renderToStaticMarkup(createElement(AgentGalleryAction, { title: "Designer", locale, onOpen() {} }));
    assert.match(markup, /<button type="button"/);
    assert.match(markup, /aria-haspopup="dialog"/);
    assert.match(markup, /aria-label="[^"]*Designer"/);
    assert.match(markup, /class="board-role-avatar" aria-hidden="true">D/);
    assert.match(markup, /nodrag nowheel/);
    assert.doesNotMatch(markup, /disabled|\(0\)/);
  }
  const profession = renderToStaticMarkup(createElement(AgentGalleryAction, { title: "Frontend · checkout", displayTitle: "Frontend engineer", locale: "en", onOpen() {} }));
  assert.match(profession, /class="board-role-name">Frontend engineer/);
  assert.match(profession, /aria-label="[^"]*Frontend · checkout"/, "the gallery retains the distinct agent identity");
  const board = readFileSync(resolve(root, "src/components/ProjectBoard.tsx"), "utf8");
  assert.match(board, /<AgentGalleryButton scope=\{\{ kind: "agent", id: role.id \}\} title=\{role.name\}/);
  assert.match(board, /<OutputsButton compact scope=\{\{ kind: "agent", id: role.id \}\}/, "compact Results action remains independently reachable without polling counts");
});

test("parser retains validated task and producer attribution across image and live results", () => {
  for (const raw of [row(), generatedRow(), liveRow()]) {
    const item = first([raw]);
    assert.equal(item.taskId, raw.task_id);
    assert.equal(item.taskRevision, raw.task_revision);
    assert.equal(item.producerAgentId, raw.producer_agent_id);
    assert.equal(item.producerSessionId, raw.producer_session_id);
    assert.equal(item.producerDelegationId, raw.producer_delegation_id);
    assert.equal(item.delegationRevision, raw.delegation_revision ?? null);
    if (item.kind !== "live_preview") {
      assert.equal(item.artifactRevision, raw.artifact_revision);
      assert.equal(item.recordedAt, raw.recorded_at);
      assert.equal(item.packageId, raw.package_id ?? null);
      assert.equal(item.packageRevision, raw.package_revision ?? null);
      assert.equal(item.screenId, raw.screen_id ?? null);
    }
  }
});

test("gallery filters retain history and unavailable records without promoting them", () => {
  const rows = parseOutputList(list([row({ latest: false }), liveRow({ state: "stale", url: null, latest: false })], scope, "all"), scope, "all").items;
  assert.equal(filterOutputs(rows, "all"), rows);
  assert.deepEqual(filterOutputs(rows, "images").map((item) => item.kind), ["design_image"]);
  assert.deepEqual(filterOutputs(rows, "live").map((item) => item.kind), ["live_preview"]);
  assert.equal(filterOutputs(rows, "live")[0].state, "stale");
  assert.equal(filterOutputs(rows, "images")[0].latest, false);
  assert.deepEqual(filterOutputs([], "images"), []);
});

test("task and agent names are readable while exact provenance stays in a disclosure", () => {
  const item = first([row()]);
  for (const locale of ["en", "ru"]) {
    const markup = renderToStaticMarkup(createElement(OutputAttribution, { item, locale, onOpenTask() {}, taskTitles: new Map([[scope.id, "Design checkout"]]), agentNames: new Map([[agentScope.id, "Designer"]]) }));
    assert.match(markup, /<button type="button" class="notice-link">Design checkout<\/button>/);
    assert.match(markup, /Designer/);
    assert.match(markup, /<details><summary>/);
    assert.match(markup, /task_revision/);
    assert.match(markup, /producer_agent_id/);
    assert.match(markup, new RegExp(item.taskId.replace(".", "\\.")));
    assert.doesNotMatch(markup, /style=/);
  }
  const unknown = first([row({ producer_agent_id: null, producer_session_id: null, producer_delegation_id: null })]);
  const fallback = renderToStaticMarkup(createElement(OutputAttribution, { item: unknown, locale: "en" }));
  assert.match(fallback, /Producer not provided/);
  assert.doesNotMatch(fallback, /<button|producer_agent_id/);
});

test("preview queue runs at most two checks and cancelled queued cards never request bytes", async () => {
  const queue = new OutputPreviewQueue(), work = [deferred(), deferred(), deferred()], controllers = [new AbortController(), new AbortController(), new AbortController()], started = [];
  let active = 0, maximum = 0;
  const jobs = work.map((job, i) => queue.run(async () => { started.push(i); active++; maximum = Math.max(maximum, active); try { return await job.promise; } finally { active--; } }, controllers[i].signal));
  await Promise.resolve();
  assert.deepEqual(started, [0, 1]);
  controllers[2].abort();
  await assert.rejects(jobs[2], OutputsError);
  work[0].resolve("first"); work[1].resolve("second");
  assert.deepEqual(await Promise.all(jobs.slice(0, 2)), ["first", "second"]);
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(maximum, 2); assert.deepEqual(started, [0, 1]);
  assert.equal(await queue.run(async () => "after cancellation", signal()), "after cancellation");
});

test("preview queue waits for an active aborted transport to settle before starting more bytes", async () => {
  const queue = new OutputPreviewQueue(1), pending = deferred(), controller = new AbortController(), started = [];
  const first = queue.run(async () => { started.push("old"); return pending.promise; }, controller.signal);
  await Promise.resolve(); controller.abort(); await assert.rejects(first, OutputsError);
  const next = queue.run(async () => { started.push("next"); return "new"; }, signal());
  await Promise.resolve(); assert.deepEqual(started, ["old"]);
  pending.resolve("ignored"); assert.equal(await next, "new"); assert.deepEqual(started, ["old", "next"]);
});

test("gallery opens with labelled version and kind filters and an honest loading state", () => {
  const api = new OutputsApi({});
  for (const locale of ["en", "ru"]) {
    const markup = renderToStaticMarkup(createElement(OutputsPanel, { api, scope: agentScope, title: "Designer", locale, revision: "", onClose() {} }));
    assert.match(markup, /<dialog/);
    assert.match(markup, /aria-labelledby=/);
    assert.match(markup, /role="status"/);
    assert.equal((markup.match(/role="group"/g) ?? []).length, 2);
    assert.equal((markup.match(/aria-pressed="true"/g) ?? []).length, 2);
    for (const key of ["history", "allKinds", "images", "liveKinds"]) assert.ok(markup.includes(outputText(locale, key)));
  }
});

test("unverified historical designs never render thumbnail image bytes", () => {
  const item = first([row({ state: "stale", reason: "package_revision_superseded", latest: false, width: null, height: null })], scope, "all");
  const markup = renderToStaticMarkup(createElement(ImageThumbnail, { api: new OutputsApi({}), queue: new OutputPreviewQueue(), scope, versions: "all", item, locale: "en", root: null }));
  assert.match(markup, /Verified image unavailable/);
  assert.doesNotMatch(markup, /<img|src=/);
});

const buildRow = (overrides = {}) => generatedRow({ kind: "static_build", media_type: "application/zip", retained: true, width: null, height: null, result_review_state: null, ...overrides });
test("static build parser keeps retained result identity and never creates an image preview", async () => {
  const { canDownloadBuild } = await load("outputsTypes.js");
  const { BuildDownloadAction } = await load("components/OutputsPanel.js");
  const item = parseOutputList(list([buildRow({ review_state: "approved" })]), scope, "latest").items[0];
  assert.equal(item.reviewState, "approved"); assert.equal(item.resultReviewState, null);
  assert.equal(canViewImage(item), false); assert.equal(canDownloadBuild(item), true);
  assert.equal(filterOutputs([item], "images").length, 0); assert.equal(filterOutputs([item], "builds").length, 1);
  for (const locale of ["en", "ru"]) {
    const html = renderToStaticMarkup(createElement(BuildDownloadAction, { api: {}, scope, item, locale }));
    assert.ok(html.includes(outputText(locale, "downloadBuild")));
    assert.ok(html.includes(outputText(locale, "openLocally")));
    assert.doesNotMatch(html, /<iframe|<img|href=/);
    const unavailable = renderToStaticMarkup(createElement(BuildDownloadAction, { api: {}, scope, item: { ...item, state: "unavailable" }, locale }));
    assert.match(unavailable, /disabled=""/);
  }
  for (const changed of [{ retained: false }, { media_type: "text/html" }, { width: 1 }, { task_id: id("task", "1") }]) assert.throws(() => parseOutputList(list([buildRow(changed)]), scope, "latest"), OutputsError);
});
test("build download verifies hash and scoped freshness, and propagates an honest retryable error", async () => {
  const bytes = new TextEncoder().encode("synthetic zip content"), digest = `sha256:${Buffer.from(await crypto.subtle.digest("SHA-256", bytes)).toString("hex")}`;
  const wire = buildRow({ content_revision: digest });
  let response = list([wire]);
  const transport = { readOutputs: async (_kind, _id, versions) => ({ ...response, versions }), readOutputImage: async () => { throw Error("must not request image bytes"); }, readOutputBuild: async () => new Blob([bytes], { type: "application/zip" }) };
  const api = new OutputsApi(transport), item = parseOutputList(response, scope, "latest").items[0];
  assert.equal((await api.build(scope, item, signal())).size, bytes.length);
  response = list([buildRow({ ...wire, state: "unavailable", reason: "output_preview_unavailable" })], scope, "all");
  await assert.rejects(api.build(scope, item, signal()), OutputsError);
  response = list([wire], scope, "all");
  assert.equal((await api.build(scope, item, signal())).size, bytes.length);
  transport.readOutputBuild = async () => new Blob(["wrong version"], { type: "application/zip" });
  await assert.rejects(api.build(scope, item, signal()), OutputsError);
});

test("build transport retains immutable project scope and rejects HTML, oversize and unsafe identities", async () => {
  const previous = globalThis.fetch, calls = [];
  const host = Object.assign(new WorkApi(), { apiBase: "/api/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" });
  const first = host.forProject("project.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"), second = host.forProject("project.bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
  globalThis.fetch = async (url, init) => { calls.push({ url, init }); return new Response(new Uint8Array([1]), { headers: { "Content-Type": "application/zip" } }); };
  try {
    await first.readOutputBuild(id("artifact"), id("evt"), "task", scope.id, signal());
    await second.readOutputBuild(id("artifact"), id("evt"), "agent", agentScope.id, signal());
    assert.match(calls[0].url, /\/projects\/project.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\/outputs\/builds\/artifact\..*\/evt\..*scope_kind=task/);
    assert.ok(calls[1].url.includes(`/projects/project.${"b".repeat(32)}/outputs/builds/`));
    assert.equal(calls[0].init.redirect, "error"); assert.equal(calls[0].init.credentials, "same-origin");
    for (const response of [new Response("<script/>", { headers: { "Content-Type": "text/html" } }), new Response(new Uint8Array(), { headers: { "Content-Type": "application/zip" } }), new Response(new Uint8Array([1]), { headers: { "Content-Type": "application/zip", "Content-Length": "20971521" } }), new Response(new Uint8Array(20971521), { headers: { "Content-Type": "application/zip" } })]) {
      globalThis.fetch = async () => response;
      await assert.rejects(first.readOutputBuild(id("artifact"), id("evt"), "task", scope.id, signal()));
    }
    await assert.rejects(first.readOutputBuild("../config", id("evt"), "task", scope.id, signal()));
    await assert.rejects(first.readOutputBuild(id("artifact"), "evt.invalid", "task", scope.id, signal()));
    await assert.rejects(first.readOutputBuild(id("artifact"), id("evt"), "task", "task.injected?scope=all", signal()));
  } finally { globalThis.fetch = previous; }
});
