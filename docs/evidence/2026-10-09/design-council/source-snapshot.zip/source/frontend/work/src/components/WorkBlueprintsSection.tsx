import { BlueprintAuthoring } from "./BlueprintAuthoring.js";
import { type FormEvent, type ReactElement, useEffect, useRef, useState } from "react";
import { ApiProblem } from "../api.js";
import {
  blueprintPlanIntent, blueprintStartIntent,
  type BlueprintApplyIntent, type BlueprintApplyOutcome
} from "../blueprintApplyOutcome.js";
import type { Profile } from "../contracts.js";
import { blueprintBriefIsValid, type LibraryApi } from "../libraryApi.js";
import { selectBlueprintProfile, type BlueprintRuntimeChoice } from "../libraryEditorState.js";
import type { Locale, MessageKey } from "../i18n.js";
import type { BlueprintApplication, BlueprintApplyInput, BlueprintBinding, ServiceLibrary, WorkBlueprint } from "../libraryTypes.js";

type ApplyIntent = Readonly<{ id: string; input: BlueprintApplyInput; key: string }>;
type BlueprintSession = {
  selected: WorkBlueprint | null; title: string; brief: string; bindings: BlueprintBinding[];
  defaultRuntime: BlueprintRuntimeChoice; status: "idle" | "applying" | "refused" | "uncertain";
  intent: ApplyIntent | null; result: BlueprintApplication | null; invalid: boolean; code: string;
};
// RAM only. A project switch may unmount this panel without discarding a draft
// or the immutable retry key that describes an uncertain apply.
const sessions = new Map<string, BlueprintSession>();
export function WorkBlueprintsSection({ api, profiles, locale, text, writesEnabled, onApplied, onCount, projectId, catalog }: {
  catalog?: ServiceLibrary; api: LibraryApi; profiles: readonly Profile[]; locale: Locale; text: (key: MessageKey) => string;
  writesEnabled: boolean; onApplied: (application: BlueprintApplication) => void; onCount?: (count: number) => void; projectId?: string | null;
}): ReactElement {
  const sessionKey = projectId ?? "legacy";
  const restored = sessions.get(sessionKey);
  const restoredStatus: "idle" | "applying" | "refused" | "uncertain" = restored?.status === "applying"
    ? "uncertain" : restored?.status ?? "idle";
  const [blueprints, setBlueprints] = useState<readonly WorkBlueprint[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [includeArchived, setIncludeArchived] = useState(false);
  const [selected, setSelected] = useState<WorkBlueprint | null>(() => restored?.selected ?? null);
  const [title, setTitle] = useState(() => restored?.title ?? "");
  const [brief, setBrief] = useState(() => restored?.brief ?? "");
  const [bindings, setBindings] = useState<BlueprintBinding[]>(() => restored?.bindings ?? []);
  const [defaultRuntime, setDefaultRuntime] = useState<BlueprintRuntimeChoice>(() => restored?.defaultRuntime ?? { profile_id: "", model: null });
  const defaultProfile = defaultRuntime.profile_id;
  const defaultModel = defaultRuntime.model ?? "";
  const [status, setStatus] = useState<"idle" | "applying" | "refused" | "uncertain">(() => restoredStatus);
  const [intent, setIntent] = useState<ApplyIntent | null>(() => restored?.intent ?? null);
  const [result, setResult] = useState<BlueprintApplication | null>(() => restored?.result ?? null);
  const [invalid, setInvalid] = useState(() => restored?.invalid ?? false);
  const [code, setCode] = useState(() => restored?.code ?? "");
  const executing = useRef(false);
  const mounted = useRef(true);
  const snapshot = useRef<BlueprintSession | null>(null);
  snapshot.current = { selected, title, brief, bindings, defaultRuntime, status, intent, result, invalid, code };
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; if (snapshot.current) sessions.set(sessionKey, snapshot.current); };
  }, [sessionKey]);
  const locked = status === "applying" || status === "uncertain";
  useEffect(() => {
    const controller = new AbortController(); setLoading(true); setLoadError(false);
    void api.blueprints(controller.signal, includeArchived).then((items) => { if (!controller.signal.aborted) { setBlueprints(items); setLoading(false); onCount?.(items.filter((item) => !item.archived).length); } }).catch(() => { if (!controller.signal.aborted) { setLoadError(true); setLoading(false); } });
    return () => controller.abort();
  }, [api, refresh, onCount, includeArchived]);
  function choose(blueprint: WorkBlueprint): void {
    if (locked || blueprint.contentAvailable === false) return;
    setSelected(blueprint); setTitle(blueprint.name[locale]); setBindings(blueprint.slots.map((slot) => ({ slot_id: slot.id, name: slot.name, profile_id: "", model: null })));
    setStatus("idle"); setIntent(null); setResult(null); setInvalid(false);
  }
  function updateBinding(index: number, change: Partial<BlueprintBinding>): void {
    setBindings((current) => current.map((binding, i) => i === index
      ? change.profile_id === undefined ? { ...binding, ...change } : selectBlueprintProfile({ ...binding, ...change }, change.profile_id)
      : binding)); setStatus("idle"); setIntent(null);
  }
  async function execute(operation: ApplyIntent): Promise<void> {
    if (executing.current) return;
    executing.current = true;
    setStatus("applying"); setCode("");
    if (snapshot.current) {
      const interrupted = { ...snapshot.current, status: "applying" as const, intent: operation };
      snapshot.current = interrupted;
      sessions.set(sessionKey, interrupted);
    }
    try { const application = await api.applyBlueprint(operation.id, operation.input, operation.key, new AbortController().signal); if (!mounted.current) return; setResult(application); setIntent(null); setStatus("idle"); onApplied(application); }
    catch (error: unknown) { if (!mounted.current) return; const problem = error instanceof ApiProblem ? error : null; setIntent(operation); setStatus(problem && problem.status >= 400 && problem.status < 500 ? "refused" : "uncertain"); setCode(problem?.apiError?.code ?? "request_unavailable"); }
    finally { executing.current = false; }
  }
  function submit(event: FormEvent): void {
    event.preventDefault(); if (!selected || !canInspectSelected || !current || selected.contentAvailable === false || selected.archived || locked || executing.current || !writesEnabled) return;
    const valid = title.trim() && title.length <= 128 && blueprintBriefIsValid(brief) && bindings.length === selected.slots.length
      && bindings.every((binding) => binding.name.trim() && binding.name.length <= 128 && profiles.some((profile) => profile.id === binding.profile_id && profile.configured !== false)
        && (binding.model === null || /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/.test(binding.model.trim())));
    setInvalid(!valid); if (!valid) return;
    const operation: ApplyIntent = { id: selected.id, key: crypto.randomUUID(), input: structuredClone({ expected_version: selected.version, title: title.trim(), brief: brief.trim(), locale, bindings: bindings.map((binding) => ({ ...binding, name: binding.name.trim(), model: binding.model?.trim() || null })) }) };
    setIntent(operation); void execute(operation);
  }
  const canInspectSelected = !selected || (!loading && !loadError && blueprints.some((blueprint) => blueprint.id === selected.id && blueprint.contentAvailable !== false));
  const current = !selected || blueprints.some((blueprint) => blueprint.id === selected.id && blueprint.version === selected.version && blueprint.contentAvailable !== false && !blueprint.archived);
  const options = profiles.map((profile) => <option key={profile.id} value={profile.id} disabled={profile.configured === false}>{profile.label}</option>);
  return <section className="work-blueprints" aria-label={text("blueprints_title")}>
    <div className="composer-heading"><div><h2>{text("blueprints_title")}</h2><p className="lead-copy">{text("blueprints_intro")}</p></div><button type="button" className="button button-secondary" onClick={() => setRefresh((value) => value + 1)}>{text("library_refresh")}</button></div>
    <BlueprintAuthoring api={api} catalog={catalog} selected={canInspectSelected ? selected : null} plans={blueprints} text={text} editable={writesEnabled} applying={locked} projectId={projectId} onRefresh={() => setRefresh((value) => value + 1)} />
    <label className="blueprint-archive-toggle"><input type="checkbox" checked={includeArchived} onChange={(event) => setIncludeArchived(event.currentTarget.checked)} />{text("library_show_archived")}</label>
    {loading ? <p role="status">{text("library_loading")}</p> : null}{loadError ? <p className="field-error" role="alert">{text("blueprints_load_error")}</p> : null}
    <div className="blueprint-choice-grid">{blueprints.map((blueprint) => <button className="blueprint-choice" type="button" key={blueprint.id} disabled={locked || blueprint.contentAvailable === false} aria-pressed={selected?.id === blueprint.id} onClick={() => choose(blueprint)}><strong>{blueprint.name[locale]}</strong><span>{blueprint.contentAvailable === false ? text("library_blueprint_content_unavailable") : blueprint.description[locale]}</span><span className="small-copy">{blueprint.slotCount ?? blueprint.slots.length} {text("blueprints_roles_count")} · {blueprint.taskCount ?? blueprint.tasks.length} {text("blueprints_tasks_count")}{blueprint.archived ? ` · ${text("library_blueprint_archived")}` : ""}</span></button>)}</div>
    {selected && !loading && !canInspectSelected ? <p className="notice">{text("library_selection_unavailable")}</p> : null}
    {selected && canInspectSelected ? <div className="blueprint-composer"><h3>{selected.name[locale]}</h3><p>{text("blueprints_preview_help")}</p>
      <ol className="blueprint-task-preview">{selected.tasks.map((task) => <li key={task.id}><strong>{task.title[locale]}</strong><p className="small-copy">{selected.slots.find((slot) => slot.id === task.slot_id)?.name}</p>{task.depends_on.length ? <p className="small-copy">{text("blueprints_after")}: {task.depends_on.map((id) => selected.tasks.find((item) => item.id === id)?.title[locale] ?? id).join(" · ")}</p> : <p className="small-copy">{text("blueprints_start_node")}</p>}</li>)}</ol>
      {!current ? <p className="field-error" role="alert">{text("library_selection_unavailable")}</p> : null}
      <form onSubmit={submit} noValidate><fieldset disabled={!writesEnabled || locked || !current || result !== null}>
        <label htmlFor="blueprint-project-title">{text("blueprints_project_title")}</label><input id="blueprint-project-title" value={title} maxLength={128} onChange={(event) => { setTitle(event.currentTarget.value); setStatus("idle"); setIntent(null); }} />
        <label htmlFor="blueprint-project-brief">{text("blueprints_project_brief")}</label><textarea id="blueprint-project-brief" required rows={5} aria-describedby="blueprint-brief-help" aria-invalid={invalid && !blueprintBriefIsValid(brief)} value={brief} onChange={(event) => { setBrief(event.currentTarget.value); setStatus("idle"); setIntent(null); }} /><p className="small-copy" id="blueprint-brief-help">{text("blueprints_brief_help")} · {[...brief.trim()].length}/4000</p>
        <div className="blueprint-defaults"><h4>{text("blueprints_default_runtime")}</h4><label htmlFor="blueprint-default-profile">{text("role_profile")}</label><select id="blueprint-default-profile" value={defaultProfile} onChange={(event) => { const profileId = event.currentTarget.value; setDefaultRuntime((current) => selectBlueprintProfile(current, profileId)); }}><option value="">{text("select_profile")}</option>{options}</select><label htmlFor="blueprint-default-model">{text("role_model")}</label><input id="blueprint-default-model" value={defaultModel} onChange={(event) => { const model = event.currentTarget.value; setDefaultRuntime((current) => ({ ...current, model: model || null })); }} /><p className="small-copy">{text("blueprints_model_help")}</p><button type="button" className="button button-secondary" disabled={!defaultProfile} onClick={() => { setBindings((current) => current.map((binding) => ({ ...binding, profile_id: defaultProfile, model: defaultModel.trim() || null }))); setStatus("idle"); setIntent(null); }}>{text("blueprints_fill_runtime")}</button></div>
        {bindings.map((binding, index) => <div className="blueprint-binding" key={binding.slot_id}><h4>{selected.slots.find((slot) => slot.id === binding.slot_id)?.name}</h4><p className="small-copy"><code>{selected.slots.find((slot) => slot.id === binding.slot_id)?.role_ref.id}</code></p><label htmlFor={`blueprint-name-${index}`}>{text("role_name")}</label><input id={`blueprint-name-${index}`} value={binding.name} maxLength={128} onChange={(event) => updateBinding(index, { name: event.currentTarget.value })} /><label htmlFor={`blueprint-profile-${index}`}>{text("role_profile")}</label><select id={`blueprint-profile-${index}`} value={binding.profile_id} onChange={(event) => updateBinding(index, { profile_id: event.currentTarget.value })}><option value="">{text("select_profile")}</option>{options}</select><label htmlFor={`blueprint-model-${index}`}>{text("role_model")}</label><input id={`blueprint-model-${index}`} value={binding.model ?? ""} onChange={(event) => updateBinding(index, { model: event.currentTarget.value || null })} /><p className="small-copy">{text("blueprints_model_help")}</p></div>)}
        {invalid ? <p className="field-error" role="alert">{text("blueprints_invalid")}</p> : null}<p className="small-copy">{text("blueprints_apply_help")}</p><button type="submit" className="button button-primary">{text(status === "applying" ? "working" : "blueprints_apply")}</button>
      </fieldset></form>
      {status === "refused" || status === "uncertain" ? <div className="notice" role="alert"><p>{text(status === "uncertain" ? "blueprints_uncertain" : "blueprints_refused")}</p><code>{code}</code>{intent ? <button type="button" className="button button-secondary" disabled={!writesEnabled} onClick={() => void execute(intent)}>{text("blueprints_retry")}</button> : null}</div> : null}
    </div> : null}
  </section>;
}

// The apply outcome is rendered by the shell, which owns the refreshed tracker
// snapshot, navigation and the Prepare run draft. It receives no client, so the
// only effects reachable from a finished apply are the two returned intents.
export function BlueprintApplyOutcomePanel({ outcome, text, onIntent }: {
  outcome: BlueprintApplyOutcome; text: (key: MessageKey) => string;
  onIntent: (intent: BlueprintApplyIntent) => void;
}): ReactElement {
  const start = blueprintStartIntent(outcome);
  return <div className="blueprint-apply-result notice" role="status">
    <h3>{text("blueprints_applied_title")}</h3>
    <p>{text("blueprints_created")}: {outcome.roleCount} {text("blueprints_roles_count")} · {outcome.taskCount} {text("blueprints_tasks_count")}</p>
    <p>{text("blueprints_applied_not_started")}</p>
    <div className="blueprint-apply-actions">
      {start ? <button type="button" className="button button-primary" onClick={() => onIntent(start)}>{text("blueprints_applied_start")}</button> : null}
      <button type="button" className="button button-secondary" onClick={() => onIntent(blueprintPlanIntent(outcome))}>{text("blueprints_applied_view_plan")}</button>
    </div>
    <p className="small-copy">{text(start ? "blueprints_applied_start_help"
      : outcome.nextAction === "no_ready_task" ? "blueprints_applied_no_ready" : "blueprints_applied_unconfirmed")}</p>
  </div>;
}
