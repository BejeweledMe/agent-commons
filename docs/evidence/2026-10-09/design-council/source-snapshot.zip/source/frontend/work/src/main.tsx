import { Modal } from "./components/Modal.js";
import { Icon } from "./components/Icon.js";
import { anyDialogOpen } from "./dialogStack.js";
import { useCompactPane } from "./components/useCompactPane.js";
import { ProjectEnvironment, ProviderQualificationAction } from "./components/ProjectEnvironment.js";
import { ProjectCreation, type FolderPurpose, type FolderSelection } from "./projectCreation.js";
import "./projectCreation.css";
import { ConversationButton, ConversationWorkspace, ProjectChat } from "./components/ConversationPanel.js";
import { ConversationSessions, prepareRunTaskId } from "./conversationState.js";
import type { ConversationScope } from "./conversationApi.js";
import "./conversation.css";
import { OutputsButton, OutputsWorkspace } from "./components/OutputsPanel.js";
import "./outputs.css";
import "@xyflow/react/dist/style.css";
import "./board.css";
import { ProjectBoard } from "./components/ProjectBoard.js";
import { AgentBoardSessions } from "./agentBoardState.js";
import { type FormEvent, type ReactElement, useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";

import { ApiProblem, WorkApi, launchRefusalFromError, requestOutcome } from "./api";
import { ContextPackRetryIdentity } from "./contextPackEditorState";
import { RolePresetPicker } from "./components/RolePresetPicker";
import { chooseRolePreset, chooseRoleProvider } from "./rolePresetState";
import { AppHeader } from "./components/AppHeader";
import { ProjectSidebar } from "./components/ProjectSidebar";
import { FailurePanel } from "./components/FailurePanel";
import { LibrarySection } from "./components/LibrarySection";
import { BlueprintApplyOutcomePanel } from "./components/WorkBlueprintsSection.js";
import { blueprintApplyOutcome, type BlueprintApplyIntent } from "./blueprintApplyOutcome.js";
import { TaskComposer } from "./components/TaskComposer";
import { MutationFeedback } from "./components/MutationFeedback.js";
import { MutationRegistry, mutationSurface } from "./mutationRegistry.js";
import { LaunchRecoveryPanel } from "./components/LaunchRecoveryPanel";
import { StopReasonNotice } from "./components/StopReasonNotice.js";
import { DEFAULT_RUN_LIMIT_MINUTES, MAX_RUN_LIMIT_MINUTES, MIN_RUN_LIMIT_MINUTES, freezeLaunchIntent, launchIntentIsVisible, restoreLaunchDraft, runLimitSeconds, type LaunchIntent, type RunDraft } from "./launchIntentState.js";
import { taskDependencyCatalog } from "./taskDependencyState.js";
import type { TrackerViewState } from "./trackerState.js";
import { isEditingTarget, parseWorkRoute, workRouteHref, type WorkPanel, type WorkRoute } from "./appRouteState";
import { MapViewportStore } from "./mapViewport.js";
import { PaneSeparator } from "./components/PaneSeparator.js";
import {
  CHAT_MAX_WIDTH, CHAT_MIN_WIDTH, DEFAULT_WORKSPACE_LAYOUT, SIDEBAR_MAX_WIDTH, SIDEBAR_MIN_WIDTH,
  WorkspaceLayoutStore, WorkspacePreferenceSync, workspaceShellClasses,
  type LayoutSaveState, type WorkspaceLayout
} from "./workspaceLayout.js";
import { budgetExhaustedRefusal, launchBudgetFromError, parseLaunchBudget, type LaunchBudget, type LaunchBudgetState } from "./launchBudget.js";
import { ProjectDraftStore, ProjectReadRequest, ProjectRegistryApi, ProjectSelection, type ProjectInspection, type ProjectList } from "./projectWorkspace.js";
import { providerReadinessLines, railSetupLabelKey, railSetupState } from "./setupReadiness.js";
import { TrackerSection } from "./components/TrackerSection";
import { InstrumentationSettings } from "./components/InstrumentationSettings.js";
import { InstrumentationBatcher, recordInstrumentation, setInstrumentationSink, type InstrumentationHint, type InstrumentationPostOutcome } from "./instrumentation.js";
import { WorkflowCard } from "./components/WorkflowCard";
import { SpecializationPicker } from "./components/SpecializationPicker.js";
import { WorkerPicker, type WorkerPickerState } from "./components/WorkerPicker.js";
import { hireWorkerAllowed } from "./hireGate.js";
import { LibraryApi } from "./libraryApi.js";
import { libraryRefKey, sameLibraryRef, type BlueprintApplication, type LibraryRef, type LibraryRole, type LibraryState } from "./libraryTypes.js";
import { TaskGraphApi } from "./taskGraphApi.js";
import type {
  ContextPackOption,
  DesignPackageOption,
  Failure,
  Instrumentation,
  ProviderAvailabilityRefusalCode,
  ProviderCapabilityRefusalCode,
  ProviderAuthAction,
  ProviderAuthState,
  ProviderAuthStatus,
  SetupGuidanceNextActionKey,
  StopReason,
  WorkerEligibilityEntry,
  WorkerRefusal,
  WorkspaceData
} from "./contracts";
import { type Locale, type MessageKey, translate } from "./i18n";
import "./styles.css";

type AppState =
  | { kind: "checking" }
  | { kind: "ready"; data: WorkspaceData; notice: MessageKey | null }
  | { kind: "failure"; failure: Failure };

type RoleDraft = {
  fromPresetId: string;
  name: string;
  profileId: string;
  rationale: string;
  contextMode: string;
  provider: string;
  model: string;
  modelMode: "profile" | "explicit";
  specializationRef: LibraryRef | null;
  specializationName: string;
  supervisorAgentId?: string | null;
};

type TaskDraft = {
  title: string;
  description: string;
  criteria: string;
  dependencyIds: readonly string[];
  taskKind?: "task" | "component";
  parentTaskId?: string | null;
};

type FormErrors = ReadonlySet<string>;
type ActionError = { failure: Failure; retry: () => void; uncertain: boolean; retryKind: "mutation" | "refresh" };
type ProjectTransient = {
  pendingLaunch: LaunchIntent | null;
  pendingLaunchRetry: (() => Promise<void>) | null;
  taskRetry: ReturnType<ContextPackRetryIdentity["snapshot"]>;
  actionErrors: Record<string, ActionError>;
  lastHiredRole: { id: string; name: string } | null;
  roleErrors: FormErrors;
  taskErrors: FormErrors;
  runErrors: FormErrors;
  selectedTaskId: string | null;
};

const emptyRole: RoleDraft = { fromPresetId: "", name: "", profileId: "", rationale: "", contextMode: "fresh", provider: "", model: "", modelMode: "profile", specializationRef: null, specializationName: "" };
const emptyTask: TaskDraft = { title: "", description: "", criteria: "", dependencyIds: [] };
const emptyRun: RunDraft = { agentId: "", taskId: "", contextPackKey: "", designPackageKey: "", limitMinutes: String(DEFAULT_RUN_LIMIT_MINUTES) };

function contextPackKey(option: ContextPackOption): string {
  return `${option.contextPackId}@${option.revision}`;
}

function designPackageKey(option: DesignPackageOption): string {
  return `${option.designPackageId}@${option.revision}`;
}

const guidanceActionMessage: Readonly<Record<SetupGuidanceNextActionKey, MessageKey>> = {
  choose_git_repository: "guidance_choose_repository",
  initialize_workspace: "guidance_initialize_workspace",
  install_provider_and_check_again: "guidance_install_provider",
  install_support_tool_and_check_again: "guidance_install_support_tool",
  configure_runtime: "guidance_configure_runtime",
  repair_workspace_configuration: "guidance_repair_configuration",
  setup_ready: "guidance_ready"
};

/** What the on-demand panel beside the map is called, in human words. */
const workPanelLabel: Readonly<Record<WorkPanel, MessageKey>> = {
  detail: "work_panel_detail",
  new: "work_panel_new",
  run: "work_panel_run"
};

/** Saving and saved are different outcomes, and so is "in memory only". */
function layoutStatusKey(state: LayoutSaveState): MessageKey {
  switch (state.kind) {
    case "saving": return "workspace_layout_saving";
    case "saved": return "workspace_layout_saved";
    case "conflict": return "workspace_layout_conflict";
    case "unavailable": return "workspace_layout_unavailable";
    default: return "workspace_layout_idle";
  }
}

const providerAuthStateMessage: Readonly<Record<ProviderAuthState, MessageKey>> = {
  ready: "provider_auth_ready",
  authentication_required: "provider_auth_required",
  authenticating: "provider_auth_authenticating",
  timed_out: "provider_auth_timed_out",
  cancelled: "provider_auth_cancelled",
  failed: "provider_auth_failed",
  unsupported: "provider_auth_unsupported",
  credential_store_unavailable: "provider_auth_credential_store_unavailable"
};

const providerAuthActionMessage: Readonly<Record<ProviderAuthAction, MessageKey>> = {
  authenticate: "provider_auth_authenticate",
  cancel_authentication: "provider_auth_cancel",
  check_again: "provider_auth_check_again",
  continue_launch: "provider_auth_continue_launch"
};

const availabilityRefusalMessage: Readonly<Record<ProviderAvailabilityRefusalCode, MessageKey>> = {
  provider_installation_unavailable: "provider_availability_installation",
  provider_initialization_failed: "provider_availability_initialization",
  provider_qualification_required: "provider_availability_qualification_required",
  provider_qualification_failed: "provider_availability_qualification_failed",
  provider_authentication_required: "provider_availability_authentication_required",
  provider_authentication_unconfirmed: "provider_availability_authentication_unconfirmed"
};

const capabilityRefusalMessage: Readonly<Record<ProviderCapabilityRefusalCode, MessageKey>> = {
  provider_resume_unavailable: "provider_capability_resume_unavailable",
  provider_skill_projection_unavailable: "provider_capability_skills_unavailable",
  provider_monetary_budget_unavailable: "provider_capability_monetary_unavailable"
};

function failureFrom(error: unknown, text: (key: MessageKey) => string): Failure {
  const problem = error instanceof ApiProblem ? error : null;
  const code = problem?.apiError?.code ?? (problem?.status === 401 ? "unauthorized" : "request_unavailable");
  const safeNextActions = problem?.apiError?.safeNextActions ?? [];
  if (code === "unauthorized" || problem?.status === 401 || problem?.status === 404) {
    return {
      code,
      title: text("failure_access_title"),
      nextStep: text("failure_access_next"),
      canRetry: false,
      safeNextActions
    };
  }
  if (code.startsWith("setup_")) {
    return {
      code,
      title: text("failure_setup_title"),
      nextStep: text("failure_setup_next"),
      canRetry: true,
      safeNextActions
    };
  }
  if (code === "launch_not_configured") {
    return {
      code,
      title: text("failure_launch_title"),
      nextStep: text("failure_launch_next"),
      canRetry: true,
      safeNextActions
    };
  }
  if (code === "invalid_request" || code === "ValidationError") {
    return {
      code,
      title: text("failure_validation_title"),
      nextStep: text("failure_validation_next"),
      canRetry: true,
      safeNextActions
    };
  }
  const unavailable = problem !== null && problem.status >= 500;
  return {
    code,
    title: text(unavailable ? "failure_unavailable_title" : "failure_unknown_title"),
    nextStep: text(unavailable ? "failure_unavailable_next" : "failure_unknown_next"),
    canRetry: true,
    safeNextActions
  };
}

// The route refuses a mistyped or out-of-range limit with a typed 422; the
// launch coordinator refuses the same bound on its own path with the code in
// the message. Either way the reason belongs beside the control, not in the
// generic failure panel.
const RUN_LIMIT_REFUSAL_CODE = "invalid_wall_time_seconds";

function isRunLimitRefusal(problem: ApiProblem | null): boolean {
  const apiError = problem?.apiError ?? null;
  if (apiError === null || apiError.message === "") return false;
  // Typed code only: the route names the refusal, and message text never drives UI.
  return apiError.code === RUN_LIMIT_REFUSAL_CODE;
}

function validation(errors: readonly string[], field: string): boolean {
  return errors.includes(field);
}

function repositoryBasename(path: string): string {
  const segments = path.split(/[\\/]/).filter(Boolean);
  return segments.at(-1) ?? path;
}

function WorkApp(): ReactElement {
  const projectCreation = useRef(new ProjectCreation());
  const conversationSessions = useRef(new ConversationSessions());
  const agentBoardSessions = useRef(new AgentBoardSessions());
  const [route, setRoute] = useState<WorkRoute>(() => parseWorkRoute(window.location.search));
  const compactPane = useCompactPane(route.projectId);
  const routeRef = useRef(route);
  const [search, setSearch] = useState("");
  // Reading positions on the task map, per project, map kind and drawing. RAM
  // only: a viewport is where the person is looking, not a record.
  const viewportsRef = useRef(new MapViewportStore());
  // The pane arrangement. The server owns it; this store owns what the person
  // is doing to it right now, and a save happens when a gesture ends.
  const layoutEntries = useRef(new Map<string, { store: WorkspaceLayoutStore; sync: WorkspacePreferenceSync }>());
  const layoutKey = route.projectId ?? "legacy";
  if (!layoutEntries.current.has(layoutKey)) {
    const store = new WorkspaceLayoutStore();
    layoutEntries.current.set(layoutKey, { store, sync: new WorkspacePreferenceSync(store) });
  }
  const layoutEntry = layoutEntries.current.get(layoutKey)!;
  const layoutRef = useRef(layoutEntry.store);
  layoutRef.current = layoutEntry.store;
  const [, setLayoutRevision] = useState(0);
  useEffect(() => layoutEntry.store.subscribe(() => setLayoutRevision((value) => value + 1)), [layoutEntry]);
  const [actionErrors, setActionErrors] = useState<Record<string, ActionError>>({});
  const newTaskButton = useRef<HTMLButtonElement>(null);
  const navigationRevision = useRef(0);
  const [locale, setLocale] = useState<Locale>("en");
  const [state, setState] = useState<AppState>({ kind: "checking" });
  useEffect(() => { if (state.kind !== "ready") compactPane.reset(); }, [state.kind]);
  // In-flight writes, per project and surface. A write gates writes, not reading.
  const mutationsRef = useRef(new MutationRegistry());
  const [mutationRevision, setMutationRevision] = useState(0);
  const [role, setRole] = useState<RoleDraft>(emptyRole);
  const [task, setTask] = useState<TaskDraft>(emptyTask);
  const [run, setRun] = useState<RunDraft>(emptyRun);
  const draftsRef = useRef(new ProjectDraftStore<{ role: RoleDraft; task: TaskDraft; run: RunDraft }>());
  const currentDraftRef = useRef({ role: emptyRole, task: emptyTask, run: emptyRun });
  currentDraftRef.current = { role, task, run };
  const [roleErrors, setRoleErrors] = useState<FormErrors>(new Set());
  const [taskErrors, setTaskErrors] = useState<FormErrors>(new Set());
  const [runErrors, setRunErrors] = useState<FormErrors>(new Set());
  // The server's own reason for refusing the limit, shown verbatim next to the
  // control and tied to the exact attempt it refused, so it can never be read
  // as a verdict on another draft. The typed draft is never reset by a refusal.
  const [runLimitRefusal, setRunLimitRefusal] = useState<{ taskId: string; limitMinutes: string } | null>(null);
  // A launch the server refused before any attempt or child session existed:
  // no run was created, the typed refusal is rendered beside the control that
  // asked for it, and the draft stays exactly as it was, in memory only.
  const [launchRefusal, setLaunchRefusal] = useState<{ taskId: string; refusal: StopReason } | null>(null);
  // The operator's remaining launch allowance for the chosen agent's profile:
  // reserved launches, never money. Unknown stays unknown.
  const [launchBudget, setLaunchBudget] = useState<{ profileId: string; state: LaunchBudgetState }>({ profileId: "", state: { kind: "unknown" } });
  // A launch the precheck refused because that allowance is used up. No
  // attempt, no child session, and no automatic raise of the limit.
  const [budgetRefusal, setBudgetRefusal] = useState<{ taskId: string; budget: LaunchBudget | null } | null>(null);
  const [showFullProjectPath, setShowFullProjectPath] = useState(false);
  const [configurationConfirmationOpen, setConfigurationConfirmationOpen] = useState(false);
  const [pendingLaunch, setPendingLaunch] = useState<LaunchIntent | null>(null);
  const pendingLaunchRef = useRef<LaunchIntent | null>(null);
  const runRef = useRef(run);
  runRef.current = run;
  const [launchedTaskId, setLaunchedTaskId] = useState<string | null>(null);
  const [trackerObservation, setTrackerObservation] = useState<TrackerViewState>({ kind: "loading" });
  const dependencies = useMemo(() => taskDependencyCatalog(trackerObservation), [trackerObservation]);
  const hostApiRef = useRef(new WorkApi());
  const apiRef = useRef(hostApiRef.current);
  const libraryApiRef = useRef(new LibraryApi(apiRef.current));
  const registryApiRef = useRef(new ProjectRegistryApi(hostApiRef.current));
  const projectSelectionRef = useRef(new ProjectSelection());
  const readRequestRef = useRef(new ProjectReadRequest());
  const projectMutationKeys = useRef(new Map<string, string>());
  const [projectList, setProjectList] = useState<ProjectList | null>(null);
  const [legacyProjectHost, setLegacyProjectHost] = useState(false);
  const [libraryState, setLibraryState] = useState<LibraryState>({ kind: "loading" });
  const [libraryRefresh, setLibraryRefresh] = useState(0);
  // Worker choices are server truth for the exact chosen specialization version.
  // The key travels with them so a list read for one version is never shown
  // beside another, and a failed read leaves every worker unknown.
  const [workers, setWorkers] = useState<{ key: string; state: WorkerPickerState }>({ key: "", state: { kind: "idle" } });
  const [workerRefresh, setWorkerRefresh] = useState(0);
  // A hire the server refused: kept in RAM beside the worker step, never a
  // canonical fact and never a reason to drop the typed draft.
  const [hireRefusal, setHireRefusal] = useState<{ refusal: WorkerRefusal | null } | null>(null);
  const [lastHiredRole, setLastHiredRole] = useState<{ id: string; name: string } | null>(null);
  // RAM only, and never a canonical fact: the applied mapping is kept so the
  // outcome can be read against a later tracker snapshot rather than guessed.
  const [appliedBlueprint, setAppliedBlueprint] = useState<BlueprintApplication | null>(null);
  // Board shell state (ADR 0020): the hire panel toggle, a re-read trigger for the
  // role graph after confirmed writes, and the application the board frames next.
  const [hireOpen, setHireOpen] = useState(false);
  const [boardRefreshKey, setBoardRefreshKey] = useState(0);
  const [pendingApplication, setPendingApplication] = useState<{ application: BlueprintApplication; title: string } | null>(null);
  const taskRetryIdentity = useRef(new ContextPackRetryIdentity());
  const projectTransientRef = useRef(new ProjectDraftStore<ProjectTransient>());
  const currentTransientRef = useRef<Omit<ProjectTransient, "pendingLaunch" | "pendingLaunchRetry" | "taskRetry">>({
    actionErrors: {}, lastHiredRole: null, roleErrors: new Set(), taskErrors: new Set(), runErrors: new Set(), selectedTaskId: null
  });
  currentTransientRef.current = { actionErrors, lastHiredRole, roleErrors, taskErrors, runErrors, selectedTaskId: route.taskId };
  // Local, opt-in, content-free counters. Server truth for the toggle and the
  // revision; the client never assumes either, and holds nothing in storage.
  const [instrumentation, setInstrumentation] = useState<Instrumentation | null>(null);
  const [instrumentationUnavailable, setInstrumentationUnavailable] = useState(false);
  const [instrumentationHint, setInstrumentationHint] = useState<InstrumentationHint | null>(null);
  const [instrumentationBusy, setInstrumentationBusy] = useState(false);
  const [instrumentationClearAsked, setInstrumentationClearAsked] = useState(false);
  const [instrumentationRefresh, setInstrumentationRefresh] = useState(0);
  const authPanelRef = useRef<HTMLElement | null>(null);
  const pendingLaunchRetry = useRef<(() => Promise<void>) | null>(null);
  const launchSelectionVersion = useRef(0);
  const text = useMemo(() => (key: MessageKey) => translate(locale, key), [locale]);

  // One batcher for the whole shell. It posts revision-bound batches to this
  // panel's own API and nowhere else, and is inert until a read says the toggle
  // is on. A 409 re-reads once and hints; a 422 hints and drops; neither retries.
  const instrumentationBatcher = useRef<InstrumentationBatcher | null>(null);
  if (instrumentationBatcher.current === null) {
    instrumentationBatcher.current = new InstrumentationBatcher({
      post: async (events, expectedRevision): Promise<InstrumentationPostOutcome> => {
        try {
          const next = await apiRef.current.recordInstrumentation(events, expectedRevision, new AbortController().signal);
          if (next === null) return { kind: "ignored" };
          setInstrumentation(next);
          return { kind: "accepted", revision: next.revision };
        } catch (error: unknown) {
          const status = error instanceof ApiProblem ? error.status : 0;
          if (status === 409) return { kind: "stale" };
          if (status === 400 || status === 422) return { kind: "rejected" };
          return { kind: "unavailable" };
        }
      },
      onHint: setInstrumentationHint,
      onReread: () => setInstrumentationRefresh((current) => current + 1)
    });
  }

  useEffect(() => {
    setInstrumentationSink(instrumentationBatcher.current);
    return () => setInstrumentationSink(null);
  }, []);

  // Server truth drives the batcher: an answer that says off, or no answer at
  // all, leaves it inert and empties whatever it was holding.
  useEffect(() => {
    const batcher = instrumentationBatcher.current;
    if (batcher === null) return;
    batcher.setRevision(instrumentation?.revision ?? null);
    batcher.setEnabled(instrumentation?.enabled === true);
  }, [instrumentation]);

  useEffect(() => mutationsRef.current.subscribe(() => setMutationRevision((current) => current + 1)), []);
  // Recomputed whenever the registry publishes, while the handles themselves stay
  // identical, so an unrelated render never restarts a running duration timer.
  const projectMutations = useMemo(
    () => mutationsRef.current.inFlight(route.projectId),
    [mutationRevision, route.projectId]
  );
  // One server write lock: any write in this project gates the other writes, and
  // nothing else. Navigation, task selection, search, reading and refresh do not
  // consult it, so a slow ledger write no longer freezes the whole application.
  const writeInFlight = projectMutations.length > 0;

  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  const libraryAccessible = state.kind === "ready" && state.data.setup.state !== "setup_uninitialized" && state.data.setup.state !== "setup_not_a_repository";
  useEffect(() => {
    if (!libraryAccessible) return;
    const controller = new AbortController();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = libraryApiRef.current;
    const stillCurrent = (): boolean => !controller.signal.aborted
      && projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId;
    void api.load(controller.signal).then((catalog) => {
      if (stillCurrent()) setLibraryState({ kind: "ready", catalog });
    }).catch(() => {
      if (stillCurrent()) setLibraryState((current) => ({ kind: "error", ...(current.kind !== "loading" && current.catalog ? { catalog: current.catalog } : {}) }));
    });
    return () => controller.abort();
  }, [libraryAccessible, libraryRefresh]);

  const instrumentationReadable = state.kind === "ready";
  useEffect(() => {
    if (!instrumentationReadable) return;
    const controller = new AbortController();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const stillCurrent = (): boolean => !controller.signal.aborted
      && projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId;
    void api.instrumentation(controller.signal).then((value) => {
      if (!stillCurrent()) return;
      setInstrumentation(value);
      setInstrumentationUnavailable(false);
    }).catch(() => {
      // Fail closed: an unreadable local store counts nothing and says so.
      if (!stillCurrent()) return;
      setInstrumentation(null);
      setInstrumentationUnavailable(true);
    });
    return () => controller.abort();
  }, [instrumentationReadable, route.projectId, instrumentationRefresh]);

  async function toggleInstrumentation(enabled: boolean): Promise<void> {
    const current = instrumentation;
    if (current === null || instrumentationBusy) return;
    // Emission stops before the request leaves, so switching off can never race
    // a flush that was already scheduled.
    if (!enabled) instrumentationBatcher.current?.setEnabled(false);
    const api = apiRef.current;
    setInstrumentationBusy(true);
    setInstrumentationHint(null);
    try {
      setInstrumentation(await api.setInstrumentation(enabled, current.revision, new AbortController().signal));
      setInstrumentationUnavailable(false);
    } catch (error: unknown) {
      setInstrumentationHint(error instanceof ApiProblem && error.status === 409 ? "stale" : "rejected");
      setInstrumentationRefresh((value) => value + 1);
    } finally {
      setInstrumentationBusy(false);
    }
  }

  async function clearInstrumentation(): Promise<void> {
    const current = instrumentation;
    if (current === null || instrumentationBusy) return;
    const api = apiRef.current;
    setInstrumentationBusy(true);
    setInstrumentationHint(null);
    // Whatever is queued describes counts that are being discarded anyway.
    instrumentationBatcher.current?.reset();
    try {
      await api.clearInstrumentation(current.revision, new AbortController().signal);
      setInstrumentationClearAsked(false);
    } catch (error: unknown) {
      setInstrumentationHint(error instanceof ApiProblem && error.status === 409 ? "stale" : "rejected");
    } finally {
      setInstrumentationBusy(false);
      setInstrumentationRefresh((value) => value + 1);
    }
  }

  // Only a connected, loaded project can read private preferences. The queue is
  // owned by that project and survives navigation and late responses in RAM.
  const preferenceApi = state.kind === "ready" ? apiRef.current : null;
  useEffect(() => {
    if (preferenceApi === null) return;
    void layoutEntry.sync.connect(preferenceApi);
  }, [preferenceApi, layoutEntry]);
  function saveLayout(layout: WorkspaceLayout): Promise<void> {
    return layoutEntry.sync.request(layout);
  }

  // Role first: without a chosen specialization there is nothing to ask the
  // server about, and the worker step stays disabled rather than guessing.
  const specializationKey = role.specializationRef === null ? "" : libraryRefKey(role.specializationRef);
  const workersReadable = state.kind === "ready" && state.data.setup.state === "setup_configured";
  useEffect(() => {
    if (specializationKey === "" || !workersReadable) {
      setWorkers({ key: "", state: { kind: "idle" } });
      return;
    }
    const ref = role.specializationRef;
    if (ref === null) return;
    const controller = new AbortController();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const stillCurrent = (): boolean => !controller.signal.aborted
      && projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId;
    // A re-read keeps the workers it is refreshing; a different specialization
    // starts from nothing, because those workers answered another question.
    setWorkers((current) => ({
      key: specializationKey,
      state: { kind: "loading", workers: current.key === specializationKey && current.state.kind !== "idle" ? current.state.workers : [] }
    }));
    void api.workerEligibility(ref, controller.signal).then((eligibility) => {
      if (stillCurrent()) setWorkers({ key: specializationKey, state: { kind: "ready", workers: eligibility.workers } });
    }).catch(() => {
      // Fail closed: the workers stay visible, and every one of them unknown.
      if (stillCurrent()) {
        setWorkers((current) => ({
          key: specializationKey,
          state: { kind: "unavailable", workers: current.key === specializationKey && current.state.kind !== "idle" ? current.state.workers : [] }
        }));
      }
    });
    return () => controller.abort();
  }, [specializationKey, workersReadable, workerRefresh]);

  const workerState: WorkerPickerState = workers.key === specializationKey ? workers.state : { kind: "idle" };

  // Prepare run explains the limit it will be launched under. The profile of
  // the chosen agent decides which allowance is read; an unreadable or absent
  // answer shows no number at all.
  const runProfileId = useMemo(
    () => state.kind === "ready" ? state.data.launch?.roles.find((option) => option.id === run.agentId)?.profileId ?? null : null,
    [state, run.agentId]
  );
  const runPanelOpen = route.panel === "run";
  useEffect(() => {
    if (!runPanelOpen || runProfileId === null) {
      setLaunchBudget({ profileId: "", state: { kind: "unknown" } });
      return;
    }
    const controller = new AbortController();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const stillCurrent = (): boolean => !controller.signal.aborted
      && projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId;
    setLaunchBudget({ profileId: runProfileId, state: { kind: "loading" } });
    void api.readLaunchBudget(runProfileId, controller.signal).then((payload) => {
      if (stillCurrent()) setLaunchBudget({ profileId: runProfileId, state: { kind: "ready", budget: parseLaunchBudget(payload, runProfileId) } });
    }).catch(() => {
      // Not readable is not zero: the surface says so and invents no count.
      if (stillCurrent()) setLaunchBudget({ profileId: runProfileId, state: { kind: "unavailable" } });
    });
    return () => controller.abort();
  }, [runPanelOpen, runProfileId, route.projectId]);

  function chooseSpecialization(selected: LibraryRole | null, showTeam = false): void {
    setRole((current) => ({ ...current, fromPresetId: "", specializationRef: selected?.ref ?? null,
      specializationName: selected?.name ?? "", name: current.name || selected?.name || "",
      rationale: current.rationale || selected?.description || "",
      // The worker belonged to the previous question and is not carried over.
      profileId: "", provider: "", model: "", modelMode: "profile" }));
    setHireRefusal(null);
    if (showTeam) { setHireOpen(true); navigate({ view: "board" }); }
  }

  /** The chosen worker also supplies the Advanced defaults: its own provider and model. */
  function chooseWorker(worker: WorkerEligibilityEntry): void {
    setHireRefusal(null);
    setRole((current) => ({ ...current, fromPresetId: "", profileId: worker.profileId,
      provider: worker.provider, model: "", modelMode: "profile" }));
  }


  function navigate(patch: Partial<WorkRoute>, replace = false): void {
    navigationRevision.current += 1;
    const previous = routeRef.current;
    const next = { ...previous, ...patch };
    const destinationChanged = next.view !== previous.view
      || (next.view === "library" && next.libraryTab !== previous.libraryTab);
    routeRef.current = next;
    const href = workRouteHref(next);
    if (replace) window.history.replaceState(null, "", href);
    else if (href !== window.location.pathname + window.location.search) window.history.pushState(null, "", href);
    setRoute(next);
    if (destinationChanged) {
      // Moving between views completes here and takes no request: the coarse
      // bucket is the local work only, never a wall-clock reading.
      recordInstrumentation("navigation", "confirmed", 0);
      const revision = navigationRevision.current;
      window.requestAnimationFrame(() => {
        if (navigationRevision.current === revision) window.scrollTo({ top: 0, left: 0, behavior: "auto" });
      });
    }
  }

  /**
   * Opening a task: it becomes the selected node and its details open on
   * demand beside the map. The map stays mounted; its focused branch and
   * reading position are untouched.
   */
  function openTask(taskId: string): void {
    navigate({ taskId, panel: "detail" });
    if (window.matchMedia("(max-width: 1000px)").matches) {
      window.requestAnimationFrame(() => {
        if (routeRef.current.view !== "work" || routeRef.current.taskId !== taskId) return;
        document.querySelector<HTMLElement>(".work-panel-detail .task-inspector")?.focus({ preventScroll: true });
      });
    }
  }

  /** Moving the selection only: no panel opens, closes or changes. */
  function focusTask(taskId: string): void {
    navigate({ taskId });
  }

  /** Closing a panel never clears the selection or refits the map. */
  function closePanel(): void {
    navigate({ panel: null });
  }

  function closeComposer(): void {
    closePanel();
    window.setTimeout(() => newTaskButton.current?.focus(), 0);
  }

  function prepareLaunch(taskId: string): void {
    // Prepare run opens the composer and issues nothing, so it always completes.
    recordInstrumentation("run_prepare", "confirmed", 0);
    const selectionVersion = ++launchSelectionVersion.current;
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    setRun((current) => pendingLaunchRef.current?.input.taskId === taskId ? restoreLaunchDraft(pendingLaunchRef.current) : current.taskId === taskId ? current : { ...emptyRun, taskId });
    navigate({ view: "work", taskId, panel: "run" });
    window.setTimeout(() => {
      if (projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId) {
        document.getElementById("run-role")?.focus();
      }
    }, 0);
    if (state.kind === "ready" && !pendingLaunchRef.current) {
      const activeRoles = new Set(state.data.launch?.roles.map((option) => option.id) ?? []);
      void new TaskGraphApi(api).detail(taskId, new AbortController().signal).then((detail) => {
        if (!projectSelectionRef.current.isCurrent(generation) || routeRef.current.projectId !== projectId
          || launchSelectionVersion.current !== selectionVersion || pendingLaunchRef.current || routeRef.current.view !== "work" || routeRef.current.taskId !== taskId
          || !detail.suggestedAgentId || !activeRoles.has(detail.suggestedAgentId)) return;
        const suggested = detail.suggestedAgentId;
        setRun((current) => current.taskId === taskId && !current.agentId ? { ...current, agentId: suggested } : current);
      }).catch(() => { /* The optional hint never replaces an explicit role choice. */ });
    }
  }

  // A conversation cannot start a run. This only opens Prepare run for the task
  // the conversation is about — the selected task for an agent or project scope —
  // or returns to Work when no task is in hand. It never issues a request.
  function prepareRunForConversation(scope: ConversationScope): void {
    const taskId = prepareRunTaskId(scope, routeRef.current.taskId);
    if (taskId) prepareLaunch(taskId);
    else navigate({ view: "work", panel: null });
  }

  // Applying a blueprint creates roles and tasks only. Both offered intents
  // navigate; neither issues a launch. Prepare run is prefilled with the exact
  // task a refreshed snapshot confirmed, never with a position in the mapping.
  function followBlueprintIntent(intent: BlueprintApplyIntent): void {
    setAppliedBlueprint(null);
    if (intent.kind === "prepare_run") {
      prepareLaunch(intent.taskId);
      if (!pendingLaunchRef.current) {
        setRun((current) => current.taskId === intent.taskId && !current.agentId
          ? { ...current, agentId: intent.agentId } : current);
      }
      return;
    }
    setSearch("");
    navigate({ view: "work", filter: "all", taskId: intent.taskId, panel: "detail" });
  }

  useEffect(() => {
    const onPop = (): void => {
      navigationRevision.current += 1;
      const next = parseWorkRoute(window.location.search);
      if (next.projectId !== routeRef.current.projectId) bindProject(next.projectId);
      routeRef.current = next;
      setRoute(next);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (anyDialogOpen() || event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey || isEditingTarget(event.target)) return;
      if (event.key.toLowerCase() === "n") {
        event.preventDefault();
        navigate({ view: "work", panel: "new" });
        window.setTimeout(() => document.getElementById("task-title")?.focus(), 0);
      } else if (event.key === "/") {
        event.preventDefault();
        navigate({ view: "work" });
        window.setTimeout(() => document.querySelector<HTMLInputElement>(".task-view-toolbar input")?.focus(), 0);
      } else if (event.key === "Escape" && route.panel === "new") closeComposer();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [route]);

  function clearActionError(action: string): void {
    setActionErrors((current) => { const next = { ...current }; delete next[action]; return next; });
  }
  function recordActionError(action: string, error: unknown, retry: () => void): void {
    setActionErrors((current) => ({ ...current, [action]: { failure: failureFrom(error, text), retry,
      uncertain: !(error instanceof ApiProblem) || error.status >= 500, retryKind: "mutation" } }));
  }
  function recordRefreshError(action: string, error: unknown, retry: () => void): void {
    setActionErrors((current) => ({ ...current, [action]: {
      failure: failureFrom(error, text), retry, uncertain: false, retryKind: "refresh"
    } }));
  }
  function actionFeedback(action: string): ReactElement | null {
    const actionError = actionErrors[action];
    if (!actionError) return null;
    return <div className="action-failure" role="alert">
      <h3>{actionError.failure.title}</h3>
      <p>{text(actionError.retryKind === "refresh" ? "shell_refresh_retry_help" : "shell_retry_help")}</p>
      <p>{actionError.failure.nextStep}</p>
      {/* Retrying a failed follow-up read is a read: it never waits on a write. */}
      <button className="button button-secondary button-inline" disabled={actionError.retryKind === "mutation" && writeInFlight} onClick={actionError.retry} type="button">{text(actionError.retryKind === "refresh" ? "refresh_status" : "shell_retry_original")}</button>
      <details><summary>{text("shell_technical_details")}</summary><code>{actionError.failure.code}</code>
        <ul>{actionError.failure.safeNextActions.map((item) => <li key={item}>{item}</li>)}</ul>
      </details>
    </div>;
  }

  async function load(): Promise<void> {
    const projectGeneration = projectSelectionRef.current.currentGeneration();
    const read = readRequestRef.current.begin();
    const stillCurrent = (): boolean => projectSelectionRef.current.isCurrent(projectGeneration)
      && readRequestRef.current.isCurrent(read.generation);
    setState((current) => current.kind === "ready" ? current : { kind: "checking" });
    try {
      const host = hostApiRef.current;
      await host.connect(read.signal);
      let projectApi = host;
      try {
        const projects = await registryApiRef.current.list(read.signal);
        if (!stillCurrent()) return;
        setLegacyProjectHost(false);
        setProjectList(projects);
        const selectedId = routeRef.current.projectId ?? projects.defaultProjectId ?? projects.projects.find((item) => item.available && item.state === "ready")?.id ?? null;
        if (selectedId === null) {
          setState({ kind: "failure", failure: { code: "project_required", title: text("project_none"), nextStep: text("project_new"), canRetry: true, safeNextActions: [] } });
          return;
        }
        if (routeRef.current.projectId !== selectedId) {
          const next = { ...routeRef.current, projectId: selectedId };
          routeRef.current = next;
          window.history.replaceState(null, "", workRouteHref(next));
          setRoute(next);
        }
        projectApi = host.forProject(selectedId);
      } catch (error: unknown) {
        if (!(error instanceof ApiProblem) || error.status !== 404) throw error;
        // A single-workspace host predates the registry endpoint. Keep its
        // authenticated transport and do not erase it merely because projects is absent.
        setLegacyProjectHost(true);
        setProjectList(null);
      }
      apiRef.current = projectApi;
      libraryApiRef.current = new LibraryApi(projectApi);
      const data = await projectApi.load(read.signal);
      if (!stillCurrent()) return;
      setState((current) => ({ kind: "ready", data, notice: current.kind === "ready" ? current.notice : null }));
    } catch (error: unknown) {
      if (error instanceof DOMException && error.name === "AbortError") {
        return;
      }
      if (!stillCurrent()) return;
      setState((current) => current.kind === "ready" ? current : { kind: "failure", failure: failureFrom(error, text) });
      recordActionError("refresh", error, () => void refresh());
    } finally { /* The next project selection owns cancellation of this request. */ }
  }

  useEffect(() => {
    void load();
    return () => readRequestRef.current.abort();
  }, [route.projectId]);

  useEffect(() => {
    if (state.kind !== "ready") {
      return;
    }
    const activeProfiles = state.data.providerAuth
      .filter((status) => status.state === "authenticating")
      .map((status) => status.profileId);
    if (activeProfiles.length === 0) {
      return;
    }
    const generation = projectSelectionRef.current.currentGeneration();
    const api = apiRef.current;
    const controller = new AbortController();
    const timer = window.setTimeout(() => {
      void Promise.allSettled(
        activeProfiles.map((profileId) => api.providerAuthStatus(profileId, controller.signal))
      ).then((results) => {
        if (!projectSelectionRef.current.isCurrent(generation)) return;
        setState((current) => {
          if (current.kind !== "ready") {
            return current;
          }
          const byProfile = new Map(current.data.providerAuth.map((status) => [status.profileId, status]));
          const errors = new Set(current.data.providerAuthErrors);
          results.forEach((result, index) => {
            const profileId = activeProfiles[index];
            if (result.status === "fulfilled") {
              byProfile.set(profileId, result.value);
              errors.delete(profileId);
            } else {
              errors.add(profileId);
            }
          });
          return {
            ...current,
            data: {
              ...current.data,
              providerAuth: [...byProfile.values()],
              providerAuthErrors: [...errors]
            }
          };
        });
      });
    }, 1500);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [state]);

  async function refresh(): Promise<void> {
    clearActionError("refresh");
    await load();
    setBoardRefreshKey((current) => current + 1);
  }

  function selectProject(projectId: string): void {
    if (routeRef.current.projectId === projectId) return;
    // Drafts are intentionally RAM-only and keyed by opaque project identity.
    // Selection also closes the active tracker through a new immutable client.
    const selectedTaskId = bindProject(projectId);
    navigate({ projectId, taskId: selectedTaskId, panel: null });
  }

  function bindProject(projectId: string | null): string | null {
    const previousId = routeRef.current.projectId;
    if (previousId !== null) {
      draftsRef.current.set(previousId, currentDraftRef.current);
      projectTransientRef.current.set(previousId, {
        pendingLaunch: pendingLaunchRef.current,
        pendingLaunchRetry: pendingLaunchRetry.current,
        taskRetry: taskRetryIdentity.current.snapshot(),
        ...currentTransientRef.current
      });
    }
    const nextDraft = projectId === null ? { role: emptyRole, task: emptyTask, run: emptyRun }
      : draftsRef.current.get(projectId, { role: emptyRole, task: emptyTask, run: emptyRun });
    setRole(nextDraft.role); setTask(nextDraft.task); setRun(nextDraft.run);
    const transient = projectId === null
      ? { pendingLaunch: null, pendingLaunchRetry: null, taskRetry: null, actionErrors: {}, lastHiredRole: null, roleErrors: new Set<string>(), taskErrors: new Set<string>(), runErrors: new Set<string>(), selectedTaskId: null }
      : projectTransientRef.current.get(projectId, { pendingLaunch: null, pendingLaunchRetry: null, taskRetry: null, actionErrors: {}, lastHiredRole: null, roleErrors: new Set<string>(), taskErrors: new Set<string>(), runErrors: new Set<string>(), selectedTaskId: null });
    pendingLaunchRef.current = transient.pendingLaunch;
    pendingLaunchRetry.current = transient.pendingLaunchRetry;
    setPendingLaunch(transient.pendingLaunch);
    taskRetryIdentity.current.restore(transient.taskRetry);
    projectSelectionRef.current.select();
    readRequestRef.current.abort();
    if (projectId !== null) {
      try { apiRef.current = hostApiRef.current.forProject(projectId); libraryApiRef.current = new LibraryApi(apiRef.current); }
      catch { /* The route loader presents the typed host failure. */ }
    }
    // Never retain a ready snapshot while its project heading/client changes.
    // The route effect owns the next scoped read and will replace this shell.
    setState({ kind: "checking" });
    setLibraryState({ kind: "loading" });
    // A write started in the other project stays recorded under that project.
    // It gates that project's writes when it is opened again, and gates nothing here.
    setActionErrors(transient.actionErrors);
    setLastHiredRole(transient.lastHiredRole);
    setRoleErrors(transient.roleErrors);
    setTaskErrors(transient.taskErrors);
    setRunErrors(transient.runErrors);
    setTrackerObservation({ kind: "loading" });
    setAppliedBlueprint(null);
    setPendingApplication(null);
    setHireOpen(false);
    return transient.selectedTaskId;
  }

  function pickProjectFolder(purpose: FolderPurpose, signal: AbortSignal): Promise<FolderSelection> {
    return registryApiRef.current.pickFolder(purpose, signal);
  }

  async function inspectProject(input: { mode: "new" | "existing"; path: string; name: string }): Promise<ProjectInspection> {
    return registryApiRef.current.inspect(input, new AbortController().signal);
  }

  async function createProject(inspection: ProjectInspection): Promise<void> {
    const intent = `create:${inspection.inspectionId}`;
    const key = projectMutationKeys.current.get(intent) ?? `project-create-${crypto.randomUUID()}`;
    projectMutationKeys.current.set(intent, key);
    const result = await registryApiRef.current.create(inspection.inspectionId, key, new AbortController().signal);
    setProjectList((current) => current === null ? current : { ...current, revision: result.revision,
      defaultProjectId: current.defaultProjectId ?? result.project.id,
      projects: [...current.projects.filter((item) => item.id !== result.project.id), result.project] });
    selectProject(result.project.id);
    // Blueprint and profile choices are intentionally collected only after the
    // registry has created this project, through the existing scoped apply flow.
    navigate({ view: "library", libraryTab: "blueprints" });
    projectMutationKeys.current.delete(intent);
  }

  async function updateProject(projectId: string, expectedRevision: string, input: { name: string; archived: boolean }): Promise<void> {
    const intent = `update:${projectId}:${expectedRevision}:${JSON.stringify(input)}`;
    const key = projectMutationKeys.current.get(intent) ?? `project-update-${crypto.randomUUID()}`;
    projectMutationKeys.current.set(intent, key);
    const result = await registryApiRef.current.update(projectId, expectedRevision, input, key, new AbortController().signal);
    setProjectList((current) => current === null ? current : { ...current, revision: result.revision,
      projects: current.projects.map((item) => item.id === result.project.id ? result.project : item) });
    projectMutationKeys.current.delete(intent);
  }

  async function perform(
    action: string,
    api: WorkApi,
    work: (signal: AbortSignal) => Promise<void>,
    notice: MessageKey,
    projectId = routeRef.current.projectId
  ): Promise<boolean> {
    const generation = projectSelectionRef.current.currentGeneration();
    const stillCurrent = (): boolean => projectSelectionRef.current.isCurrent(generation)
      && routeRef.current.projectId === projectId;
    const handle = mutationsRef.current.begin({ projectId, surface: mutationSurface(action), operation: action }, typeof document === "undefined" ? null : document.activeElement);
    clearActionError(action);
    // A snapshot started before this write must not publish after it.
    readRequestRef.current.abort();
    const controller = new AbortController();
    try {
      await work(controller.signal);
      if (!stillCurrent()) return false;
      // The mutation is now authoritative. End its busy phase and retain the
      // confirmed outcome while the follow-up read catches the snapshot up.
      setState((current) => current.kind === "ready" ? { ...current, notice } : current);
      mutationsRef.current.end(handle);
      void refreshAfterConfirmed(action, api, notice, projectId);
      return true;
    } catch (error: unknown) {
      if (stillCurrent() && !(error instanceof DOMException && error.name === "AbortError")) {
        if (action === "create-role" && error instanceof ApiProblem
          && error.status === 409 && error.apiError?.code === "worker_ineligible") {
          // A typed refusal, decided before any canonical write. It belongs
          // beside the worker step with the draft intact, and the eligibility
          // list is read again rather than reasoned about here.
          setHireRefusal({ refusal: error.apiError?.refusal ?? null });
          setWorkerRefresh((current) => current + 1);
          return false;
        }
        if (action === "runtime" && error instanceof ApiProblem
          && error.status === 409 && error.apiError?.code === "setup_configured") {
          // This definite refusal happens before any configuration write. A
          // previous successful write's refresh may have been cancelled above;
          // replace that read without replaying setup or inventing success.
          void refreshAfterConfirmed(action, api, null, projectId);
          return false;
        }
        // The retry retains the original immutable project client and input
        // closure. It may only run after this same project is visible again.
        recordActionError(action, error, () => {
          if (routeRef.current.projectId === projectId) void perform(action, api, work, notice, projectId);
        });
      }
      return false;
    } finally {
      // Retired unconditionally: the entry belongs to its own project, so a
      // switch away must not leave that project holding a write forever.
      mutationsRef.current.end(handle);
    }
  }

  async function refreshAfterConfirmed(
    action: string,
    api: WorkApi,
    notice: MessageKey | null,
    projectId: string | null
  ): Promise<boolean> {
    if (routeRef.current.projectId !== projectId) return false;
    const generation = projectSelectionRef.current.currentGeneration();
    const read = readRequestRef.current.begin();
    const stillCurrent = (): boolean => projectSelectionRef.current.isCurrent(generation)
      && routeRef.current.projectId === projectId && readRequestRef.current.isCurrent(read.generation);
    clearActionError(action);
    try {
      const data = await api.load(read.signal);
      if (!stillCurrent()) return false;
      setState((current) => ({ kind: "ready", data, notice: current.kind === "ready" ? current.notice : notice }));
      return true;
    } catch (error: unknown) {
      if (stillCurrent() && !(error instanceof DOMException && error.name === "AbortError")) {
        recordRefreshError(action, error, () => {
          if (routeRef.current.projectId === projectId) void refreshAfterConfirmed(action, api, notice, projectId);
        });
      }
      return false;
    }
  }

  function submitRole(event: FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    if (actionErrors["create-role"]?.uncertain || state.kind !== "ready" || !state.data.meta.writesEnabled || state.data.setup.state !== "setup_configured") return;
    setHireRefusal(null);
    const errors = [
      ...(role.name.trim() ? [] : ["name"]),
      // Only a worker the server called eligible in the current read may be
      // submitted -- a legacy preset included: its profile is checked against
      // the read for the preset's own specialization, never taken on trust.
      ...(hireWorkerAllowed(role.profileId, workerState) ? [] : ["worker"]),
      ...(role.rationale.trim() ? [] : ["rationale"]),
      ...(!role.fromPresetId && role.modelMode === "explicit" && !/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/.test(role.model.trim()) ? ["model"] : []),
      ...(role.specializationRef && (libraryState.kind !== "ready" || !libraryState.catalog.roles.some((item) => sameLibraryRef(item.ref, role.specializationRef))) ? ["specialization"] : [])
    ];
    setRoleErrors(new Set(errors));
    if (errors.length > 0) {
      return;
    }
    const roleInput = { ...role, name: role.name.trim(), rationale: role.rationale.trim() };
    const roleKey = crypto.randomUUID();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const operationNavigation = navigationRevision.current;
    const operationSelection = launchSelectionVersion.current;
    const operationRun = { taskId: runRef.current.taskId, agentId: runRef.current.agentId };
    const targetTaskId = routeRef.current.taskId ?? operationRun.taskId;
    void perform(
      "create-role",
      api,
      async (signal) => {
        const created = await api.createRole(roleInput, signal, roleKey);
        if (!projectSelectionRef.current.isCurrent(generation) || routeRef.current.projectId !== projectId) return;
        setLastHiredRole({ id: created.agentId, name: roleInput.name });
        setBoardRefreshKey((current) => current + 1);
        if (!pendingLaunchRef.current && navigationRevision.current === operationNavigation && launchSelectionVersion.current === operationSelection) {
          setRun((current) => current.taskId === operationRun.taskId && current.agentId === operationRun.agentId
            ? { ...current, agentId: created.agentId, taskId: targetTaskId, contextPackKey: "", designPackageKey: "" } : current);
        }
        setRole((current) => JSON.stringify({ ...current, name: current.name.trim(), rationale: current.rationale.trim() }) === JSON.stringify(roleInput) ? emptyRole : current);
      },
      "created_role",
      projectId
    );
  }

  function submitTask(event: FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    if (actionErrors["create-task"]?.uncertain) return;
    const criteria = task.criteria.split("\n").map((item) => item.trim()).filter(Boolean);
    const errors = [
      ...(task.title.trim() ? [] : ["title"]),
      ...(task.description.trim() ? [] : ["description"]),
      ...(criteria.length > 0 ? [] : ["criteria"])
    ];
    setTaskErrors(new Set(errors));
    if (errors.length > 0) {
      return;
    }
    const input = {
      title: task.title.trim(), description: task.description.trim(),
      criteria, dependencyIds: [...task.dependencyIds], taskKind: task.taskKind ?? "task", parentTaskId: task.parentTaskId ?? null
    };
    const idempotencyKey = taskRetryIdentity.current.forOperation(JSON.stringify(input));
    const operationNavigation = navigationRevision.current;
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const submit = async (): Promise<void> => {
      // A retry may happen after A → B → A. It keeps A's immutable client,
      // input and idempotency key, while taking A's current selection generation.
      if (routeRef.current.projectId !== projectId) return;
      const generation = projectSelectionRef.current.currentGeneration();
      const stillCurrent = (): boolean => projectSelectionRef.current.isCurrent(generation)
        && routeRef.current.projectId === projectId;
      const handle = mutationsRef.current.begin({ projectId, surface: mutationSurface("create-task"), operation: "create-task" }, typeof document === "undefined" ? null : document.activeElement);
      clearActionError("create-task");
      const started = performance.now();
      try {
        const result = await api.createTask(input, new AbortController().signal, idempotencyKey);
        recordInstrumentation("task_create", "confirmed", performance.now() - started);
        if (!stillCurrent()) return;
        api.forgetTaskWrite(idempotencyKey);
        taskRetryIdentity.current.reset();
        setTask((current) => JSON.stringify({
          title: current.title.trim(), description: current.description.trim(),
          criteria: current.criteria.split("\n").map((item) => item.trim()).filter(Boolean),
          dependencyIds: [...current.dependencyIds], taskKind: current.taskKind ?? "task",
          parentTaskId: current.parentTaskId ?? null
        }) === JSON.stringify(input) ? emptyTask : current);
        if (navigationRevision.current === operationNavigation) {
          navigate({ view: "work", taskId: result.taskId, panel: "detail" });
          setRun((current) => ({ ...current, taskId: result.taskId }));
        }
        setState((current) => current.kind === "ready" ? { ...current, notice: "created_task" } : current);
        void refresh();
      } catch (error: unknown) {
        recordInstrumentation("task_create", requestOutcome(error), performance.now() - started);
        if (!stillCurrent()) return;
        recordActionError("create-task", error, () => void submit());
      } finally { mutationsRef.current.end(handle); }
    };
    void submit();
  }

  function setTaskDependency(taskId: string, selected: boolean): void {
    setTask((current) => {
      const dependencyIds = selected
        ? [...new Set([...current.dependencyIds, taskId])]
        : current.dependencyIds.filter((candidate) => candidate !== taskId);
      return { ...current, dependencyIds };
    });
  }

  function focusAuthRecovery(projectId = routeRef.current.projectId, generation = projectSelectionRef.current.currentGeneration()): void {
    window.setTimeout(() => {
      if (projectSelectionRef.current.isCurrent(generation) && routeRef.current.projectId === projectId) {
        authPanelRef.current?.focus();
      }
    }, 0);
  }

  function replaceProviderStatus(status: ProviderAuthStatus): void {
    setState((current) => {
      if (current.kind !== "ready") {
        return current;
      }
      const remaining = current.data.providerAuth.filter(
        (candidate) => candidate.profileId !== status.profileId
      );
      const providerAvailability = current.data.providerAvailability.map((availability) => {
        if (availability.profileId !== status.profileId) {
          return availability;
        }
        const oldRefusal = availability.refusal;
        const nonAuthRefusal = oldRefusal !== null
          && !["provider_authentication_required", "provider_authentication_unconfirmed"].includes(oldRefusal.code)
          ? oldRefusal
          : null;
        const authRefusal = status.blocksLaunch
          ? {
              code: status.state === "authentication_required"
                ? "provider_authentication_required" as const
                : "provider_authentication_unconfirmed" as const,
              remediation: status.state === "authentication_required"
                ? ["authenticate_provider"]
                : ["check_provider_authentication"]
            }
          : null;
        const refusal = nonAuthRefusal ?? authRefusal;
        return {
          ...availability,
          authentication: { state: status.state, freshness: status.freshness },
          refusal,
          launchable: refusal === null
            && availability.installationState === "installed"
            && availability.initializationState === "ready"
            && availability.qualification.state === "qualified"
            && (status.state === "ready" || status.state === "unsupported")
        };
      });
      return {
        ...current,
        data: {
          ...current.data,
          providerAuth: [...remaining, status],
          providerAvailability,
          providerAuthErrors: current.data.providerAuthErrors.filter(
            (profileId) => profileId !== status.profileId
          )
        }
      };
    });
  }


  function restorePendingLaunch(): void {
    const intent = pendingLaunchRef.current;
    if (intent === null) return;
    const restored = restoreLaunchDraft(intent);
    runRef.current = restored;
    setRun(restored);
    navigate({ view: "work", taskId: intent.input.taskId, panel: "run" });
  }

  function retryPendingLaunch(): void {
    const intent = pendingLaunchRef.current;
    if (intent === null) return;
    if (routeRef.current.view !== "work" || !launchIntentIsVisible(intent, routeRef.current.taskId, runRef.current)) {
      restorePendingLaunch();
      return;
    }
    void pendingLaunchRetry.current?.();
  }

  function editRefusedLaunch(): void {
    if (actionErrors["start-run"]?.uncertain || writeInFlight) return;
    restorePendingLaunch();
    pendingLaunchRef.current = null;
    pendingLaunchRetry.current = null;
    setPendingLaunch(null);
    clearActionError("start-run");
  }

  async function launchSelectedRun(): Promise<void> {
    if (pendingLaunchRef.current !== null || state.kind !== "ready" || !state.data.meta.writesEnabled) {
      return;
    }
    const selectedRole = state.data.launch?.roles.find((option) => option.id === run.agentId);
    const selectedPack = state.data.launch?.contextPacks.find(
      (option) => contextPackKey(option) === run.contextPackKey
    );
    const selectedDesignPackage = state.data.launch?.designPackages.find(
      (option) => designPackageKey(option) === run.designPackageKey
    );
    const profileId = selectedRole?.profileId;
    // The control's min/max is convenience only, so the value is re-derived from
    // the typed draft here as well: no request leaves without a valid limit.
    const wallTimeSeconds = runLimitSeconds(run.limitMinutes);
    if (wallTimeSeconds === null) {
      setRunErrors((current) => new Set([...current, "run-limit"]));
      return;
    }
    const authStatus = state.data.providerAuth.find((status) => status.profileId === profileId);
    const key = crypto.randomUUID();
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const input = {
      agentId: run.agentId, taskId: run.taskId,
      contextPackId: selectedPack?.contextPackId ?? null,
      contextPackRevision: selectedPack?.revision ?? null,
      designPackageId: selectedDesignPackage?.designPackageId ?? null,
      designPackageRevision: selectedDesignPackage?.revision ?? null,
      wallTimeSeconds
    };
    const intent = freezeLaunchIntent({ key, input, draft: run,
      taskTitle: dependencies.tasks.find((task) => task.id === run.taskId)?.title
        ?? state.data.launch?.tasks.find((task) => task.id === run.taskId)?.title ?? run.taskId,
      roleName: selectedRole?.name ?? run.agentId, profileId: profileId ?? null });
    pendingLaunchRef.current = intent;
    setPendingLaunch(intent);
    const execute = async (): Promise<void> => {
      const attemptGeneration = projectSelectionRef.current.currentGeneration();
      if (routeRef.current.projectId !== projectId) return;
      const stillCurrent = (): boolean => projectSelectionRef.current.isCurrent(attemptGeneration)
        && routeRef.current.projectId === projectId;
      const handle = mutationsRef.current.begin({ projectId, surface: mutationSurface("start-run"), operation: "start-run" }, typeof document === "undefined" ? null : document.activeElement);
      clearActionError("start-run");
      setRunLimitRefusal(null);
      setLaunchRefusal(null);
      setBudgetRefusal(null);
      const controller = new AbortController();
      const started = performance.now();
      try {
        await api.startRun(intent.input, intent.key, controller.signal);
        recordInstrumentation("run_start", "confirmed", performance.now() - started);
        if (!stillCurrent()) return;
        setPendingLaunch(null);
        pendingLaunchRef.current = null;
        setLaunchedTaskId(intent.input.taskId);
        pendingLaunchRetry.current = null;
        setState((current) => current.kind === "ready" ? { ...current, notice: "run_started" } : current);
        void refresh();
      } catch (error: unknown) {
        recordInstrumentation("run_start", requestOutcome(error), performance.now() - started);
        if (!stillCurrent()) return;
        const problem = error instanceof ApiProblem ? error : null;
        setPendingLaunch(intent);
        pendingLaunchRetry.current = execute;
        // A refused limit is reported by the server, in the server's words, and
        // leaves the entered minutes untouched in the in-memory draft.
        if (isRunLimitRefusal(problem)) {
          setRunLimitRefusal({ taskId: intent.draft.taskId, limitMinutes: intent.draft.limitMinutes });
        }
        // The precheck refused before any attempt existed: the typed code, and
        // the budget object it sent when that object is readable.
        if (budgetExhaustedRefusal(error)) {
          const refusedBudget = launchBudgetFromError(problem?.apiError ?? null);
          setBudgetRefusal({ taskId: intent.draft.taskId, budget: refusedBudget });
          if (refusedBudget !== null) setLaunchBudget({ profileId: refusedBudget.profileId, state: { kind: "ready", budget: refusedBudget } });
        }
        // A pre-attempt admission refusal: the closed code, the server's bounded
        // reason and one next action, tied to the task whose draft was refused.
        const refusal = launchRefusalFromError(problem?.apiError ?? null);
        if (refusal !== null) {
          setLaunchRefusal({ taskId: intent.draft.taskId, refusal });
        }
        if (profileId !== undefined && ["provider_auth_required", "provider_auth_unknown", "credential_store_unavailable"].includes(problem?.apiError?.code ?? "")) {
          try {
            const status = await api.providerAuthStatus(profileId, controller.signal);
            if (!stillCurrent()) return;
            replaceProviderStatus(status);
          } catch {
            if (!stillCurrent()) return;
            /* The unavailable recovery state stays visible. */
          }
          if (!stillCurrent()) return;
          focusAuthRecovery(projectId, attemptGeneration);
        }
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          recordActionError("start-run", error, () => void execute());
        }
      } finally { mutationsRef.current.end(handle); }
    };
    pendingLaunchRetry.current = execute;
    if (profileId !== undefined && (authStatus?.blocksLaunch === true || state.data.providerAuthErrors.includes(profileId))) {
      setPendingLaunch(intent);
      focusAuthRecovery(projectId, generation);
      return;
    }
    await execute();
  }

  async function runProviderAuthAction(
    profileId: string,
    action: "login" | "cancel" | "check"
  ): Promise<void> {
    const generation = projectSelectionRef.current.currentGeneration();
    const projectId = routeRef.current.projectId;
    const api = apiRef.current;
    const operation = `provider-auth-${action}`;
    const handle = mutationsRef.current.begin({ projectId, surface: mutationSurface(operation), operation }, typeof document === "undefined" ? null : document.activeElement);
    const controller = new AbortController();
    try {
      const status = await api.providerAuthAction(profileId, action, controller.signal);
      if (!projectSelectionRef.current.isCurrent(generation)) return;
      replaceProviderStatus(status);
      focusAuthRecovery();
    } catch (error: unknown) {
      if (projectSelectionRef.current.isCurrent(generation) && !(error instanceof DOMException && error.name === "AbortError")) {
        setState((current) => {
          if (current.kind !== "ready") {
            return { kind: "failure", failure: failureFrom(error, text) };
          }
          return {
            ...current,
            data: {
              ...current.data,
              providerAuthErrors: [...new Set([...current.data.providerAuthErrors, profileId])]
            }
          };
        });
        focusAuthRecovery();
      }
    } finally {
      mutationsRef.current.end(handle);
    }
  }

  function submitRun(event: FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    if (pendingLaunchRef.current !== null || state.kind !== "ready" || !state.data.meta.writesEnabled) return;
    const selectedRole = state.kind === "ready"
      ? state.data.launch?.roles.find((option) => option.id === run.agentId)
      : undefined;
    const selectedPack = state.kind === "ready"
      ? state.data.launch?.contextPacks.find(
        (option) => contextPackKey(option) === run.contextPackKey
      )
      : undefined;
    const selectedDesignPackage = state.kind === "ready" && run.designPackageKey !== ""
      ? state.data.launch?.designPackages.find(
        (option) => designPackageKey(option) === run.designPackageKey
      )
      : undefined;
    const selectedAvailability = state.kind === "ready"
      ? state.data.providerAvailability.find(
        (availability) => availability.profileId === selectedRole?.profileId
      )
      : undefined;
    const errors = [
      ...(run.agentId ? [] : ["agent"]),
      ...(run.taskId ? [] : ["task"]),
      ...(runLimitSeconds(run.limitMinutes) === null ? ["run-limit"] : []),
      ...(selectedRole?.contextMode === "accumulated" && selectedPack === undefined
        ? ["context-pack"]
        : []),
      ...(run.designPackageKey !== "" && selectedDesignPackage === undefined
        ? ["design-package"]
        : []),
      ...(selectedRole !== undefined && selectedAvailability?.launchable !== true
        ? ["provider-availability"]
        : [])
    ];
    setRunErrors(new Set(errors));
    if (errors.length > 0) {
      return;
    }
    void launchSelectedRun();
  }

  if (state.kind === "checking") {
    return (
      <main className="work-app work-app-centered">
        <section className="loading-panel" aria-live="polite" role="status">
          <h1>{text("checking_access")}</h1>
        </section>
      </main>
    );
  }

  if (state.kind === "failure") {
    if (state.failure.code === "project_required") {
      return <main className="work-app project-empty-app"><ProjectSidebar creation={projectCreation.current} onPickFolder={pickProjectFolder} currentProjectId={null} legacy={false} locale={locale}
        projects={projectList} text={text} onInspect={inspectProject}
        onCreate={createProject} onSelect={selectProject} onUpdate={updateProject} /></main>;
    }
    return (
      <main className="work-app work-app-centered">
        <FailurePanel failure={state.failure} onRetry={() => void refresh()} text={text} />
      </main>
    );
  }

  const { data, notice } = state;
  const renderedProjectId = route.projectId;
  const renderedProjectGeneration = projectSelectionRef.current.currentGeneration();
  const renderedProjectApi = apiRef.current;
  const configured = data.setup.state === "setup_configured";
  const catalog = data.catalog;
  const launch = data.launch;
  const profileOptions = catalog?.profiles ?? [];
  const selectedHireProfile = profileOptions.find((profile) => profile.id === role.profileId);
  const hireProvider = role.provider || selectedHireProfile?.provider || "";
  const hireProviders = [...new Set(profileOptions.filter((profile) => profile.configured !== false).map((profile) => profile.provider ?? profile.id.split("-")[0]))];
  // The Advanced model default is the chosen worker's own model as the server
  // reported it; the catalog is only a fallback for the legacy preset path.
  const selectedWorker = workerState.kind === "ready"
    ? workerState.workers.find((worker) => worker.profileId === role.profileId)
    : undefined;
  const selectedWorkerModel = selectedWorker?.model ?? selectedHireProfile?.model ?? null;
  const modelOffers = catalog?.modelOptions?.[hireProvider] ?? [];
  const presetOptions = catalog?.presets ?? [];
  const roleOptions = launch?.roles ?? [];
  const taskOptions = launch?.tasks ?? [];
  const contextPackOptions = launch?.contextPacks ?? [];
  const designPackageOptions = launch?.designPackages ?? [];
  const environmentReady = configured && Boolean(launch?.launchEnabled);
  const guidance = data.guidance?.blockerCode === null ? null : data.guidance;
  const canConfigureRuntime = data.setup.state === "setup_unconfigured"
    && guidance?.nextActionKey === "configure_runtime";
  const selectedRole = roleOptions.find((option) => option.id === run.agentId);
  const pendingLaunchVisible = pendingLaunch !== null && launchIntentIsVisible(pendingLaunch, route.taskId, run);
  // The refused reason stays with the exact value that was refused, so editing
  // the minutes or moving to another task retires it without a reset.
  const runLimitRefused = runLimitRefusal !== null
    && runLimitRefusal.taskId === run.taskId && runLimitRefusal.limitMinutes === run.limitMinutes;
  // The refusal belongs to the task it refused; selecting another task retires
  // it without touching the draft it left untouched in memory.
  const launchRefused = launchRefusal !== null && launchRefusal.taskId === run.taskId
    ? launchRefusal.refusal : null;
  // The refused allowance belongs to the task whose launch was refused.
  const budgetRefused = budgetRefusal !== null && budgetRefusal.taskId === run.taskId ? budgetRefusal : null;
  const visibleBudget = launchBudget.profileId !== "" && launchBudget.profileId === runProfileId ? launchBudget.state : { kind: "unknown" as const };
  const selectedProfileId = pendingLaunchVisible ? pendingLaunch?.profileId ?? undefined : selectedRole?.profileId;
  const selectedTeamTask = trackerObservation.kind === "ready" ? trackerObservation.snapshot.tasks.find((task) => task.taskId === route.taskId) : undefined;
  const selectedAvailability = data.providerAvailability.find(
    (availability) => availability.profileId === selectedProfileId
  );
  const selectedAuth = data.providerAuth.find(
    (status) => status.profileId === selectedProfileId
  );
  const visibleAuth = selectedProfileId === undefined
    ? data.providerAuth.find((status) => status.blocksLaunch) ?? null
    : selectedAuth ?? null;
  const authStatusUnavailable = selectedProfileId !== undefined
    && data.providerAuthErrors.includes(selectedProfileId);
  const authActionProfileId = selectedProfileId ?? visibleAuth?.profileId;
  const showAuthRecovery = visibleAuth?.blocksLaunch === true
    || (pendingLaunchVisible && visibleAuth?.state === "ready")
    || authStatusUnavailable;

  function confirmRuntimeConfiguration(): void {
    setConfigurationConfirmationOpen(false);
    const api = apiRef.current;
    void perform("runtime", api, (signal) => api.setup("runtime", signal), "action_complete");
  }

  const workspaceInitialized = !["setup_uninitialized", "setup_not_a_repository"].includes(data.setup.state);
  // Republished by the store on every change, including during a drag.
  const layoutState = layoutEntry.store.snapshot();
  const layout = layoutState.layout;
  const projectTitle = projectList?.projects.find((project) => project.id === renderedProjectId)?.name
    ?? data.meta.repo.split(/[\\/]/).pop() ?? text("shell_nav_work");
  const openProjectChat = (): void => {
    if (compactPane.compact) compactPane.show("chat");
    else if (layout.chatCollapsed) void saveLayout(layoutRef.current.apply({ chatCollapsed: false }));
    window.requestAnimationFrame(() => document.querySelector<HTMLElement>(".chat-pane .project-chat textarea")?.focus({ preventScroll: true }));
  };
  const activityRail = <nav className="activity-rail" aria-label={text("activity_navigation")} inert={compactPane.compact && compactPane.pane !== null}>
    <a title={text("activity_workspace")} aria-label={text("activity_workspace")} aria-current={route.view === "work" || route.view === "board" ? "page" : undefined} href={workRouteHref({ ...route, view: "work" })} onClick={(event) => { if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) { event.preventDefault(); navigate({ view: "work" }); } }}><Icon name="project" size={20} /></a>
    <div className="activity-divider" />
    {(["roles", "skills", "blueprints", "context"] as const).map((tab) => <a key={tab} title={text(`library_${tab}`)} aria-label={text(`library_${tab}`)} aria-current={route.view === "library" && route.libraryTab === tab ? "page" : undefined} href={workRouteHref({ ...route, view: "library", libraryTab: tab })} onClick={(event) => { if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) { event.preventDefault(); navigate({ view: "library", libraryTab: tab }); } }}><Icon name={tab === "roles" ? "supervisor" : tab === "skills" ? "skills" : tab === "blueprints" ? "agents" : "library"} size={20} /></a>)}
    <a className="activity-settings" title={text("shell_nav_settings")} aria-label={text("shell_nav_settings")} aria-current={route.view === "settings" ? "page" : undefined} href={workRouteHref({ ...route, view: "settings" })} onClick={(event) => { if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) { event.preventDefault(); navigate({ view: "settings" }); } }}><Icon name="settings" size={20} /></a>
  </nav>;
  const sidebarPane = <aside className="app-rail" ref={compactPane.compact ? (element) => { compactPane.element.current = element; } : undefined} role={compactPane.compact ? "dialog" : undefined} aria-modal={compactPane.compact ? true : undefined} aria-label={text("shell_navigation")} tabIndex={compactPane.compact ? -1 : undefined}>
    {compactPane.compact ? <button className="button button-secondary compact-pane-close" type="button" onClick={compactPane.close}>{text("workspace_close_pane")}</button> : null}
    <ProjectSidebar creation={projectCreation.current} onPickFolder={pickProjectFolder}
      currentProjectId={route.projectId} onOpenChat={openProjectChat}
      currentProjectPath={data.meta.repo}
      legacy={legacyProjectHost}
      locale={locale}
      projects={projectList}
      text={text}
      onInspect={inspectProject}
      onCreate={createProject}
      onSelect={selectProject}
      onUpdate={updateProject}
    />
    <div className="rail-status"><span className="status-dot" aria-hidden="true" data-state={railSetupState(data.setup.state)} />{text(railSetupLabelKey(data.setup.state))}</div>
    <p className="small-copy rail-help">{text("shell_local_workspace")}</p>
  </aside>;
  const chatPane = <div className="chat-pane" ref={compactPane.compact ? (element) => { compactPane.element.current = element; } : undefined} role={compactPane.compact ? "dialog" : undefined} aria-modal={compactPane.compact ? true : undefined} aria-label={text("workspace_chat_short")} tabIndex={compactPane.compact ? -1 : undefined}>
    {compactPane.compact ? <button className="button button-secondary compact-pane-close" type="button" onClick={compactPane.close}>{text("workspace_close_pane")}</button> : null}
    {workspaceInitialized
      ? <ProjectChat title={projectTitle} collapsed={false} />
      : <section className="project-chat"><p className="small-copy">{text("workspace_needs_setup")}</p></section>}
  </div>;
  const sidebarSeparator = <PaneSeparator pane="sidebar" label={text("workspace_sidebar_width")}
    value={layout.sidebarWidth} min={SIDEBAR_MIN_WIDTH} max={SIDEBAR_MAX_WIDTH}
    direction={layout.panesSwapped ? -1 : 1} valueText={`${layout.sidebarWidth}px`}
    onBeginDrag={() => layoutRef.current.beginDrag("sidebar")}
    onResize={(width) => layoutRef.current.resize("sidebar", width)}
    onCommit={(width) => { layoutRef.current.resize("sidebar", width); void saveLayout(layoutRef.current.endDrag()); }}
    onReset={() => void saveLayout(layoutRef.current.apply({ sidebarWidth: DEFAULT_WORKSPACE_LAYOUT.sidebarWidth }))} />;
  const chatSeparator = <PaneSeparator pane="chat" label={text("workspace_chat_width")}
    value={layout.chatWidth} min={CHAT_MIN_WIDTH} max={CHAT_MAX_WIDTH}
    direction={layout.panesSwapped ? 1 : -1} valueText={`${layout.chatWidth}px`}
    onBeginDrag={() => layoutRef.current.beginDrag("chat")}
    onResize={(width) => layoutRef.current.resize("chat", width)}
    onCommit={(width) => { layoutRef.current.resize("chat", width); void saveLayout(layoutRef.current.endDrag()); }}
    onReset={() => void saveLayout(layoutRef.current.apply({ chatWidth: DEFAULT_WORKSPACE_LAYOUT.chatWidth }))} />;
  return (
    <ConversationWorkspace key={renderedProjectId ?? "legacy"} api={renderedProjectApi} projectId={renderedProjectId} locale={locale} writesEnabled={workspaceInitialized && data.meta.writesEnabled} sessions={conversationSessions.current} onPrepareRun={prepareRunForConversation}>
    <OutputsWorkspace key={renderedProjectId ?? "legacy"} api={renderedProjectApi} projectId={renderedProjectId}
      revision={trackerObservation.kind === "ready" ? trackerObservation.snapshot.sourceRevision : null} locale={locale}
      taskTitles={trackerObservation.kind === "ready" ? new Map(trackerObservation.snapshot.tasks.map((task) => [task.taskId, task.title])) : undefined}
      agentNames={new Map(roleOptions.map((agent) => [agent.id, agent.name]))}
      onOpenTask={(taskId) => navigate({ view: "work", filter: "all", agentId: null, taskId, panel: "detail" })}>
    {/* The work area: a narrow sidebar, the task map at full height, and the
        project chat. Both side panes resize, collapse and swap; the page
        itself never scrolls away from the map. */}
    <main className={`work-app ${workspaceShellClasses(layout)}`}
      data-compact-pane={compactPane.pane ?? "none"}
      data-sidebar={layout.sidebarCollapsed ? "collapsed" : "open"}
      data-chat={layout.chatCollapsed ? "collapsed" : "open"}
      data-swapped={layout.panesSwapped ? "true" : "false"}>
      {activityRail}
      {(compactPane.compact ? compactPane.pane !== "sidebar" : layout.sidebarCollapsed) ? null : sidebarPane}
      {compactPane.compact || layout.sidebarCollapsed ? null : sidebarSeparator}
      {compactPane.compact && compactPane.pane ? <button type="button" tabIndex={-1} className="compact-pane-backdrop" aria-label={text("workspace_close_pane")} onClick={compactPane.close} /> : null}
      <div className="app-content" inert={compactPane.compact && compactPane.pane !== null}>
        <AppHeader locale={locale} onLocaleChange={setLocale} text={text} title={text(`shell_nav_${route.view}`)} hideTitle={route.view === "work" || route.view === "board"}
          layoutControls={<div className="layout-controls" role="group" aria-label={text("workspace_layout_label")}>
            <button type="button" className="button button-secondary button-inline" aria-label={text("workspace_sidebar_short")} title={text("workspace_sidebar_short")} aria-pressed={compactPane.compact ? compactPane.pane === "sidebar" : !layout.sidebarCollapsed}
              onClick={(event) => compactPane.compact ? compactPane.open("sidebar", event) : void saveLayout(layoutRef.current.apply({ sidebarCollapsed: !layout.sidebarCollapsed }))}>
              <Icon name="sidebar" />
            </button>
            <button type="button" className="button button-secondary button-inline" aria-label={text("workspace_chat_short")} title={text("workspace_chat_short")} aria-pressed={compactPane.compact ? compactPane.pane === "chat" : !layout.chatCollapsed}
              onClick={(event) => compactPane.compact ? compactPane.open("chat", event) : void saveLayout(layoutRef.current.apply({ chatCollapsed: !layout.chatCollapsed }))}>
              <Icon name="chat-pane" />
            </button>

            <details className="layout-menu"><summary>{text("workspace_layout_menu")}</summary><div className="layout-menu-content">
            <button type="button" className="button button-secondary button-inline" aria-pressed={layout.panesSwapped}
              onClick={() => void saveLayout(layoutRef.current.apply({ panesSwapped: !layout.panesSwapped }))}>
              {text("workspace_swap_panes")}
            </button>
            <button type="button" className="button button-secondary button-inline"
              onClick={() => void saveLayout(layoutRef.current.restoreDefault())}>
              {text("workspace_restore_layout")}
            </button>
            <p className="small-copy layout-status" role="status">{text(layoutStatusKey(layoutState.save))}</p>
            {layoutState.save.kind === "conflict" ? <button type="button" className="button button-secondary button-inline"
              onClick={() => void layoutEntry.sync.acceptConflict()}>
              {text("workspace_layout_reload")}
            </button> : null}
            {layoutState.save.kind === "unavailable" ? <button type="button" className="button button-secondary button-inline" onClick={() => void layoutEntry.sync.retry()}>{text("workspace_layout_retry")}</button> : null}
            </div></details>
          </div>} />
        <div className="workspace-content">
          {route.view === "work" || route.view === "board" ? <nav className="map-tabs" aria-label={text("map_tabs_label")}>
            {(["work", "board"] as const).map((view) => <a key={view} href={workRouteHref({ ...route, view })} aria-current={route.view === view ? "page" : undefined} onClick={(event) => { if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) { event.preventDefault(); navigate({ view }); } }}><Icon name={view === "work" ? "map" : "agents"} />{text(view === "work" ? "map_tasks" : "map_agents")}</a>)}
            {route.view === "work" ? <button ref={newTaskButton} className="button button-primary" disabled={!workspaceInitialized || !data.meta.writesEnabled} onClick={() => { navigate({ view: "work", panel: "new" }); window.setTimeout(() => document.getElementById("task-title")?.focus(), 0); }} type="button">{text("shell_new_task")}</button> : null}
          </nav> : null}
          {notice !== null ? <p className="notice workspace-notice" role="status">{text(notice)}</p> : null}
          {actionFeedback("refresh")}
          <section hidden={route.view !== "work"} className="work-area" aria-label={text("shell_nav_work")}>
            <div className="work-area-head">
              {!configured ? <div className="notice setup-notice" role="status"><p>{text(workspaceInitialized ? "shell_provider_setup_later" : "workspace_needs_setup")}</p><button className="notice-link" onClick={() => navigate({ view: "settings" })} type="button">{text("shell_open_settings")}</button></div> : null}
            </div>
            <div className="work-area-body">
            {workspaceInitialized ? <TrackerSection api={apiRef.current} locale={locale} text={text} writesEnabled={data.meta.writesEnabled} onObservation={setTrackerObservation}
              selectedTaskId={route.taskId} onSelectTask={openTask} onFocusTask={focusTask}
              detailTaskId={route.view === "work" && route.panel === "detail" ? route.taskId : null} onCloseDetail={closePanel} onLaunchTask={prepareLaunch}
              search={search} onSearchChange={setSearch} filter={route.filter} onFilterChange={(filter) => navigate({ filter })}
              tasksView={route.tasksView} onTasksViewChange={(tasksView) => navigate({ tasksView })}
              agentId={route.agentId} onClearAgent={() => navigate({ agentId: null })}
              viewports={viewportsRef.current} projectId={route.projectId} /> : null}
            {route.view === "work" && route.panel === "new" ? <Modal title={text("shell_new_task")} closeLabel={text("shell_close")} onClose={closeComposer} className="work-panel-new">
              <TaskComposer draft={task} onChange={setTask} submitBlocked={actionErrors["create-task"]?.uncertain === true} errors={taskErrors} busy={writeInFlight} writesEnabled={workspaceInitialized && data.meta.writesEnabled} tasks={dependencies.tasks} dependencyStatus={dependencies.status} onSubmit={submitTask} onClose={closeComposer} onDependency={setTaskDependency} text={text} />
              <MutationFeedback entries={projectMutations} surface="tasks" text={text} />
              {actionFeedback("create-task")}
            </Modal> : null}
            {pendingLaunch !== null ? <LaunchRecoveryPanel intent={pendingLaunch}
              visible={pendingLaunchVisible && route.panel === "run"} busy={writeInFlight || !data.meta.writesEnabled}
              uncertain={actionErrors["start-run"]?.uncertain === true}
              failureCode={actionErrors["start-run"]?.failure.code ?? null}
              onRestore={restorePendingLaunch} onRetry={retryPendingLaunch} onEdit={editRefusedLaunch} text={text} /> : null}
            {route.view === "work" && route.panel === "run" && route.taskId === run.taskId ? <Modal title={text("shell_launch_task")} closeLabel={text("shell_close")} onClose={closePanel} className="work-panel-run launch-composer">
              <div className="composer-heading"><h2>{text("shell_launch_task")}</h2><button className="button button-secondary button-inline" type="button" onClick={closePanel}>{text("shell_close")}</button></div>
          <WorkflowCard ready={false} title={text("step_run")}>
            <p className="small-copy">{text("shell_launch_help")}</p>
            <p className="launch-task-title">{taskOptions.find((option) => option.id === run.taskId)?.title ?? run.taskId}</p>
            <button className="notice-link" type="button" onClick={() => { setHireOpen(true); navigate({ view: "board" }); }}>{text("shell_choose_team")}</button>
            {selectedAvailability && !selectedAvailability.launchable ? <p className="field-error" role="status">{text(availabilityRefusalMessage[selectedAvailability.refusal?.code ?? "provider_authentication_unconfirmed"])}</p> : null}
            {selectedRole && selectedAvailability === undefined ? <p className="field-error" role="status">{text("provider_availability_unavailable")}</p> : null}
            <button className="notice-link" type="button" onClick={() => navigate({ view: "settings" })}>{text("shell_open_settings")}</button>
            {showAuthRecovery ? (
              <section
                aria-labelledby="provider-auth-title"
                aria-live="assertive"
                className="provider-auth-critical"
                ref={authPanelRef}
                role={visibleAuth?.blocksLaunch === true || authStatusUnavailable ? "alert" : "status"}
                tabIndex={-1}
              >
                <p className="provider-auth-severity">{text("provider_auth_critical")}</p>
                <h3 id="provider-auth-title">{text("provider_auth_title")}</h3>
                <p>
                  {visibleAuth === null
                    ? text("provider_auth_status_unavailable")
                    : text(providerAuthStateMessage[visibleAuth.state])}
                </p>
                {visibleAuth !== null ? (
                  <p className="small-copy">
                    {text("provider_auth_profile")} <strong>{visibleAuth.profileId}</strong>. {text("provider_auth_checked_at")} {visibleAuth.checkedAt}
                  </p>
                ) : null}
                <p className="small-copy">{text("provider_auth_secret_boundary")}</p>
                {visibleAuth?.state === "credential_store_unavailable" ? (
                  <p className="small-copy">{text("provider_auth_repair_host_help")}</p>
                ) : null}
                <div className="button-row">
                  {visibleAuth?.actionIds.includes("authenticate") ? (
                    <button
                      className="button button-primary"
                      disabled={writeInFlight || !data.meta.writesEnabled}
                      onClick={() => void runProviderAuthAction(visibleAuth.profileId, "login")}
                      type="button"
                    >
                      {text(providerAuthActionMessage.authenticate)}
                    </button>
                  ) : null}
                  {visibleAuth?.actionIds.includes("cancel_authentication") ? (
                    <button
                      className="button button-secondary button-inline"
                      disabled={writeInFlight || !data.meta.writesEnabled}
                      onClick={() => void runProviderAuthAction(visibleAuth.profileId, "cancel")}
                      type="button"
                    >
                      {text(providerAuthActionMessage.cancel_authentication)}
                    </button>
                  ) : null}
                  {(visibleAuth?.actionIds.includes("check_again") || authStatusUnavailable) && authActionProfileId !== undefined ? (
                    <button
                      className="button button-secondary button-inline"
                      disabled={writeInFlight || !data.meta.writesEnabled}
                      onClick={() => void runProviderAuthAction(authActionProfileId, "check")}
                      type="button"
                    >
                      {text(providerAuthActionMessage.check_again)}
                    </button>
                  ) : null}
                  {pendingLaunchVisible && visibleAuth?.state === "ready" ? (
                    <button
                      className="button button-primary"
                      disabled={writeInFlight}
                      onClick={retryPendingLaunch}
                      type="button"
                    >
                      {text(providerAuthActionMessage.continue_launch)}
                    </button>
                  ) : null}
                </div>
                <MutationFeedback entries={projectMutations} surface="provider-auth" text={text} />
                <p className="small-copy">{text("provider_auth_new_run_only")}</p>
              </section>
            ) : null}
            {notice === "run_started" && launchedTaskId === run.taskId ? (
              <div className="notice" role="status">
                <p>{text("run_started_help")}</p>
                <button className="notice-link" type="button" onClick={() => navigate({ view: "work", taskId: run.taskId, panel: "detail" })}>{text("shell_view_task")}</button>
              </div>
            ) : null}
            <form noValidate onSubmit={submitRun}>
              <fieldset disabled={!data.meta.writesEnabled || writeInFlight || pendingLaunchVisible}>
                <label htmlFor="run-role">{text("select_role")}</label>
                <select aria-invalid={validation([...runErrors], "agent")} id="run-role" onChange={(event) => { ++launchSelectionVersion.current; setRun({ ...run, agentId: event.target.value, contextPackKey: "", designPackageKey: "" }); }} value={run.agentId}>
                  <option value="">{text("select_role")}</option>
                  {roleOptions.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}
                </select>
                {validation([...runErrors], "agent") ? <p className="field-error">{text("form_error_run_role")}</p> : null}
                {roleOptions.length === 0 && configured ? <p className="field-error">{text("no_roles")}</p> : null}
                <label htmlFor="run-design-package">{text("select_design_package")}</label>
                <select
                  aria-describedby="run-design-package-help"
                  aria-invalid={validation([...runErrors], "design-package")}
                  id="run-design-package"
                  onChange={(event) => setRun({ ...run, designPackageKey: event.target.value })}
                  value={run.designPackageKey}
                >
                  <option value="">{text("no_design_package")}</option>
                  {designPackageOptions.map((option) => (
                    <option key={designPackageKey(option)} value={designPackageKey(option)}>
                      {option.title} — {option.screenCount} — {option.designPackageId} @ {option.revision}
                    </option>
                  ))}
                </select>
                <p className="small-copy" id="run-design-package-help">{text("design_package_exact_help")}</p>
                {validation([...runErrors], "design-package") ? <p className="field-error">{text("form_error_design_package")}</p> : null}
                {launch?.designPackageOptionsStatus.truncated ? (
                  <p className="field-error" role="status">{text("design_package_options_truncated")}</p>
                ) : null}
                {selectedRole?.contextMode === "accumulated" ? (
                  <>
                    <label htmlFor="run-context-pack">{text("select_context_pack")}</label>
                    <select
                      aria-describedby="run-context-pack-help"
                      aria-invalid={validation([...runErrors], "context-pack")}
                      id="run-context-pack"
                      onChange={(event) => setRun({ ...run, contextPackKey: event.target.value })}
                      value={run.contextPackKey}
                    >
                      <option value="">{text("select_context_pack")}</option>
                      {contextPackOptions.map((option) => (
                        <option key={contextPackKey(option)} value={contextPackKey(option)}>
                          {option.summary} — {option.contextPackId} @ {option.revision}
                        </option>
                      ))}
                    </select>
                    <p className="small-copy" id="run-context-pack-help">{text("context_pack_exact_help")}</p>
                    {validation([...runErrors], "context-pack") ? <p className="field-error">{text("form_error_context_pack")}</p> : null}
                    {contextPackOptions.length === 0 ? <p className="field-error">{text("no_context_packs")}</p> : null}
                    {launch?.contextPackOptionsStatus.truncated ? (
                      <p className="field-error" role="status">{text("context_pack_options_truncated")}</p>
                    ) : null}
                    <p className="small-copy">{text("context_resume_unavailable")}</p>
                  </>
                ) : selectedRole?.contextMode === "fresh" ? (
                  <p className="small-copy">{text("context_fresh_run_help")}</p>
                ) : null}
                <label htmlFor="run-limit">{text("run_limit_field")}</label>
                <input
                  aria-describedby={["run-limit-help",
                    ...(validation([...runErrors], "run-limit") ? ["run-limit-error"] : []),
                    ...(runLimitRefused ? ["run-limit-refusal"] : [])].join(" ")}
                  aria-invalid={validation([...runErrors], "run-limit") || runLimitRefused}
                  className="launch-limit-minutes"
                  id="run-limit"
                  inputMode="numeric"
                  max={MAX_RUN_LIMIT_MINUTES}
                  min={MIN_RUN_LIMIT_MINUTES}
                  onChange={(event) => setRun({ ...run, limitMinutes: event.target.value })}
                  step={1}
                  type="number"
                  value={run.limitMinutes}
                />
                <p className="small-copy" id="run-limit-help">{text("run_limit_help")}</p>
                {validation([...runErrors], "run-limit") ? <p className="field-error" id="run-limit-error">{text("form_error_run_limit")}</p> : null}
                {runLimitRefused ? <p className="field-error" id="run-limit-refusal" role="alert">{text("run_limit_server_refusal")} {text("form_error_run_limit")}</p> : null}
                {validation([...runErrors], "provider-availability") ? <p className="field-error">{text("form_error_provider_availability")}</p> : null}
                {/* The allowance this run would be launched under: reserved
                    launches for the chosen profile, never a sum of money, and
                    never raised from here. */}
                <section className="launch-budget" aria-labelledby="launch-budget-title">
                  <h3 id="launch-budget-title">{text("budget_title")}</h3>
                  <p className="small-copy">{text("budget_help")}</p>
                  {visibleBudget.kind === "ready" ? <ul className="launch-budget-values">
                    <li>{text("budget_limit")}: <strong>{visibleBudget.budget.limit}</strong></li>
                    <li>{text("budget_used")}: <strong>{visibleBudget.budget.used}</strong></li>
                    <li>{text("budget_remaining")}: <strong>{visibleBudget.budget.remaining}</strong></li>
                  </ul> : <p className={visibleBudget.kind === "loading" ? "small-copy" : "field-error"}>
                    {text(visibleBudget.kind === "loading" ? "budget_loading" : "budget_unknown")}
                  </p>}
                  {visibleBudget.kind === "ready" && visibleBudget.budget.exhausted
                    ? <p className="field-error" role="status">{text("budget_exhausted")}</p> : null}
                  <details className="inspector-technical"><summary>{text("shell_technical_details")}</summary>
                    <p><code>{visibleBudget.kind === "ready" ? visibleBudget.budget.unit : "provider_units"}</code>{visibleBudget.kind === "ready" ? <> · <code>{visibleBudget.budget.profileId}</code></> : null}</p>
                  </details>
                </section>
                {budgetRefused !== null ? <div className="launch-refusal" role="alert">
                  <p className="field-error">{text("budget_refused")}</p>
                  {budgetRefused.budget === null ? <p className="small-copy">{text("budget_unknown")}</p> : null}
                  <code>operator_budget_exhausted</code>
                </div> : null}
                {launchRefused !== null ? <div className="launch-refusal" role="alert">
                  <p className="field-error">{text("launch_refused_before_attempt")}</p>
                  <StopReasonNotice reason={launchRefused} text={text} />
                </div> : null}
                <button className="button button-primary" disabled={!environmentReady || selectedAvailability?.launchable !== true || pendingLaunch !== null} type="submit">{writeInFlight ? text("working") : text("start_run")}</button>
              </fieldset>
            </form>
            <MutationFeedback entries={projectMutations} surface="launch" text={text} />

          </WorkflowCard>
            </Modal> : null}
          </div>
          </section>
          <section hidden={route.view !== "board"} aria-label={text("shell_nav_board")} className="board-view">
            {/* The project-owned session survives provider remounts when switching projects. */}
            {workspaceInitialized ? <ProjectBoard onOpenProjectChat={openProjectChat} session={agentBoardSessions.current.forProject(renderedProjectId)} api={renderedProjectApi} locale={locale} text={text} rolesReady={launch !== null} roles={roleOptions} tracker={trackerObservation}
              active={route.view === "board"} library={libraryState} onChanged={() => { setBoardRefreshKey((n) => n + 1); void refresh(); }}
              onConfigureChild={(supervisorAgentId) => { setRole((current) => ({ ...current, supervisorAgentId })); setHireOpen(true); }}
              writesEnabled={data.meta.writesEnabled && configured} refreshKey={boardRefreshKey} selectedTaskId={route.taskId}
              onOpenTasks={(agentId) => navigate({ view: "work", agentId, panel: null })}
              onGiveTask={(agentId) => {
                const taskId = route.taskId;
                if (taskId === null) { navigate({ view: "work", agentId, panel: null }); return; }
                prepareLaunch(taskId);
                if (pendingLaunchRef.current?.input.taskId !== taskId) setRun((current) => ({ ...current, agentId }));
                navigate({ view: "work" });
              }}
              onAddDepartment={() => navigate({ view: "library", libraryTab: "blueprints" })}
              pendingApplication={pendingApplication} onApplicationPlaced={() => setPendingApplication(null)}
              hireOpen={hireOpen && route.view === "board"} onHireOpenChange={setHireOpen}
              hirePanel={<>
            {lastHiredRole ? <p className="notice" role="status">{text("created_role")}: <strong>{lastHiredRole.name}</strong>{route.taskId ? <button type="button" className="notice-link" onClick={() => { if (route.taskId) { prepareLaunch(route.taskId); if (!pendingLaunchRef.current) setRun((current) => ({ ...current, agentId: lastHiredRole.id })); } }}>{text("shell_use_role")}</button> : null}</p> : null}
            <ul className="team-role-list">{roleOptions.map((option) => <li key={option.id}><div><strong>{option.name}</strong><p className="small-copy">{option.specializationRef ? <><code>{option.specializationRef.id}</code> · </> : null}<code>{option.profileId}</code>{option.model ? <> · <code>{option.model}</code></> : null} · {option.contextMode === "fresh" ? text("context_fresh") : text("context_accumulated")}</p></div>
              <OutputsButton scope={{ kind: "agent", id: option.id }} title={option.name} />
              <ConversationButton scope={{ kind: "agent", id: option.id }} title={option.name} />
              {/* Opens Prepare run for the selected task and issues nothing, so a
                  write elsewhere never takes this away. */}
              <button className="button button-secondary button-inline" type="button" disabled={!selectedTeamTask || !data.meta.writesEnabled}
                onClick={() => { if (!selectedTeamTask) return; prepareLaunch(selectedTeamTask.taskId); if (pendingLaunchRef.current?.input.taskId !== selectedTeamTask.taskId) setRun((current) => ({ ...current, agentId: option.id })); }}>{text("shell_use_role")}</button>
            </li>)}</ul>
            {roleOptions.length === 0 ? <p className="empty-guidance">{text("shell_no_active_roles")}</p> : null}
          <WorkflowCard ready={roleOptions.length > 0} title={text("step_role")}>
            <p className="small-copy">{text("role_help")}</p>
            <form id="hire-role-form" noValidate onSubmit={submitRole}>
              <fieldset disabled={!configured || !data.meta.writesEnabled || writeInFlight}>
                <label>{text("agent_supervisor")}<select value={role.supervisorAgentId ?? ""} onChange={(event) => setRole((current) => ({ ...current, supervisorAgentId: event.target.value || null }))}><option value="">{text("agent_no_supervisor")}</option>{roleOptions.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}</select></label>
                <SpecializationPicker library={libraryState} value={role.specializationRef} selectedName={role.specializationName} text={text} onChange={(selected) => chooseSpecialization(selected)} onRefresh={() => setLibraryRefresh((current) => current + 1)} />
                {roleErrors.has("specialization") ? <p className="field-error">{text("library_selection_unavailable")}</p> : null}
                <details className="role-legacy-presets"><summary>{text("role_legacy_presets")}</summary>
                <RolePresetPicker
                  presets={presetOptions}
                  value={role.fromPresetId}
                  text={text}
                  onChange={(id) => setRole((current) => {
                    // A preset answers the specialization question with its own
                    // recorded ref, so the worker step reads eligibility for it;
                    // a preset without one leaves the step idle and the hire blocked.
                    const preset = presetOptions.find((candidate) => candidate.id === id);
                    return { ...chooseRolePreset(current, id, presetOptions), specializationRef: preset?.specializationRef ?? null, specializationName: "", provider: "" };
                  })}
                />
                </details>
                <WorkerPicker state={workerState} value={role.profileId} refusal={hireRefusal}
                  invalid={roleErrors.has("worker")} onChange={chooseWorker}
                  onRetry={() => setWorkerRefresh((current) => current + 1)} text={text} />
                {profileOptions.length === 0 && configured ? <p className="field-error">{text("no_profiles")}</p> : null}
                <label htmlFor="role-name">{text("role_name")}</label>
                <input
                  aria-describedby={validation([...roleErrors], "name") ? "role-name-error" : undefined}
                  aria-invalid={validation([...roleErrors], "name")}
                  id="role-name"
                  onChange={(event) => setRole({ ...role, name: event.target.value })}
                  placeholder={text("role_name_placeholder")}
                  value={role.name}
                />
                {validation([...roleErrors], "name") ? <p className="field-error" id="role-name-error">{text("form_error_role_name")}</p> : null}
                {/* Closed by default: provider and model already default to the
                    chosen worker's own, and stay editable for the rare override. */}
                <details className="role-advanced"><summary>{text("role_advanced")}</summary>
                <label htmlFor="role-provider">{text("role_provider")}</label>
                <select id="role-provider" disabled={role.fromPresetId !== ""} value={hireProvider} onChange={(event) => { const provider = event.currentTarget.value; setRole((current) => chooseRoleProvider(current, provider)); }}>
                  <option value="">{text("role_select_provider")}</option>{hireProviders.map((provider) => <option key={provider} value={provider}>{provider}</option>)}
                </select>
                {!role.fromPresetId ? <><label htmlFor="role-model-mode">{text("role_model")}</label><select id="role-model-mode" value={role.modelMode} onChange={(event) => { const modelMode = event.currentTarget.value as "profile" | "explicit"; setRole((current) => ({ ...current, modelMode })); }}><option value="profile">{text("role_model_profile")}</option><option value="explicit">{text("role_model_explicit")}</option></select>
                  {role.modelMode === "explicit" ? <><label htmlFor="role-model">{text("role_model")}</label><input id="role-model" list="role-model-offers" value={role.model} aria-invalid={roleErrors.has("model")} aria-describedby="role-model-help" onChange={(event) => { const model = event.currentTarget.value; setRole((current) => ({ ...current, model })); }} /><datalist id="role-model-offers">{modelOffers.map((model) => <option key={model} value={model} />)}</datalist>{roleErrors.has("model") ? <p className="field-error">{text("role_model_error")}</p> : null}</> : <p className="small-copy">{text("role_model_current")} <code>{selectedWorkerModel ?? text("role_model_unspecified")}</code></p>}
                  <p className="small-copy" id="role-model-help">{text("role_model_help")}</p></> : null}
                </details>
                <label htmlFor="role-rationale">{text("role_rationale")}</label>
                <textarea
                  aria-describedby={validation([...roleErrors], "rationale") ? "role-rationale-error" : undefined}
                  aria-invalid={validation([...roleErrors], "rationale")}
                  id="role-rationale"
                  onChange={(event) => setRole({ ...role, rationale: event.target.value })}
                  placeholder={text("role_rationale_placeholder")}
                  rows={3}
                  value={role.rationale}
                />
                {validation([...roleErrors], "rationale") ? <p className="field-error" id="role-rationale-error">{text("form_error_rationale")}</p> : null}
                <label htmlFor="context-mode">{text("context_mode")}</label>
                <select disabled={role.fromPresetId !== ""} id="context-mode" onChange={(event) => setRole({ ...role, contextMode: event.target.value })} value={role.contextMode}>
                  <option value="fresh">{text("context_fresh")}</option>
                  <option value="accumulated">{text("context_accumulated")}</option>
                </select>
                <button className="button button-primary" disabled={actionErrors["create-role"]?.uncertain === true} type="submit">{writeInFlight ? text("working") : text("create_role")}</button>
              </fieldset>
            </form>
            <MutationFeedback entries={projectMutations} surface="roles" text={text} />
            {actionFeedback("create-role")}
          </WorkflowCard>
              </>} /> : route.view === "board" ? <div className="notice setup-notice" role="status"><p>{text("workspace_needs_setup")}</p><button className="notice-link" type="button" onClick={() => navigate({ view: "settings" })}>{text("shell_nav_settings")}</button></div> : null}
          </section>
          <section hidden={route.view !== "library"} aria-label={text("shell_nav_library")}>
            {appliedBlueprint ? <BlueprintApplyOutcomePanel text={text} onIntent={followBlueprintIntent}
              outcome={blueprintApplyOutcome(appliedBlueprint, trackerObservation)} /> : null}
            {workspaceInitialized ? <LibrarySection key={route.projectId ?? "legacy"} api={apiRef.current} text={text} writesEnabled={data.meta.writesEnabled}
              libraryApi={libraryApiRef.current} libraryState={libraryState} onRefreshLibrary={() => setLibraryRefresh((current) => current + 1)} onChooseRole={(selected) => chooseSpecialization(selected, true)}
              profiles={profileOptions} locale={locale} projectId={route.projectId} onBlueprintApplied={(application) => {
                if (!projectSelectionRef.current.isCurrent(renderedProjectGeneration) || routeRef.current.projectId !== renderedProjectId) return;
                // The server created roles and tasks and started nothing. Read
                // the refreshed snapshot before offering any next step.
                setAppliedBlueprint(application);
                setPendingApplication({ application, title: application.blueprintId });
                void refresh();
              }}
              tab={route.libraryTab} onTabChange={(libraryTab) => navigate({ libraryTab })} /> : <p>{text("workspace_needs_setup")}</p>}
          </section>
          <section hidden={route.view !== "settings"} aria-label={text("shell_nav_settings")} className="settings-section">
          <WorkflowCard ready={environmentReady} title={text("step_environment")}>
            <p>{configured ? text("workspace_ready") : text("workspace_needs_setup")}</p>
            <p className="small-copy">{configured ? text("runtime_help") : text("environment_help")}</p>
            {!configured ? (
              <>
                {guidance !== null ? (
                  <section aria-live="polite" className="notice">
                    {guidance.tools.length > 0 ? (
                      <p>{text("guidance_missing_tools")} <strong>{guidance.tools.join(", ")}</strong></p>
                    ) : null}
                    <p>{text(guidanceActionMessage[guidance.nextActionKey])}</p>
                    {/* Checking again only reads the environment. */}
                    <button
                      className="button button-secondary"
                      onClick={() => void refresh()}
                      type="button"
                    >
                      {text("check_again")}
                    </button>
                  </section>
                ) : null}
                <div className="button-row">
                  {data.setup.state === "setup_uninitialized" ? (
                  <button
                    className="button button-primary"
                    disabled={writeInFlight}
                    onClick={() => { const api = apiRef.current; void perform("initialize", api, (signal) => api.setup("initialize", signal), "action_complete"); }}
                    type="button"
                  >
                    {writeInFlight ? text("working") : text("initialize_workspace")}
                  </button>
                  ) : null}
                  {canConfigureRuntime ? (
                  <button
                    className="button button-primary"
                    disabled={writeInFlight}
                    onClick={() => setConfigurationConfirmationOpen(true)}
                    type="button"
                  >
                    {text("configure_runtime")}
                  </button>
                  ) : null}
                </div>
                {configurationConfirmationOpen ? (
                  <section
                    aria-describedby="configuration-confirmation-details"
                    aria-labelledby="configuration-confirmation-title"
                    aria-modal="true"
                    className="notice"
                    role="dialog"
                  >
                    <h3 id="configuration-confirmation-title">{text("configuration_confirmation_title")}</h3>
                    <p id="configuration-confirmation-details">{text("configuration_confirmation_write")}</p>
                    <p>{text("configuration_confirmation_non_actions")}</p>
                    <div className="button-row">
                      <button className="button button-primary" disabled={writeInFlight} onClick={confirmRuntimeConfiguration} type="button">
                        {writeInFlight ? text("working") : text("configuration_confirmation_confirm")}
                      </button>
                      {/* Dismissing the question writes nothing and stays answerable. */}
                      <button className="button button-secondary" onClick={() => setConfigurationConfirmationOpen(false)} type="button">
                        {text("configuration_confirmation_cancel")}
                      </button>
                    </div>
                  </section>
                ) : null}
              </>
            ) : null}
            <MutationFeedback entries={projectMutations} surface="setup" text={text} />
            {actionFeedback("initialize")}
            {actionFeedback("runtime")}
          </WorkflowCard>
            <div className="settings-panel"><h2>{text("shell_project_details")}</h2><p className="project-name">{showFullProjectPath ? <code>{data.meta.repo}</code> : repositoryBasename(data.meta.repo)}</p><button className="notice-link" type="button" onClick={() => setShowFullProjectPath((visible) => !visible)}>{text(showFullProjectPath ? "hide_full_project_path" : "show_full_project_path")}</button></div>
            <ProjectEnvironment api={renderedProjectApi} locale={locale} />
            <section aria-labelledby="provider-availability-title" className="provider-availability" role="status">
              <h3 id="provider-availability-title">{text("provider_availability_title")}</h3>
              {data.providerAvailability.length === 0 ? (
                <p className="field-error">{text("provider_availability_unavailable")}</p>
              ) : data.providerAvailability.map((availability) => (
                <article className="provider-availability-item" key={availability.profileId}>
                  <p>
                    <strong>{availability.profileId}</strong> — {availability.provider}
                    {availability.model === null ? "" : ` / ${availability.model}`}
                  </p>
                  <ul className="provider-readiness">
                    {providerReadinessLines(availability).map((line) => (
                      <li key={line.stage} data-state={line.tone}>
                        <span className="provider-readiness-stage">{text(line.labelKey)}</span>
                        <span className="provider-readiness-value">{text(line.valueKey)}</span>
                      </li>
                    ))}
                  </ul>
                  <p className={availability.launchable ? "small-copy" : "field-error"}>
                    {availability.launchable
                      ? text("provider_availability_launchable")
                      : text(availabilityRefusalMessage[availability.refusal?.code ?? "provider_authentication_unconfirmed"])}
                  </p>
                  <ProviderQualificationAction availability={availability} locale={locale} />
                  <details className="provider-readiness-technical">
                    <summary>{text("provider_readiness_technical")}</summary>
                    <ul className="small-copy">
                      {providerReadinessLines(availability).map((line) => (
                        <li key={line.stage}><code>{line.stage}</code>: <code>{line.code}</code></li>
                      ))}
                      <li><code>refusal</code>: <code>{availability.refusal?.code ?? "none"}</code></li>
                    </ul>
                  </details>
                  <ul className="small-copy">
                    {availability.capabilityRefusals.map((refusal) => (
                      <li key={refusal.code}>{text(capabilityRefusalMessage[refusal.code])}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </section>
            <InstrumentationSettings instrumentation={instrumentation} unavailable={instrumentationUnavailable}
              busy={instrumentationBusy} writesEnabled={workspaceInitialized && data.meta.writesEnabled}
              hint={instrumentationHint} clearAsked={instrumentationClearAsked}
              onToggle={(enabled) => void toggleInstrumentation(enabled)}
              onAskClear={() => setInstrumentationClearAsked(true)}
              onCancelClear={() => setInstrumentationClearAsked(false)}
              onConfirmClear={() => void clearInstrumentation()} text={text} />
            <div className="settings-panel"><h2>{text("shell_diagnostics")}</h2><p className="small-copy">{text("legacy_panel_help")}</p><a className="legacy-link" href="/">{text("open_legacy_panel")}</a>{/* Reading the current status never waits on a write. */}<button className="button button-secondary" onClick={() => void refresh()} type="button">{text("refresh_status")}</button></div>
          </section>
        </div>
      </div>
      {compactPane.compact || layout.chatCollapsed ? null : chatSeparator}
      {(compactPane.compact ? compactPane.pane !== "chat" : layout.chatCollapsed) ? null : chatPane}
    </main>
    </OutputsWorkspace>
    </ConversationWorkspace>
  );
}

const rootElement = document.getElementById("root");
if (rootElement === null) {
  throw new Error("work_root_missing");
}
createRoot(rootElement).render(<WorkApp />);
