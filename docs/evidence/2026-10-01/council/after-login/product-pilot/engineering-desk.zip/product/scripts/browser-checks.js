'use strict';
(() => {
  const checks = [];
  const assert = (condition, name) => { if (!condition) throw new Error(name); checks.push(name); };
  const count = selector => document.querySelectorAll(selector).length;
  const search = query => { byId('search').value = query; byId('search').dispatchEvent(new Event('input', { bubbles: true })); };
  const chooseStatus = status => { byId('status').value = status; byId('status').dispatchEvent(new Event('change', { bubbles: true })); };
  const report = document.createElement('pre'); report.id = 'browser-check-report';
  try {
    assert(count('.task-row') === 6 && count('.result-card') === 4, 'Initial tasks and results');
    assert(document.documentElement.scrollWidth <= window.innerWidth, 'No horizontal page overflow');
    document.querySelector('[data-agent="mira"]').click();
    assert(count('.task-row') === 2 && count('.result-card') === 1, 'Agent scopes tasks and results');
    assert(document.querySelector('[data-agent="mira"]').getAttribute('aria-pressed') === 'true', 'Agent selected state exposed');
    chooseStatus('Planned');
    assert(count('.task-row') === 1 && count('.result-card') === 0 && byId('results').textContent.includes('No results here yet'), 'Combined filters and no-result state');
    byId('reset').click();
    search('  ED-103  ');
    assert(count('.task-row') === 1 && count('.result-card') === 1, 'Trimmed task ID search');
    search('CALMER');
    assert(count('.task-row') === 1 && document.querySelector('.task-row').dataset.task === 'ED-102', 'Case-insensitive result title search');
    search('<img src=x onerror=alert(1)>');
    assert(count('.task-row') === 0 && count('.result-card') === 0 && !document.querySelector('#tasks img'), 'Empty search and inert input');
    document.querySelector('[data-reset]').click();
    assert(count('.task-row') === 6 && document.activeElement === byId('search'), 'Reset restores content and search focus');
    chooseStatus('Blocked');
    assert(byId('tasks').textContent.includes('Waiting for retention requirements') && count('.result-card') === 0, 'Honest blocked state');
    byId('reset').click();
    const opener = document.querySelector('[data-open]'); opener.focus(); opener.click();
    assert(byId('result-dialog').open && byId('dialog-meta').textContent.includes('Produced by Atlas'), 'Result dialog with provenance');
    byId('close-dialog').click();
    assert(!byId('result-dialog').open && document.activeElement === opener, 'Dialog closes and restores focus');
    assert(count('.agent-button') === 4 && count('label[for="search"]') === 1 && count('label[for="status"]') === 1, 'Native controls and accessible labels');
    report.dataset.status = 'pass';
    report.textContent = JSON.stringify({ status: 'pass', width: innerWidth, checks });
  } catch (error) { report.dataset.status = 'fail'; report.textContent = JSON.stringify({ status: 'fail', checks, error: error.message }); }
  document.body.append(report);
})();
