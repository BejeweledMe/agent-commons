"""Reproducible, dependency-free static build: python3 build.py."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
FILES = {"index.html": "index.html", "styles.css": "styles.css", "app.js": "app.js", "scripts/browser-checks.js": "browser-checks.js"}

def build():
    destination = ROOT / "site"
    destination.mkdir(exist_ok=True)
    manifest = {}
    for source, target in FILES.items():
        content = (ROOT / source).read_bytes()
        (destination / target).write_bytes(content)
        manifest[target] = hashlib.sha256(content).hexdigest()
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(f"Built {len(FILES)} files in site/ (no dependencies)")
    return manifest

if __name__ == "__main__":
    build()
