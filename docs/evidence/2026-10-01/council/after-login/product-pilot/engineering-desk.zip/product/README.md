# Engineering Desk

A responsive static workspace demo built with HTML, CSS and JavaScript. Six illustrative tasks, three specialist agents and four sample results show how work and its provenance can be browsed together. All content is demo data, not live Agent Commons state.

## Run locally

Python 3's standard library is sufficient to build and serve:

```sh
python3 build.py
python3 -m http.server 8080 --bind 127.0.0.1 --directory site
```

Open `http://127.0.0.1:8080`. No package installation, CDN, external fonts or backend is required. You can also open `site/index.html` directly in a browser. The build copies explicit source files into `site/` and writes a deterministic SHA-256 manifest.

If `python3` is unavailable in this provisioned workspace, use `/Users/dmitrijersov/.local/share/uv/tools/agent-commons/bin/python` instead.

## Use

- Select Everyone or an agent to scope both tasks and results.
- Search by task ID, title, discipline, agent, result title or result type. Search is case-insensitive; surrounding whitespace is ignored.
- Combine the search with a task status. A result appears only when its source task matches.
- Use Reset or Clear all filters to restore the whole desk.
- Open View result to read its sample content, producer, type and task reference. Escape or the close button dismisses the native dialog.
- All controls use native keyboard behavior; Tab moves focus, Enter/Space activates buttons, and the select supports arrow-key selection. A skip link leads to the workspace.

## Validation

```sh
python3 check.py
```

Requires Node.js for its built-in JavaScript parser and VM; no npm packages are used. Checks the deterministic build, local assets, JS syntax and 14 assertions against the actual application's data/filter functions: referential integrity, distinct states, combined filters, result-title search, empty matches and escaping. Writes `outputs/validation.json`. This is not browser validation.

On a host that allows Chrome and loopback serving:

```sh
python3 check.py --browser
```

Chrome defaults to the standard macOS application path, or `google-chrome` on PATH. Override with `CHROME_BIN`. The optional checks exercise the real rendered DOM at 1440, 390 and 320 pixels, including filter updates, empty states, dialog provenance, focus restoration and horizontal overflow. Browser profiles are temporary and repo-local. Actual Tab-key navigation and visual quality still need manual browser review.

### Evidence from this attempt

The default validation passed. The sandbox denied local server binding (`Operation not permitted`), and a separate headless Chrome attempt using a local file and repo-local profile exited with code 134 before producing DOM output. Therefore browser validation and browser screenshots are **unavailable**, not passed.

`outputs/engineering-desk-desktop-v2.png` and `outputs/engineering-desk-mobile-v2.png` are **design previews rendered with AppKit**, using the product's data and a translation of its layout. They are not browser screenshots and cannot demonstrate CSS rendering, responsiveness or keyboard behavior. A visible label is included in each image. `outputs/engineering-desk.png` is a convenience copy of the desktop design preview. Published versioned PNG bytes must not be overwritten.

To generate new design previews on macOS, first run the check command to export the sample data, then use `swift -module-cache-path outputs/swift-module-cache scripts/render-preview.swift`. The script refuses to overwrite its versioned outputs. Choose new versioned filenames before re-rendering.

## Scope and limitations

No persistence, task editing, real agents, authentication, remote artifacts or network integration. Result content is illustrative prose inside a dialog. The blocked task names its missing input; planned and blocked tasks have no invented result. A demo task marked Done is a fictional state, not an assertion that project work was reviewed or accepted. The workspace totals always describe the full sample dataset; section counts describe the current filter.

Sources: `index.html`, `styles.css`, `app.js`. Build output: `site/`. Verification helpers: `scripts/`, `check.py`. Changes remain uncommitted for independent review. Canonical delegation completion is a work report; parent review and task acceptance are separate.
