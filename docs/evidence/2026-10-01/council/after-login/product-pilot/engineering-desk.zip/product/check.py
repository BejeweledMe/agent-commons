"""Check build reproducibility, local asset links and real Chrome DOM behavior."""
from pathlib import Path
from html.parser import HTMLParser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import functools
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import argparse
from build import ROOT, build

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.assets = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and 'src' in attrs:
            self.assets.append(attrs['src'])
        if tag == 'link' and attrs.get('rel') == 'stylesheet':
            self.assets.append(attrs['href'])

def main():
    args = argparse.ArgumentParser()
    args.add_argument('--browser', action='store_true', help='Also run real Chrome DOM checks (requires local HTTP binding).')
    options = args.parse_args()
    first = build()
    assert first == build(), 'Build must be reproducible'
    parser = Links()
    parser.feed((ROOT / 'site/index.html').read_text())
    assert parser.assets, 'Expected local assets'
    for asset in parser.assets:
        assert '://' not in asset and (ROOT / 'site' / asset).is_file(), f'Invalid local asset: {asset}'
    node = shutil.which('node')
    if not node:
        raise SystemExit('Node.js is required for JavaScript syntax and behavior validation (no packages).')
    subprocess.run([node, '--check', str(ROOT / 'app.js')], check=True)
    subprocess.run([node, '--check', str(ROOT / 'scripts/browser-checks.js')], check=True)
    subprocess.run([node, str(ROOT / 'scripts/check.js')], check=True)
    if not options.browser:
        (ROOT / 'outputs/validation.json').write_text(json.dumps({'build_sha256': first, 'checks': 'Reproducible build, local assets, JavaScript syntax, 14 data/filter assertions', 'browser': 'NOT RUN by this command. Use --browser for real DOM validation.'}, indent=2) + '\n')
        print('PASS: build, asset, JavaScript and filter checks. Browser checks require --browser.')
        return
    chrome = os.environ.get('CHROME_BIN') or shutil.which('google-chrome') or '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
    if not Path(chrome).is_file():
        raise SystemExit('Static checks passed; browser checks NOT RUN. Set CHROME_BIN to a Chrome executable.')
    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, *args): pass
    handler = functools.partial(QuietHandler, directory=str(ROOT / 'site'))
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    reports = []
    try:
        for width, height in [(1440, 1200), (390, 844), (320, 740)]:
            # Chrome refuses very narrow outer windows unless device metrics are used;
            # headless window-size is validated against the reported innerWidth below.
            with tempfile.TemporaryDirectory(prefix='chrome-check-', dir=ROOT / 'outputs') as profile:
                command = [chrome, '--headless', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--disable-background-networking', '--hide-scrollbars', f'--user-data-dir={profile}', f'--window-size={width},{height}', '--virtual-time-budget=1500', '--dump-dom', f'http://127.0.0.1:{server.server_port}/?check=1']
                run = subprocess.run(command, capture_output=True, text=True, timeout=45)
                match = re.search(r'<pre id="browser-check-report" data-status="pass">(.*?)</pre>', run.stdout, re.S)
                if run.returncode or not match:
                    failure = re.search(r'<pre id="browser-check-report".*?</pre>', run.stdout, re.S)
                    raise AssertionError(f'Browser checks failed at requested width {width}: {failure.group(0) if failure else run.stderr[-1500:]}')
                from html import unescape
                report = json.loads(unescape(match.group(1)))
                assert report['width'] == width, f'Unexpected browser viewport: {report["width"]}, wanted {width}'
                reports.append(report)
                print(f'PASS: {len(report["checks"])} browser assertions at {width}px')
    finally:
        server.shutdown()
        server.server_close()
    (ROOT / 'outputs/validation.json').write_text(json.dumps({'build_sha256': first, 'source': 'Local headless Google Chrome, actual DOM interactions', 'reports': reports}, indent=2) + '\n')
    print('PASS: reproducible build and local asset integrity; outputs/validation.json written')

if __name__ == '__main__':
    main()
