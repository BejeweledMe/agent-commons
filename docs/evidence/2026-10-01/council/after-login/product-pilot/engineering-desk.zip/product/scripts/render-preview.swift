import AppKit
import Foundation

// This is an AppKit design rendering of the implemented layout, NOT a browser screenshot.
let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let data = try Data(contentsOf: root.appendingPathComponent("outputs/demo-data.json"))
let demo = try JSONSerialization.jsonObject(with: data) as! [String: Any]
let tasks = demo["tasks"] as! [[String: Any]]
let results = demo["results"] as! [[String: Any]]
let agents = demo["agents"] as! [[String: Any]]
func color(_ hex: UInt32) -> NSColor { NSColor(red: CGFloat((hex >> 16) & 255)/255, green: CGFloat((hex >> 8) & 255)/255, blue: CGFloat(hex & 255)/255, alpha: 1) }
let ink = color(0x263c35), muted = color(0x64736b), line = color(0xdce2d6), green = color(0x235d43)
func render(width: Int, height: Int, name: String) throws {
 let url = root.appendingPathComponent("outputs/" + name)
 if FileManager.default.fileExists(atPath: url.path) { throw NSError(domain:"Immutable preview already exists", code:1) }
 let bitmap = NSBitmapImageRep(bitmapDataPlanes:nil, pixelsWide:width, pixelsHigh:height, bitsPerSample:8, samplesPerPixel:4, hasAlpha:true, isPlanar:false, colorSpaceName:.deviceRGB, bytesPerRow:0, bitsPerPixel:0)!
 NSGraphicsContext.saveGraphicsState()
 NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep:bitmap)
 let ctx = NSGraphicsContext.current!.cgContext
 ctx.translateBy(x:0,y:CGFloat(height)); ctx.scaleBy(x:1,y:-1)
 func box(_ x: CGFloat,_ y: CGFloat,_ w: CGFloat,_ h: CGFloat,_ fill: NSColor,_ radius: CGFloat = 0) {
  fill.setFill(); NSBezierPath(roundedRect:NSRect(x:x,y:y,width:w,height:h),xRadius:radius,yRadius:radius).fill()
 }
 func text(_ value: String,_ x: CGFloat,_ y: CGFloat,_ size: CGFloat = 14,_ c: NSColor = ink,_ serif: Bool = false,_ bold: Bool = false,_ width: CGFloat = 900) {
  let font = serif ? NSFont(name:"Georgia",size:size)! : (bold ? NSFont.boldSystemFont(ofSize:size) : NSFont.systemFont(ofSize:size))
  let style = NSMutableParagraphStyle(); style.lineBreakMode = .byWordWrapping
  let attrs:[NSAttributedString.Key:Any] = [.font:font,.foregroundColor:c,.paragraphStyle:style]
  NSGraphicsContext.saveGraphicsState()
  // AppKit text draws into an explicitly flipped coordinate system.
  ctx.translateBy(x:x,y:y+150); ctx.scaleBy(x:1,y:-1)
  NSAttributedString(string:value,attributes:attrs).draw(with:NSRect(x:0,y:0,width:width,height:150),options:[.usesLineFragmentOrigin],context:nil)
  NSGraphicsContext.restoreGraphicsState()
 }
 let mobile = width < 600
 let w = CGFloat(width), margin:CGFloat = mobile ? 20 : 58
 box(0,0,w,CGFloat(height),color(0xf7f8f2))
 box(0,0,w,68,color(0xfffefa)); box(0,68,w,1,line)
 box(margin,19,30,30,green,8); text("e↗",margin+5,20,20,.white,true)
 text("Engineering Desk",margin+42,24,mobile ? 15 : 18,ink,false,true)
 if !mobile { text("COMMON GROUND  /  WORKSPACE 01",w/2-110,27,10,muted); }
 text("DEMO",w-68,27,10,green,false,true)
 text("A LITTLE CLARITY FOR THE WORK AHEAD",margin,100,mobile ? 8 : 10,green,false,true)
 text("Good work, in view.",margin,126,mobile ? 38 : 54,ink,true)
 text("Follow the tasks. Meet the agents.\nExplore what they made.",margin,mobile ? 182 : 198,14,muted,false,false,mobile ? 320 : 800)
 let sy:CGFloat = mobile ? 250 : 264
 box(margin,sy,w-margin*2,1,line)
 for (i,label) in ["Tasks on the desk","Specialist agents","Results to explore"].enumerated() {
  let x = margin + CGFloat(i)*(w-margin*2)/3
  text(label,x,sy+17,mobile ? 9 : 11,muted)
  text(["06","03","04"][i],x,sy+34,30)
 }
 box(margin,sy+85,w-margin*2,1,line)
 let top = sy+116
 text("The team",margin,top,18,ink,false,true)
 text("Choose an agent to see their work.",margin,top+28,11,muted)
 let teamNames = ["Everyone"] + agents.map{$0["name"] as! String}
 let roles = ["The whole picture"] + agents.map{$0["role"] as! String}
 for i in 0..<4 {
  let x:CGFloat = mobile ? margin+CGFloat(i%2)*178 : margin
  let y:CGFloat = mobile ? top+55+CGFloat(i/2)*65 : top+55+CGFloat(i)*68
  box(x,y,mobile ? 170 : 210,58,i == 0 ? color(0xeaf0dd) : color(0xf0f2e9),7)
  box(x+9,y+13,30,30,i == 0 ? green : color(0xdce3d1),15)
  text(i == 0 ? "✳" : String(teamNames[i].prefix(1)),x+17,y+18,14,i == 0 ? .white : ink)
  text(teamNames[i],x+47,y+10,12,ink,false,true)
  text(roles[i],x+47,y+30,9,muted,false,false,120)
 }
 if !mobile { box(margin,top+345,210,210,color(0xeef0e5),8); text("↳",margin+20,top+358,30); text("A shared desk.\nA clear trail.",margin+20,top+400,26,ink,true,false,185); text("Every result belongs to a task\nand the agent who produced it.\n\nAll content is illustrative.",margin+20,top+477,11,muted,false,false,180) }
 let x:CGFloat = mobile ? margin : margin+250
 let board:CGFloat = mobile ? top+215 : top
 let bw = w-x-margin
 text("On the desk",x,board,18,ink,false,true); text("6",x+120,board+3,12,muted)
 box(x,board+38,bw,mobile ? 39 : 42,color(0xfffefa),6)
 text("⌕  Search tasks, results, or a task ID…",x+12,board+50,12,muted)
 let filterY = board+88
 text("All statuses  ▾",x+10,filterY,11,muted); text("Reset",x+bw-40,filterY,11,green)
 let ty = board+119
 for (i,t) in tasks.enumerated() {
  let y = ty+CGFloat(i)*74
  box(x,y,bw,73,color(0xfffefa)); box(x,y+73,bw,1,line)
  text(t["symbol"] as! String,x+10,y+19,18,muted)
  text(t["title"] as! String,x+36,y+10,mobile ? 11 : 13,ink,false,true,bw-(mobile ? 50 : 175))
  let producer = (t["agent"] as! String).capitalized
  text("\(t["id"]!) · \(producer)",x+36,y+49,10,muted)
  let status = t["status"] as! String
  let sx = x+bw-(mobile ? 84 : 106)
  box(sx,y+44,mobile ? 77 : 94,22,status == "Blocked" ? color(0xfae9d9) : color(0xeaf0dd),5)
  text(status,sx+7,y+48,9,green)
 }
 let gy = ty+CGFloat(tasks.count)*74+35
 text("Made along the way",x,gy,18,ink,false,true)
 text("Working drafts and finished pieces, with their source attached.",x,gy+29,11,muted,false,false,bw)
 for (i,r) in results.enumerated() {
  let cw:CGFloat = mobile ? bw : (bw-18)/2
  let cx = mobile ? x : x+CGFloat(i%2)*(cw+18)
  let cy = gy+62+CGFloat(mobile ? i : i/2)*255
  box(cx,cy,cw,238,color(0xfffefa),8)
  let colors:[UInt32] = [0xe7eddf,0xeee8dc,0xe5e6ed,0xe4ebdf]
  box(cx,cy,cw,115,color(colors[i]),8)
  if i == 0 { text("Tasks   —   Agents   —   Results",cx+28,cy+48,14,green,true,false,cw-45) }
  if i == 1 { box(cx+cw/2-75,cy+16,150,83,color(0xfffdf7),3); text("First things first.",cx+cw/2-60,cy+29,16,ink,true); for k in 0..<3 {box(cx+cw/2-60,cy+58+CGFloat(k)*10,110-CGFloat(k)*12,3,line)} }
  if i == 2 { text("const desk = {\n  query: 'good work'\n};",cx+35,cy+20,15,color(0x746489)) }
  if i == 3 { text("✓  Visible focus\n✓  Clear labels\n✓  A way back",cx+40,cy+20,15,green) }
  text("\(r["type"]!) · \(r["task"]!)",cx+16,cy+128,9,muted)
  text(r["title"] as! String,cx+16,cy+148,14,ink,false,true,cw-32)
  text(r["state"] as! String,cx+16,cy+174,11,muted)
  let owner = tasks.first{$0["id"] as? String == r["task"] as? String}!["agent"] as! String
  text("Made by \(owner.capitalized)",cx+16,cy+207,10,muted)
  text("View result ↗",cx+cw-93,cy+207,10,green)
 }
 box(0,CGFloat(height)-45,w,45,green)
 text("DESIGN PREVIEW · AppKit rendering · NOT a browser screenshot",margin,CGFloat(height)-30,mobile ? 9 : 12,.white,false,false,w-margin*2)
 NSGraphicsContext.restoreGraphicsState()
 try bitmap.representation(using:.png,properties:[:])!.write(to:url)
 print("Wrote design preview: \(name)")
}
try render(width:1440,height:1620,name:"engineering-desk-desktop-v2.png")
try render(width:390,height:2450,name:"engineering-desk-mobile-v2.png")
