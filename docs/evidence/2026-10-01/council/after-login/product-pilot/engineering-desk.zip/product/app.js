'use strict';

const agents = [
  { id: 'atlas', name: 'Atlas', role: 'Systems & architecture', color: 'sage', letter: 'A' },
  { id: 'mira', name: 'Mira', role: 'Product & experience', color: 'clay', letter: 'M' },
  { id: 'patch', name: 'Patch', role: 'Engineering & quality', color: 'lilac', letter: 'P' }
];
const tasks = [
  { id: 'ED-101', title: 'Map the workspace architecture', agent: 'atlas', status: 'Done', area: 'Architecture', symbol: '✓' },
  { id: 'ED-102', title: 'Shape the onboarding experience', agent: 'mira', status: 'In review', area: 'Product design', symbol: '◇' },
  { id: 'ED-103', title: 'Build the task search interface', agent: 'patch', status: 'In progress', area: 'Frontend', symbol: '◐' },
  { id: 'ED-104', title: 'Define the result data contract', agent: 'atlas', status: 'Blocked', area: 'Data model', symbol: '⊘', note: 'Waiting for retention requirements' },
  { id: 'ED-105', title: 'Explore a compact mobile layout', agent: 'mira', status: 'Planned', area: 'Exploration', symbol: '○' },
  { id: 'ED-106', title: 'Verify keyboard navigation', agent: 'patch', status: 'Done', area: 'Quality', symbol: '✓' }
];
const results = [
  { id: 'architecture', task: 'ED-101', type: 'System map', title: 'A place for every piece', state: 'Demo · final example', art: 'system', body: ['The workspace brings tasks, agents and results into a single local view.', 'Each task has one owner. Every result points to its source task, which establishes its producer.', 'A future connected version would need durable artifact storage and independently verified task states.'] },
  { id: 'onboarding', task: 'ED-102', type: 'Design notes', title: 'A calmer first five minutes', state: 'Demo · review draft', art: 'notes', body: ['Start with a small, legible overview of the work already in motion.', 'Let people select an agent, scan their tasks and inspect the result without losing their place.', 'Open question: should a first visit prioritize recently finished work or tasks that need attention? This draft has not been accepted.'] },
  { id: 'search', task: 'ED-103', type: 'Implementation sketch', title: 'Find the work that matters', state: 'Demo · work in progress', art: 'code', body: ['Search matches task IDs, task titles, agent names, disciplines and result titles or types.', 'Status and agent filters narrow both the board and its related results. Reset clears every filter.', 'This example sketch is an illustrative result, not independent evidence that a live engineering task is complete.'] },
  { id: 'keyboard', task: 'ED-106', type: 'QA checklist', title: 'A path through the keyboard', state: 'Demo · final example', art: 'checks', body: ['Tab reaches search, native status selection, agent filters and result buttons.', 'A result opens in a native dialog. Escape closes it and focus returns to the opener.', 'This sample checklist describes intended behavior; consult the repository validation report for actual product checks.'] }
];

const state = { query: '', agent: 'all', status: 'all' };
const byId = id => document.getElementById(id);
const agentFor = id => agents.find(agent => agent.id === id);
const taskFor = id => tasks.find(task => task.id === id);
const escapeText = value => String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const avatar = agent => `<span class="avatar ${agent.color}" aria-hidden="true">${agent.letter}</span>`;

function visibleTasks() {
  const query = state.query.trim().toLowerCase();
  return tasks.filter(task => {
    const agent = agentFor(task.agent);
    const related = results.filter(result => result.task === task.id);
    const haystack = [task.id, task.title, task.area, task.note || '', agent.name, agent.role, ...related.flatMap(result => [result.title, result.type])].join(' ').toLowerCase();
    return (state.agent === 'all' || state.agent === task.agent) && (state.status === 'all' || state.status === task.status) && haystack.includes(query);
  });
}

function resetFilters() {
  state.query = ''; state.agent = 'all'; state.status = 'all';
  byId('search').value = ''; byId('status').value = 'all';
  render();
  byId('search').focus();
}

function empty(title, detail) {
  return `<div class="empty"><h3>${title}</h3><p>${detail}</p><button type="button" data-reset>Clear all filters</button></div>`;
}

function art(kind) {
  const illustrations = {
    system: '<span class="mini-node">Tasks</span><span class="connector"></span><span class="mini-node">Agents</span><span class="connector"></span><span class="mini-node">Results</span>',
    notes: '<div class="paper"><b>First things first.</b><i></i><i></i><i></i></div>',
    code: '<div class="code-sheet">const desk = {<br>&nbsp; query: <span>"good work"</span>,<br>&nbsp; agent: <span>"everyone"</span><br>};</div>',
    checks: '<div class="check-sheet"><div><b>✓</b> Visible focus</div><div><b>✓</b> Clear labels</div><div><b>✓</b> A way back</div></div>'
  };
  return `<div class="result-art art-${kind}" aria-hidden="true"><span class="art-label">DEMO / ${kind.toUpperCase()}</span>${illustrations[kind]}</div>`;
}

function render() {
  document.querySelectorAll('.agent-button').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.agent === state.agent)));
  const filtered = visibleTasks();
  const related = results.filter(result => filtered.some(task => task.id === result.task));
  byId('task-count').textContent = filtered.length;
  byId('result-count').textContent = related.length;
  byId('filter-summary').textContent = `${filtered.length} tasks and ${related.length} results shown. Agent: ${state.agent === 'all' ? 'everyone' : agentFor(state.agent).name}. Status: ${state.status}.`;
  byId('tasks').innerHTML = filtered.length ? filtered.map(task => `<article class="task-row" data-task="${task.id}"><div class="task-main"><span class="task-symbol" aria-hidden="true">${task.symbol}</span><div><h3>${escapeText(task.title)}</h3><div class="task-meta"><span>${task.id}</span><span>·</span><span>${agentFor(task.agent).name}</span><span>·</span><span>${task.note || task.area}</span></div></div></div><span class="status ${task.status.toLowerCase().replaceAll(' ', '-')}">${task.status}</span></article>`).join('') : empty('Nothing on this part of the desk.', 'Try a different search, agent or status — or start fresh.');
  byId('results').innerHTML = related.length ? related.map(result => {
    const task = taskFor(result.task), agent = agentFor(task.agent);
    return `<article class="result-card" data-result="${result.id}">${art(result.art)}<div class="result-info"><span class="result-type">${result.type} · ${task.id}</span><h3>${result.title}</h3><p>${result.state}</p><div class="result-bottom"><span class="producer">${avatar(agent)} Made by ${agent.name}</span><button type="button" class="open-result" data-open="${result.id}" aria-label="Open ${result.title}">View result ↗</button></div></div></article>`;
  }).join('') : empty('No results here yet.', filtered.length ? 'These demo tasks have no matching result. Planned and blocked work may have nothing to share yet.' : 'Results follow the tasks above. Clear the filters to explore all four.');
}

byId('agent-filters').innerHTML = `<button class="agent-button" type="button" data-agent="all" aria-pressed="true"><span class="avatar all-avatar" aria-hidden="true">✳</span><span><span class="agent-name">Everyone</span><span class="agent-role">The whole picture</span></span><span class="agent-number">06</span></button>` + agents.map(agent => `<button class="agent-button" type="button" data-agent="${agent.id}" aria-pressed="false">${avatar(agent)}<span><span class="agent-name">${agent.name}</span><span class="agent-role">${agent.role}</span></span><span class="agent-number">02</span></button>`).join('');
byId('agent-filters').addEventListener('click', event => { const button = event.target.closest('[data-agent]'); if (button) { state.agent = button.dataset.agent; render(); } });
byId('search').addEventListener('input', event => { state.query = event.target.value; render(); });
byId('status').addEventListener('change', event => { state.status = event.target.value; render(); });
byId('reset').addEventListener('click', resetFilters);
document.addEventListener('click', event => {
  if (event.target.closest('[data-reset]')) resetFilters();
  const button = event.target.closest('[data-open]');
  if (!button) return;
  const result = results.find(item => item.id === button.dataset.open);
  const task = taskFor(result.task);
  byId('dialog-title').textContent = result.title;
  byId('dialog-meta').textContent = `${result.type} · ${task.id} · Produced by ${agentFor(task.agent).name} · ${result.state}`;
  byId('dialog-body').innerHTML = `<ul>${result.body.map(line => `<li>${escapeText(line)}</li>`).join('')}</ul>`;
  byId('result-dialog').showModal();
});
byId('close-dialog').addEventListener('click', () => byId('result-dialog').close());
render();

// Optional local browser checks. This script is never loaded during normal use.
if (new URLSearchParams(location.search).has('check')) {
  const script = document.createElement('script');
  script.src = 'browser-checks.js';
  document.body.append(script);
}
